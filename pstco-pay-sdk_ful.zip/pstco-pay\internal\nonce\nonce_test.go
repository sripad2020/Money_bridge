package nonce

import (
	"context"
	"errors"
	"testing"
	"time"
)

func TestNonceIsSingleUseScopedAndExpiring(t *testing.T) {
	ctx := context.Background()
	s := New(time.Minute)
	defer s.Close()
	n, ref, _ := s.Issue(ctx, "pay_1:CAPTURE:1")
	if ref == n || ref != Ref(n) {
		t.Fatal("reference must be a hash, not the nonce")
	}
	if err := s.Consume(ctx, n, "pay_1:CAPTURE:2"); !errors.Is(err, ErrScopeMismatch) {
		t.Fatalf("scope: %v", err)
	}
	if err := s.Consume(ctx, n, "pay_1:CAPTURE:1"); err != nil {
		t.Fatal(err)
	}
	if err := s.Consume(ctx, n, "pay_1:CAPTURE:1"); !errors.Is(err, ErrUsed) {
		t.Fatalf("replay: %v", err)
	}
	if err := s.Consume(ctx, "nope", "x"); !errors.Is(err, ErrUnknown) {
		t.Fatalf("unknown: %v", err)
	}
	m, _, _ := s.Issue(ctx, "x")
	s.now = func() time.Time { return time.Now().Add(2 * time.Minute) }
	if err := s.Consume(ctx, m, "x"); !errors.Is(err, ErrExpired) {
		t.Fatalf("expiry: %v", err)
	}
}
