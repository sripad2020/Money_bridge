// Command pstco-server runs the complete PSTCO-Pay backend: the merchant
// gRPC API, the offline payment HTTPS API for wallet devices, the SMS
// gateway, and every background worker. See sdk/server for embedding it.
package main

import (
	"context"
	"flag"
	"log/slog"
	"os"
	"os/signal"
	"strings"
	"syscall"

	"pstcopay/sdk/server"
)

func main() {
	var c server.Config
	flag.StringVar(&c.GRPCAddr, "listen", "127.0.0.1:8443", "merchant gRPC listen address")
	flag.StringVar(&c.OfflineAddr, "offline-listen", "127.0.0.1:8444", "offline HTTPS API listen address (- disables)")
	flag.StringVar(&c.MetricsAddr, "metrics", "127.0.0.1:9464", "metrics and health address (- disables)")
	flag.StringVar(&c.DataDir, "data", "data", "directory for the database, keys, anchors and simulator state")
	flag.StringVar(&c.CertDir, "certs", "certs", "directory with ca.pem, server.pem and server-key.pem")
	flag.StringVar(&c.Congestion, "cc", "bbr", "TCP congestion control: bbr, cubic or empty (Linux only)")
	flag.StringVar(&c.Faults, "faults", "none", "simulated processor faults: none, flaky or chaos")
	flag.Float64Var(&c.LatencyMS, "processor-latency-ms", 2, "simulated processor latency per call")
	flag.Int64Var(&c.MaxInflight, "max-inflight", 512, "admission control: max in-flight payments")
	maxStreams := flag.Uint("max-streams", 1000, "HTTP/2 max concurrent streams per connection")
	flag.StringVar(&c.GatewayCN, "gateway-cn", "", "certificate CN of a trusted Envoy gateway")
	flag.StringVar(&c.AdminCN, "admin-cn", "pstco-admin", "certificate CN allowed to run admin RPCs")
	flag.StringVar(&c.Durability, "durability", "full", "full: fsync every commit; normal: survives process crash only")
	flag.StringVar(&c.RedisURL, "redis", os.Getenv("PSTCO_REDIS_URL"), "Redis URL for nonces, locks and cache (empty: in-process)")
	flag.BoolVar(&c.DevOTP, "dev-otp", false, "return OTPs in API responses (development only)")
	flag.StringVar(&c.SMSGatewaySecret, "sms-gateway-secret", os.Getenv("PSTCO_SMS_GATEWAY_SECRET"), "HMAC secret shared with the SMS aggregator")
	flag.StringVar(&c.AndroidRootsPEM, "android-roots", "", "PEM file of trusted Android key attestation roots")
	flag.StringVar(&c.AppleRootsPEM, "apple-roots", "", "PEM file of the Apple App Attest root")
	appIDs := flag.String("apple-app-ids", "", "comma-separated <team>.<bundle> IDs allowed to register")
	flag.BoolVar(&c.AppleDevelopment, "apple-development", false, "accept App Attest development environment")
	flag.StringVar(&c.SIMRootsPEM, "sim-roots", "", "PEM file of the SIM applet CA")
	flag.BoolVar(&c.RequireHardware, "require-hardware", false, "refuse devices without verified secure hardware")
	flag.IntVar(&c.PublicRateLimit, "public-rate-limit", 0, "public API requests per minute per IP (0 = 30, -1 = off)")
	logLevel := flag.String("log", "info", "log level: debug, info, warn, error")
	flag.Parse()

	c.MaxStreams = uint32(*maxStreams)
	if *appIDs != "" {
		c.AppleAppIDs = strings.Split(*appIDs, ",")
	}
	if s := os.Getenv("PSTCO_MERCHANT_SECRET"); s != "" {
		c.MerchantSecret = s
	}
	var lvl slog.Level
	_ = lvl.UnmarshalText([]byte(*logLevel))
	c.Logger = slog.New(slog.NewTextHandler(os.Stderr, &slog.HandlerOptions{Level: lvl}))
	c.KeyPassphrase = os.Getenv("PSTCO_KEY_PASSPHRASE")
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	if err := server.Run(ctx, c); err != nil {
		c.Logger.Error("fatal", "err", err)
		os.Exit(1)
	}
}
