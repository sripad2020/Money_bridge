// Package offlinesvc is the server side of PSTCO-Pay offline payments:
// account verification by OTP, device registration with or without secure
// hardware, deposits and offline reserves at the bank, record sync over the
// internet or SMS, verification, double-spend and rollback detection,
// settlement to payees, reserve expiry and reconciliation.
package offlinesvc

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"log/slog"
	"math/big"
	"strings"
	"sync"
	"time"

	"pstcopay/internal/bank"
	"pstcopay/internal/chain"
	"pstcopay/internal/store"
	"pstcopay/sdk/attest"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/offline/api"
)

// Bank is the bank integration. *bank.Bank (the simulator) implements it.
type Bank interface {
	Deposit(ctx context.Context, key, account string, amount int64) (*bank.Result, error)
	Hold(ctx context.Context, key, account, holdID string, amount int64) (*bank.Result, error)
	MoveHold(ctx context.Context, key, fromHold, toHold string, amount int64) (*bank.Result, error)
	TransferFromHold(ctx context.Context, key, holdID, to string, amount int64) (*bank.Result, error)
	ReleaseFromHold(ctx context.Context, key, holdID string, amount int64) (*bank.Result, error)
	Query(ctx context.Context, key string) (*bank.Result, error)
	Balance(ctx context.Context, account string) (available, held int64)
}

// SMSSender sends SMS: OTPs and payment confirmations.
type SMSSender interface {
	Send(ctx context.Context, to, text string) error
}

// LogSMS writes messages to the log instead of sending them (development).
// Unless ShowSecrets is set it masks the phone number and every digit run of
// four or more (OTP codes), so logs never hold credentials or full numbers.
type LogSMS struct {
	Log         *slog.Logger
	ShowSecrets bool
}

// Send implements SMSSender.
func (l LogSMS) Send(_ context.Context, to, text string) error {
	if !l.ShowSecrets {
		to, text = MaskPhone(to), redactDigits(text)
	}
	l.Log.Info("sms", "to", to, "text", text)
	return nil
}

// MaskPhone keeps only the last four digits of a phone number for logs.
func MaskPhone(p string) string {
	if len(p) <= 4 {
		return "****"
	}
	return strings.Repeat("*", len(p)-4) + p[len(p)-4:]
}

func redactDigits(s string) string {
	b := []byte(s)
	for i := 0; i < len(b); {
		j := i
		for j < len(b) && b[j] >= '0' && b[j] <= '9' {
			j++
		}
		if j-i >= 4 {
			for k := i; k < j; k++ {
				b[k] = '#'
			}
		}
		if j == i {
			j++
		}
		i = j
	}
	return string(b)
}

// Locker serialises work per device. *coord.Redis implements it; nil uses an
// in-process lock.
type Locker interface {
	Lock(ctx context.Context, key string) (func(), error)
}

// Policy sets limits per trust level. The defaults are placeholders: confirm
// the current RBI caps for offline payments before production.
type Policy struct {
	Software           api.Limits
	HardwareKey        api.Limits
	SecureApplet       api.Limits
	AllowSoftware      bool          // register devices without secure hardware
	RejectCriticalRASP bool          // refuse registration on a critical RASP finding
	CertValidity       time.Duration // device certificate lifetime
	SettlementGrace    time.Duration // how long after reserve expiry records are still accepted
	MaxDepositPaise    int64
}

// DefaultPolicy returns conservative defaults.
func DefaultPolicy() Policy {
	return Policy{
		Software:           api.Limits{PerPaymentPaise: 200_00, MaxReservePaise: 500_00, ReserveDays: 7},
		HardwareKey:        api.Limits{PerPaymentPaise: 500_00, MaxReservePaise: 2000_00, ReserveDays: 30},
		SecureApplet:       api.Limits{PerPaymentPaise: 500_00, MaxReservePaise: 2000_00, ReserveDays: 30},
		AllowSoftware:      true,
		RejectCriticalRASP: true,
		CertValidity:       365 * 24 * time.Hour,
		SettlementGrace:    7 * 24 * time.Hour,
		MaxDepositPaise:    1_00_000_00,
	}
}

func (p Policy) limits(t offline.Trust) api.Limits {
	switch t {
	case offline.TrustSecureApplet:
		return p.SecureApplet
	case offline.TrustHardwareKey:
		return p.HardwareKey
	}
	return p.Software
}

// Config configures the service.
type Config struct {
	Policy            Policy
	Attest            *attest.Registry
	DevOTP            bool // return the OTP in the API response (development only)
	OTPSecret         []byte
	GatewaySecret     []byte // HMAC key shared with the SMS aggregator
	OTPTTL            time.Duration
	TokenTTL          time.Duration
	ChallengeTTL      time.Duration
	RequestSkew       time.Duration
	MaxSettleAttempts int
	SettleInterval    time.Duration
	ExpireInterval    time.Duration
	// PublicRateLimit is requests per minute per client IP on unauthenticated
	// endpoints (default 30; -1 disables, e.g. behind a proxy that limits).
	PublicRateLimit int
}

func (c *Config) defaults() {
	if c.Policy == (Policy{}) {
		c.Policy = DefaultPolicy()
	}
	if c.Attest == nil {
		c.Attest = attest.NewRegistry()
	}
	if len(c.OTPSecret) == 0 {
		c.OTPSecret = make([]byte, 32)
		_, _ = rand.Read(c.OTPSecret)
	}
	if c.OTPTTL == 0 {
		c.OTPTTL = 5 * time.Minute
	}
	if c.TokenTTL == 0 {
		c.TokenTTL = 10 * time.Minute
	}
	if c.ChallengeTTL == 0 {
		c.ChallengeTTL = 5 * time.Minute
	}
	if c.RequestSkew == 0 {
		c.RequestSkew = 5 * time.Minute
	}
	if c.MaxSettleAttempts == 0 {
		c.MaxSettleAttempts = 10
	}
	if c.SettleInterval == 0 {
		c.SettleInterval = 200 * time.Millisecond
	}
	if c.ExpireInterval == 0 {
		c.ExpireInterval = 30 * time.Second
	}
}

// Service is the offline payment service.
type Service struct {
	cfg    Config
	st     *store.Store
	keys   *chain.KeyRing
	bank   Bank
	sms    SMSSender
	locker Locker
	log    *slog.Logger
	now    func() time.Time
	wg     sync.WaitGroup
	guard  *guard
	jobs   jobQueue
}

// Deps are the service's collaborators.
type Deps struct {
	Store  *store.Store
	Keys   *chain.KeyRing
	Bank   Bank
	SMS    SMSSender
	Locker Locker
	Logger *slog.Logger
}

// New creates the service.
func New(cfg Config, d Deps) *Service {
	cfg.defaults()
	if d.Logger == nil {
		d.Logger = slog.Default()
	}
	if d.SMS == nil {
		d.SMS = LogSMS{Log: d.Logger}
	}
	if d.Locker == nil {
		d.Locker = newLocalLock()
	}
	g := newGuard()
	switch {
	case cfg.PublicRateLimit < 0:
		g.ipLimit = 1 << 30
	case cfg.PublicRateLimit > 0:
		g.ipLimit = cfg.PublicRateLimit
	}
	return &Service{cfg: cfg, st: d.Store, keys: d.Keys, bank: d.Bank, sms: d.SMS, locker: d.Locker,
		log: d.Logger, now: time.Now, guard: g}
}

// SetClock replaces the clock (tests).
func (s *Service) SetClock(now func() time.Time) { s.now = now }

// CAPublicKey returns the bank CA key devices pin.
func (s *Service) CAPublicKey() []byte { return s.keys.PublicKey(chain.SignerOfflineCA) }

func (s *Service) caSign(msg []byte) []byte { return s.keys.Signer(chain.SignerOfflineCA).Sign(msg) }

// ------------------------------------------------------------------ errors

// Error is an API error with an HTTP status.
type Error struct {
	Status  int
	Code    string
	Message string
}

func (e *Error) Error() string { return e.Code + ": " + e.Message }

func apiErr(status int, code, format string, args ...any) *Error {
	return &Error{Status: status, Code: code, Message: fmt.Sprintf(format, args...)}
}

// ------------------------------------------------------------------ helpers

func randomID63() uint64 {
	for {
		var b [8]byte
		_, _ = rand.Read(b[:])
		v := binary.BigEndian.Uint64(b[:]) & 0x7fffffffffffffff
		if v != 0 {
			return v
		}
	}
}

func randomHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func sha(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}

func shaBytes(b []byte) string {
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:])
}

func (s *Service) otpHash(phone, code string) string {
	m := hmac.New(sha256.New, s.cfg.OTPSecret)
	m.Write([]byte(phone + ":" + code))
	return hex.EncodeToString(m.Sum(nil))
}

type localLock struct {
	mu sync.Mutex
	m  map[string]chan struct{}
}

func newLocalLock() *localLock { return &localLock{m: map[string]chan struct{}{}} }

func (l *localLock) Lock(ctx context.Context, key string) (func(), error) {
	l.mu.Lock()
	ch, ok := l.m[key]
	if !ok {
		ch = make(chan struct{}, 1)
		l.m[key] = ch
	}
	l.mu.Unlock()
	select {
	case ch <- struct{}{}:
		return func() { <-ch }, nil
	case <-ctx.Done():
		return nil, ctx.Err()
	}
}

func (s *Service) lockDevice(ctx context.Context, id uint64) (func(), error) {
	return s.locker.Lock(ctx, "offline-device:"+offline.FormatID(id))
}

// bankDo calls the bank, retrying when it is unavailable and resolving lost
// responses by querying the original key, so no operation runs twice.
func (s *Service) bankDo(ctx context.Context, key string, op func(context.Context) (*bank.Result, error)) (*bank.Result, error) {
	var last error
	for attempt := 0; attempt < 4; attempt++ {
		r, err := op(ctx)
		switch {
		case err == nil:
			return r, nil
		case errors.Is(err, bank.ErrTimeout):
			if q, qerr := s.bank.Query(ctx, key); qerr == nil {
				if q.OK {
					return q, nil
				}
				return q, fmt.Errorf("%w: %s", bank.ErrInsufficient, q.Reason)
			}
		case errors.Is(err, bank.ErrUnavailable):
		default:
			return r, err
		}
		last = err
		t := time.NewTimer(time.Duration(10<<attempt) * time.Millisecond)
		select {
		case <-ctx.Done():
			t.Stop()
			return nil, ctx.Err()
		case <-t.C:
		}
	}
	return nil, last
}

// --------------------------------------------------------------- accounts

// StartAccount sends an OTP to the phone.
func (s *Service) StartAccount(ctx context.Context, r api.AccountStartRequest) (*api.AccountStartResponse, error) {
	phone, err := offline.NormalizePhone(r.Phone)
	if err != nil {
		return nil, apiErr(400, "invalid_phone", "%v", err)
	}
	name := strings.TrimSpace(r.Name)
	if name == "" || len(name) > 64 {
		return nil, apiErr(400, "invalid_name", "name must be 1 to 64 characters")
	}
	now := s.now()
	// At most 5 codes per phone per hour, so repeated re-sends cannot be used
	// to brute-force the 6-digit code.
	if !s.guard.allowKey("otp-send:"+phone, 5, time.Hour, now) {
		s.securityEvent(ctx, EventRateLimited, "phone:"+MaskPhone(phone), "OTP send limit")
		return nil, apiErr(429, "otp_rate_limited", "too many codes requested; try again in an hour")
	}
	if prev, err := s.st.GetOTP(ctx, phone); err == nil && now.Sub(prev.SentAt) < 30*time.Second {
		return nil, apiErr(429, "otp_rate_limited", "wait 30 seconds before requesting another code")
	}
	n, _ := rand.Int(rand.Reader, big.NewInt(1_000_000))
	code := fmt.Sprintf("%06d", n.Int64())
	if err := s.st.PutOTP(ctx, &store.OTP{Phone: phone, CodeHash: s.otpHash(phone, code), Name: name, Listed: r.Listed,
		ExpiresAt: now.Add(s.cfg.OTPTTL), SentAt: now}); err != nil {
		return nil, err
	}
	if err := s.sms.Send(ctx, phone, "Your PSTCO-Pay code is "+code+". Do not share it."); err != nil {
		return nil, apiErr(502, "sms_failed", "could not send the code")
	}
	resp := &api.AccountStartResponse{ExpiresInSeconds: int(s.cfg.OTPTTL.Seconds())}
	if s.cfg.DevOTP {
		resp.DevOTP = code
	}
	return resp, nil
}

// VerifyAccount checks the OTP, creates the account if needed and returns a
// single-use registration token.
func (s *Service) VerifyAccount(ctx context.Context, r api.AccountVerifyRequest) (*api.AccountVerifyResponse, error) {
	phone, err := offline.NormalizePhone(r.Phone)
	if err != nil {
		return nil, apiErr(400, "invalid_phone", "%v", err)
	}
	o, err := s.st.GetOTP(ctx, phone)
	if err != nil {
		return nil, apiErr(400, "otp_invalid", "no pending code for this phone")
	}
	now := s.now()
	if now.After(o.ExpiresAt) {
		_ = s.st.DeleteOTP(ctx, phone)
		return nil, apiErr(400, "otp_expired", "code expired")
	}
	if o.Attempts >= 5 {
		_ = s.st.DeleteOTP(ctx, phone)
		return nil, apiErr(429, "otp_locked", "too many wrong codes; request a new one")
	}
	if s.guard.isLocked("otp:"+phone, now) {
		return nil, apiErr(429, "otp_locked", "too many wrong codes; try again later")
	}
	if subtle.ConstantTimeCompare([]byte(o.CodeHash), []byte(s.otpHash(phone, r.OTP))) != 1 {
		_ = s.st.FailOTP(ctx, phone)
		if s.guard.fail("otp:"+phone, now) {
			s.securityEvent(ctx, EventAuthLockout, "phone:"+MaskPhone(phone), "OTP verification locked after repeated wrong codes")
		}
		return nil, apiErr(400, "otp_invalid", "wrong code")
	}
	_ = s.st.DeleteOTP(ctx, phone)
	acct, err := s.st.GetAccountByPhone(ctx, phone)
	created := false
	if errors.Is(err, store.ErrNotFound) {
		payee, _ := offline.PayeeIDForPhone(phone)
		acct = &store.Account{ID: "acct_" + randomHex(12), Phone: phone, Name: o.Name, PayeeID: payee,
			Listed: o.Listed, Status: "ACTIVE", CreatedAt: now}
		if err := s.st.InsertAccount(ctx, acct); err != nil {
			return nil, err
		}
		created = true
	} else if err != nil {
		return nil, err
	}
	token := randomHex(32)
	if err := s.st.PutRegistrationToken(ctx, sha(token), acct.ID, now.Add(s.cfg.TokenTTL)); err != nil {
		return nil, err
	}
	if created {
		s.releaseWaiting(ctx, acct.PayeeID)
	}
	return &api.AccountVerifyResponse{AccountID: acct.ID, PayeeID: offline.FormatID(acct.PayeeID),
		RegistrationToken: token, ExpiresInSeconds: int(s.cfg.TokenTTL.Seconds())}, nil
}

// releaseWaiting queues payments that arrived before the payee registered.
func (s *Service) releaseWaiting(ctx context.Context, payee uint64) {
	waiting, err := s.st.WaitingSettlements(ctx, payee)
	if err != nil {
		return
	}
	for _, w := range waiting {
		w.Status, w.NextAttemptAt = store.SettlePending, s.now()
		_ = s.st.UpdateOfflineSettlement(ctx, w, s.now())
	}
}

// ------------------------------------------------------------ registration

// Challenge issues a single-use registration challenge.
func (s *Service) Challenge(ctx context.Context, r api.ChallengeRequest) (*api.ChallengeResponse, error) {
	now := s.now()
	if _, err := s.st.PeekRegistrationToken(ctx, sha(r.RegistrationToken), now); err != nil {
		return nil, apiErr(401, "invalid_token", "registration token is invalid or expired")
	}
	ch := make([]byte, 32)
	_, _ = rand.Read(ch)
	if err := s.st.PutChallenge(ctx, shaBytes(ch), sha(r.RegistrationToken), now.Add(s.cfg.ChallengeTTL)); err != nil {
		return nil, err
	}
	return &api.ChallengeResponse{Challenge: ch, ExpiresInSeconds: int(s.cfg.ChallengeTTL.Seconds())}, nil
}

// Register registers a device. Devices with verified secure hardware get
// hardware trust; devices without it are still registered, with software
// trust and lower limits. Evidence that is present but invalid is rejected.
func (s *Service) Register(ctx context.Context, r api.RegisterRequest) (*api.RegisterResponse, error) {
	now := s.now()
	tokHash := sha(r.RegistrationToken)
	acctID, err := s.st.PeekRegistrationToken(ctx, tokHash, now)
	if err != nil {
		return nil, apiErr(401, "invalid_token", "registration token is invalid or expired")
	}
	if err := s.st.UseChallenge(ctx, shaBytes(r.Challenge), tokHash, now); err != nil {
		return nil, apiErr(401, "invalid_challenge", "challenge is invalid, used or expired")
	}
	alg, err := offline.ParseAlg(r.Algorithm)
	if err != nil || len(r.PublicKey) != alg.PublicKeySize() {
		return nil, apiErr(400, "invalid_key", "unsupported algorithm or key size")
	}
	if err := offline.VerifySignature(alg, r.PublicKey, api.RegisterMessage(r.Challenge, r.RegistrationToken, r.PublicKey), r.Proof); err != nil {
		return nil, apiErr(401, "invalid_proof", "device did not prove possession of the key")
	}
	var critical []string
	for _, f := range r.RASP {
		if f.Severity == "critical" {
			critical = append(critical, f.Check+": "+f.Detail)
		}
	}
	if len(critical) > 0 && s.cfg.Policy.RejectCriticalRASP {
		s.securityEvent(ctx, EventRASPBlocked, "account:"+acctID, strings.Join(critical, "; "))
		return nil, apiErr(403, "rasp_blocked", "device failed runtime protection: %s", strings.Join(critical, "; "))
	}
	res, err := s.cfg.Attest.Verify(r.Attestation, r.Challenge, r.PublicKey, alg, now)
	if err != nil {
		s.securityEvent(ctx, EventAttestationFail, "account:"+acctID, err.Error())
		return nil, apiErr(400, "attestation_invalid", "%v", err)
	}
	note := res.Note
	if res.Trust == offline.TrustSoftware && r.ElementKind != "" && r.ElementKind != "software" &&
		(r.Attestation.Format == "" || r.Attestation.Format == "none") {
		note = "element claims " + r.ElementKind + " but sent no attestation; registered with software trust"
	}
	if res.Trust == offline.TrustSoftware && !s.cfg.Policy.AllowSoftware {
		return nil, apiErr(403, "hardware_required", "this server only registers devices with verified secure hardware")
	}
	acct, err := s.st.GetAccount(ctx, acctID)
	if err != nil {
		return nil, err
	}
	lim := s.cfg.Policy.limits(res.Trust)
	devID := randomID63()
	cert := &offline.DeviceCert{Version: offline.CertV1, DeviceID: devID, OwnerPayee: acct.PayeeID, Alg: alg,
		Trust: res.Trust, PerPaymentLimit: lim.PerPaymentPaise, MaxReserve: lim.MaxReservePaise,
		IssuedAt: uint32(now.Unix()), ExpiresAt: uint32(now.Add(s.cfg.Policy.CertValidity).Unix()), PublicKey: r.PublicKey}
	if err := cert.Sign(s.caSign); err != nil {
		return nil, err
	}
	certRaw, _ := cert.Marshal()
	raspReport := ""
	for _, f := range r.RASP {
		raspReport += f.Severity + ":" + f.Check + " "
	}
	var revoked uint64
	err = s.st.WithTx(ctx, func(tx *store.Tx) error {
		if _, err := tx.UseRegistrationToken(ctx, tokHash, now); err != nil {
			return apiErr(401, "invalid_token", "registration token already used")
		}
		if old, err := tx.ActiveDevice(ctx, acct.ID); err == nil {
			// One active device per account: the previous one is revoked. Its
			// valid records are still paid from its reserve until expiry.
			if err := tx.SetDeviceStatus(ctx, old.ID, store.DeviceRevoked, "replaced by device "+offline.FormatID(devID), now); err != nil {
				return err
			}
			revoked = old.ID
		}
		return tx.InsertDevice(ctx, &store.Device{ID: devID, AccountID: acct.ID, Alg: byte(alg), PublicKey: r.PublicKey,
			Trust: byte(res.Trust), ElementKind: res.Kind, AttestationFormat: r.Attestation.Format, TrustNote: note,
			Cert: certRaw, Status: store.DeviceActive, RASP: strings.TrimSpace(raspReport), Model: r.Model,
			CreatedAt: now, UpdatedAt: now})
	})
	if err != nil {
		return nil, err
	}
	resp := &api.RegisterResponse{DeviceID: offline.FormatID(devID), AccountID: acct.ID, PayeeID: offline.FormatID(acct.PayeeID),
		Trust: res.Trust.String(), TrustNote: note, Certificate: certRaw, CAPublicKey: s.CAPublicKey(),
		ReceiptKey: s.ReceiptPublicKey(), Limits: lim}
	if revoked != 0 {
		resp.RevokedDeviceID = offline.FormatID(revoked)
	}
	s.log.Info("device registered", "device", resp.DeviceID, "account", acct.ID, "trust", resp.Trust, "kind", res.Kind)
	return resp, nil
}
