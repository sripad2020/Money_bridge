package engine

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"pstcopay/internal/acquirer"
	"pstcopay/internal/chain"
	"pstcopay/internal/model"
	"pstcopay/internal/risk"
	"pstcopay/internal/store"
)

// Cryptographic Stage Dependency Recovery (CSDR).
//
// Before any failed stage is retried, CSDR verifies four layers:
//  1. Cryptographic: every hash, link, signature, dependency and retry edge.
//  2. Business: merchant still active, payment not expired, risk approval and
//     authorization still valid.
//  3. Execution: ask the processor, by the original idempotency key, whether
//     the operation actually happened.
//  4. Financial: the idempotency record agrees, and any retry reuses the same
//     key so the processor deduplicates it.
// Only then does it reconcile the existing result, retry, re-authorize, stop
// or compensate. Every decision is itself recorded as a signed RECOVERY event.

// errDeferred tells drive that recovery handed the payment to the background
// recovery loop; it is not an error for the caller.
var errDeferred = errors.New("csdr: deferred to background recovery")

// Recover resumes a payment that is unfinished for any reason.
func (e *Engine) Recover(ctx context.Context, id string) (*model.Payment, error) {
	if _, ok := ctx.Deadline(); !ok {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, e.cfg.RecoveryDeadline)
		defer cancel()
	}
	unlock, err := e.locks.Lock(ctx, id)
	if err != nil {
		return nil, ErrBusy
	}
	defer unlock()
	p, err := e.GetPayment(ctx, id)
	if err != nil {
		return nil, err
	}
	if p.State.Terminal() {
		return p, nil
	}
	return e.drive(ctx, p)
}

// findFailed returns the most recent unsuccessful attempt that has not been
// superseded by a success of the same stage.
func findFailed(events []*chain.Event) *chain.Event {
	last := map[model.Stage]*chain.Event{}
	for _, ev := range events {
		switch ev.Stage {
		case model.StageRecovery, model.StageSettle, model.StageVoid, model.StageRefund:
			continue
		}
		last[ev.Stage] = ev
	}
	var failed *chain.Event
	for _, ev := range last {
		if ev.Status != model.EventSuccess && (failed == nil || ev.Seq > failed.Seq) {
			failed = ev
		}
	}
	return failed
}

func isDownstream(s model.Stage) bool {
	return s == model.StageAuthorize || s == model.StageCapture
}

// financialEffectPossible reports whether money may have moved downstream.
func financialEffectPossible(events []*chain.Event) bool {
	for _, ev := range events {
		if isDownstream(ev.Stage) && ev.Status != model.EventHardFail {
			return true
		}
	}
	return false
}

func opFor(s model.Stage) string {
	switch s {
	case model.StageAuthorize:
		return string(acquirer.OpAuthorize)
	case model.StageCapture:
		return string(acquirer.OpCapture)
	}
	return strings.ToLower(string(s))
}

type recovery struct {
	e      *Engine
	p      *model.Payment
	events []*chain.Event
	failed *chain.Event
	notes  map[string]string
}

// conclude records a RECOVERY event with the layer notes and moves the
// payment to target, in one transaction.
func (r *recovery) conclude(ctx context.Context, decision string, target model.State, code model.FailureCode,
	reason string, extra func(tx *store.Tx) error) error {
	r.notes["decision"] = decision
	ref := r.failed
	if ref == nil && len(r.events) > 0 {
		ref = r.events[len(r.events)-1]
	}
	attempt, _ := nextAttempt(r.events, model.StageRecovery)
	err := r.e.persist(ctx, func(tx *store.Tx) error {
		if _, err := r.e.appendEvent(ctx, tx, r.p.ID, evSpec{
			stage: model.StageRecovery, attempt: attempt, status: model.EventSuccess,
			deps: hashes(ref), signer: chain.SignerCSDR, payload: r.notes,
		}); err != nil {
			return err
		}
		if code != model.FailNone {
			r.p.FailureCode, r.p.FailureReason = code, reason
		}
		if r.p.State != target {
			if err := r.e.move(ctx, tx, r.p, target); err != nil {
				return err
			}
		}
		if extra != nil {
			return extra(tx)
		}
		return nil
	})
	if err == nil {
		r.e.metrics.Recovery(decision)
		r.e.notify(r.p)
		r.e.log.Info("csdr decision", "payment", r.p.ID, "decision", decision, "state", r.p.State)
	}
	return err
}

// stopTarget is where a payment goes when its failed stage cannot continue.
func stopTarget(p *model.Payment, stage model.Stage) model.State {
	if p.AuthID != "" || stage == model.StageCapture {
		return model.StateCompensating
	}
	return model.StateFailed
}

// recoverLocked runs CSDR on a payment. The caller holds the payment lock.
func (e *Engine) recoverLocked(ctx context.Context, p *model.Payment) error {
	if remaining(ctx) < e.cfg.MinRecoveryBudget {
		return nil
	}
	events, err := e.store.ListEvents(ctx, p.ID)
	if err != nil {
		return err
	}
	r := &recovery{e: e, p: p, events: events, failed: findFailed(events), notes: map[string]string{}}

	// Enter verification.
	if p.State != model.StateDependencyVerification {
		if err := e.persist(ctx, func(tx *store.Tx) error {
			if p.State != model.StateRecoveryPending {
				if err := e.move(ctx, tx, p, model.StateRecoveryPending); err != nil {
					return err
				}
			}
			return e.move(ctx, tx, p, model.StateDependencyVerification)
		}); err != nil {
			return err
		}
		e.notify(p)
	}
	if r.failed != nil {
		r.notes["failed_stage"] = string(r.failed.Stage)
		r.notes["failed_event"] = r.failed.EventID
		r.notes["failed_attempt"] = strconv.Itoa(r.failed.Attempt)
		r.notes["failed_status"] = string(r.failed.Status)
	}

	// Layer 1: cryptographic verification.
	if err := chain.VerifyGraph(events, e.keys); err != nil {
		code := model.FailHashMismatch
		var ie *chain.IntegrityError
		if errors.As(err, &ie) {
			code = ie.Code
		}
		r.notes["layer1_crypto"] = "FAILED: " + err.Error()
		target := model.StateFailed
		if financialEffectPossible(events) {
			target = model.StateReconciliationRequired
		}
		return r.conclude(ctx, "integrity_stop", target, code, err.Error(), nil)
	}
	r.notes["layer1_crypto"] = fmt.Sprintf("ok: %d events, hashes, links, signatures and dependencies verified", len(events))

	if r.failed == nil {
		return r.resume(ctx)
	}
	stage := r.failed.Stage
	failCode := model.FailureCode(r.failed.Payload["failure_code"])
	if r.failed.Status == model.EventPending {
		failCode = model.FailResponseTimeout // crashed mid-call: outcome unknown
	}
	r.notes["failure_code"] = string(failCode)

	// Layer 2: business verification.
	m, err := e.merchant(ctx, p.MerchantID)
	if err != nil {
		return err
	}
	now := e.now()
	preCapture := stage != model.StageCapture
	switch {
	case !m.Active:
		r.notes["layer2_business"] = "merchant disabled"
		return r.conclude(ctx, "business_stop", stopTarget(p, stage), model.FailMerchantDisabled, "merchant disabled", nil)
	case preCapture && !now.Before(p.ExpiresAt):
		r.notes["layer2_business"] = "payment expired at " + p.ExpiresAt.Format(time.RFC3339)
		return r.conclude(ctx, "business_stop", stopTarget(p, stage), model.FailPaymentExpired, "payment expired", nil)
	}
	needRisk := stage == model.StageAuthorize && !p.RiskApprovedAt.IsZero() &&
		now.After(p.RiskApprovedAt.Add(e.risk.Validity()))
	needReauth := false
	if stage == model.StageCapture {
		expired := failCode == model.FailAuthExpired || now.After(p.AuthorizedAt.Add(e.cfg.AuthValidity))
		if expired {
			if !m.AllowReauth || !now.Before(p.ExpiresAt) {
				r.notes["layer2_business"] = "authorization expired and re-authorization not permitted"
				return r.conclude(ctx, "business_stop", model.StateCompensating, model.FailAuthExpired,
					"authorization expired", nil)
			}
			needReauth = true
		}
	}
	r.notes["layer2_business"] = fmt.Sprintf("ok: merchant active, payment valid until %s, risk_reassess=%t, reauthorize=%t",
		p.ExpiresAt.Format(time.RFC3339), needRisk, needReauth)

	// Layer 3: execution verification.
	if isDownstream(stage) && r.failed.IdempotencyKey != "" {
		res, qerr := e.acq.Query(ctx, r.failed.IdempotencyKey)
		switch {
		case qerr == nil && res.Approved:
			r.notes["layer3_execution"] = "processor executed operation " + res.Ref + "; reusing existing result"
			r.notes["layer4_financial"] = "no new financial operation will be issued"
			return r.reconcileExisting(ctx, res)
		case qerr == nil:
			r.notes["layer3_execution"] = "processor executed and declined: " + res.DeclineCode
			return r.reconcileDecline(ctx, res)
		case errors.Is(qerr, acquirer.ErrNotFound):
			r.notes["layer3_execution"] = "processor has no record of key " + r.failed.IdempotencyKey
		default:
			r.notes["layer3_execution"] = "status query failed: " + qerr.Error()
			if err := r.conclude(ctx, "deferred_unknown", model.StateUnknownOutcome, model.FailResponseTimeout,
				"downstream status could not be determined", nil); err != nil {
				return err
			}
			return errDeferred
		}
	} else {
		r.notes["layer3_execution"] = "local stage, no downstream effect"
	}

	// Layer 4: financial verification.
	if isDownstream(stage) {
		rec, err := e.store.GetIdempotency(ctx, r.failed.IdempotencyKey)
		switch {
		case err == nil && rec.Status == store.IdemCompleted:
			r.notes["layer4_financial"] = "idempotency record says COMPLETED but processor has no record"
			return r.conclude(ctx, "financial_mismatch", model.StateReconciliationRequired, model.FailInternal,
				"idempotency record and processor disagree", nil)
		case err == nil:
			r.notes["layer4_financial"] = fmt.Sprintf("ok: key %s status %s; retry reuses the key so the processor deduplicates",
				rec.OpKey, rec.Status)
		case errors.Is(err, store.ErrNotFound):
			r.notes["layer4_financial"] = "ok: no idempotency record, nothing executed"
		default:
			return err
		}
	}

	// Classify and decide.
	if needReauth {
		return r.reauthorize(ctx, needRisk)
	}
	if r.failed.Status == model.EventHardFail || !failCode.Retryable() {
		target := model.StateDeclined
		if stage == model.StageCapture {
			target = model.StateCompensating
		}
		return r.conclude(ctx, "not_retryable", target, failCode, "failure is not retryable: "+string(failCode), nil)
	}
	op := opFor(stage)
	if r.failed.Attempt >= e.cfg.MaxAttempts {
		return r.conclude(ctx, "retries_exhausted", stopTarget(p, stage), model.FailRetriesExhausted,
			fmt.Sprintf("%s failed %d times", stage, r.failed.Attempt), nil)
	}
	backoff := e.ctl.Backoff(op, r.failed.Attempt)
	if remaining(ctx) < backoff+e.ctl.Expected(op)+e.cfg.MinRecoveryBudget {
		r.notes["backoff_ms"] = strconv.FormatInt(backoff.Milliseconds(), 10)
		if err := r.conclude(ctx, "deferred_deadline", model.StateSoftFailure, failCode,
			"retry deferred: not enough deadline left", nil); err != nil {
			return err
		}
		return errDeferred
	}
	if err := sleep(ctx, backoff); err != nil {
		if err := r.conclude(ctx, "deferred_deadline", model.StateSoftFailure, failCode,
			"retry deferred: deadline reached during backoff", nil); err != nil {
			return err
		}
		return errDeferred
	}
	r.notes["backoff_ms"] = strconv.FormatInt(backoff.Milliseconds(), 10)
	r.notes["congestion_factor"] = strconv.FormatFloat(e.ctl.CongestionFactor(), 'f', 2, 64)
	if err := r.conclude(ctx, "retry", model.StateRetryOrResume, model.FailNone, "", nil); err != nil {
		return err
	}
	switch stage {
	case model.StageAuthorize:
		if needRisk {
			if ok, err := r.reassessRisk(ctx); err != nil || !ok {
				return err
			}
		}
		return e.authorize(ctx, p, chain.SignerCSDR)
	case model.StageCapture:
		return e.capture(ctx, p, chain.SignerCSDR)
	}
	// Local stages (authentication or risk) re-run from VALIDATED.
	return e.persist(ctx, func(tx *store.Tx) error { return e.move(ctx, tx, p, model.StateValidated) })
}

// resume continues a payment whose latest stages all succeeded.
func (r *recovery) resume(ctx context.Context) error {
	ev := r.events
	var target model.State
	switch {
	case latestSuccess(ev, model.StageCapture) != nil:
		target = model.StateCaptured
	case latestSuccess(ev, model.StageAuthorize) != nil:
		target = model.StateAuthorized
	case latestSuccess(ev, model.StageAuthenticate) != nil && latestSuccess(ev, model.StageRisk) != nil:
		target = model.StateRiskPending
	case latestSuccess(ev, model.StageValidate) != nil:
		target = model.StateValidated
	default:
		return r.conclude(ctx, "no_resume_point", model.StateFailed, model.FailInternal, "no verified resume point", nil)
	}
	r.notes["resume_state"] = string(target)
	if err := r.conclude(ctx, "resume", model.StateRetryOrResume, model.FailNone, "", nil); err != nil {
		return err
	}
	return r.e.persist(ctx, func(tx *store.Tx) error { return r.e.move(ctx, tx, r.p, target) })
}

// reconcileExisting records the processor's existing successful result as the
// outcome of the failed attempt and continues from there.
func (r *recovery) reconcileExisting(ctx context.Context, res *acquirer.Result) error {
	e, p, f := r.e, r.p, r.failed
	return r.conclude(ctx, "reconciled_existing", model.StateRetryOrResume, model.FailNone, "", func(tx *store.Tx) error {
		if _, err := e.appendEvent(ctx, tx, p.ID, evSpec{
			stage: f.Stage, attempt: f.Attempt, status: model.EventSuccess, deps: f.DependencyHashes,
			retryOf: f.CurrentHash, idemKey: f.IdempotencyKey, signer: chain.SignerCSDR,
			payload: map[string]string{"reconciled": "true", "source": "processor_status_query", "downstream_ref": res.Ref},
		}); err != nil {
			return err
		}
		if err := tx.PutIdempotency(ctx, &store.IdemRecord{OpKey: f.IdempotencyKey, PaymentID: p.ID,
			Operation: opFor(f.Stage), Status: store.IdemCompleted, DownstreamRef: res.Ref}, e.now()); err != nil {
			return err
		}
		p.FailureCode, p.FailureReason = model.FailNone, ""
		if f.Stage == model.StageAuthorize {
			p.AuthID, p.AuthorizedAt = res.Ref, res.At.UTC()
			return e.move(ctx, tx, p, model.StateAuthorized)
		}
		return e.applyCaptured(ctx, tx, p, res)
	})
}

// reconcileDecline records a decline that the processor executed but whose
// response was lost.
func (r *recovery) reconcileDecline(ctx context.Context, res *acquirer.Result) error {
	e, p, f := r.e, r.p, r.failed
	target := model.StateDeclined
	if f.Stage == model.StageCapture {
		target = model.StateCompensating
	}
	reason := fmt.Sprintf("declined %s: %s", res.DeclineCode, res.Reason)
	return r.conclude(ctx, "reconciled_decline", target, model.FailBusinessRejection, reason, func(tx *store.Tx) error {
		if _, err := e.appendEvent(ctx, tx, p.ID, evSpec{
			stage: f.Stage, attempt: f.Attempt, status: model.EventHardFail, deps: f.DependencyHashes,
			retryOf: f.CurrentHash, idemKey: f.IdempotencyKey, signer: chain.SignerCSDR,
			payload: map[string]string{"reconciled": "true", "failure_code": string(model.FailBusinessRejection), "reason": reason},
		}); err != nil {
			return err
		}
		return tx.PutIdempotency(ctx, &store.IdemRecord{OpKey: f.IdempotencyKey, PaymentID: p.ID,
			Operation: opFor(f.Stage), Status: store.IdemDeclined}, e.now())
	})
}

// reauthorize places a new authorization after the old one expired, then the
// pipeline captures against it.
func (r *recovery) reauthorize(ctx context.Context, needRisk bool) error {
	n := 0
	for _, ev := range r.events {
		if ev.Stage == model.StageAuthorize && ev.Status == model.EventSuccess {
			n++
		}
	}
	key := fmt.Sprintf("%s:authorize:reauth-%d", r.p.ID, n)
	r.notes["reauth_key"] = key
	if err := r.conclude(ctx, "reauthorize", model.StateRetryOrResume, model.FailNone, "", nil); err != nil {
		return err
	}
	if needRisk {
		if ok, err := r.reassessRisk(ctx); err != nil || !ok {
			return err
		}
	}
	r.p.AuthID = ""
	return r.e.authorizeWithKey(ctx, r.p, chain.SignerCSDR, key)
}

// reassessRisk refreshes an expired risk approval. It returns false (and
// declines the payment) when the new assessment declines.
func (r *recovery) reassessRisk(ctx context.Context) (bool, error) {
	e, p := r.e, r.p
	events, err := e.store.ListEvents(ctx, p.ID)
	if err != nil {
		return false, err
	}
	a := e.risk.Assess(p)
	attempt, _ := nextAttempt(events, model.StageRisk)
	ok := a.Decision != risk.Decline
	err = e.persist(ctx, func(tx *store.Tx) error {
		spec := evSpec{stage: model.StageRisk, attempt: attempt, status: model.EventSuccess,
			deps: hashes(latestSuccess(events, model.StageValidate)), signer: chain.SignerRisk,
			payload: map[string]string{"score": strconv.FormatFloat(a.Score, 'f', 3, 64),
				"decision": string(a.Decision), "reason": "re-assessment after approval expiry"}}
		if !ok {
			spec.status = model.EventHardFail
			spec.payload["failure_code"] = string(model.FailRiskDeclined)
		}
		if _, err := e.appendEvent(ctx, tx, p.ID, spec); err != nil {
			return err
		}
		p.RiskScore, p.RiskDecision = a.Score, string(a.Decision)
		if !ok {
			p.FailureCode, p.FailureReason = model.FailRiskDeclined, strings.Join(a.Reasons, "; ")
			return e.move(ctx, tx, p, model.StateDeclined)
		}
		p.RiskApprovedAt = a.At.UTC()
		return tx.SavePayment(ctx, p, p.State, e.now())
	})
	return ok && err == nil, err
}

func sleep(ctx context.Context, d time.Duration) error {
	if d <= 0 {
		return nil
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-t.C:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}
