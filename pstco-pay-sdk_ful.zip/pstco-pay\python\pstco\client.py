"""Clients for the PSTCO-Pay offline HTTP API: ``Client`` (blocking) and
``AsyncClient`` (asyncio). Both sign device requests exactly like the Go SDK,
fetch a server nonce before money-moving calls, and check argument types
before anything is sent.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import secrets
import ssl
import time
from typing import Any, Protocol

import httpx

from .checks import CheckError, binary, boolean, integer, json_types, one_of, text, digits

REQUEST_TAG = "PSTCO-REQ-1\n"
REGISTER_TAG = "PSTCO-REG-1\n"
MAX_AMOUNT = 1_00_00_000_00


class Signer(Protocol):
    def sign_auth(self, msg: bytes) -> bytes: ...


class APIError(Exception):
    def __init__(self, status: int, code: str, message: str):
        self.status, self.code, self.message = status, code, message
        super().__init__(f"pstco api {status} {code}: {message}")


def request_message(method: str, path: str, ts: int, nonce: str, body: bytes) -> bytes:
    return (REQUEST_TAG + method.upper() + "\n" + path + "\n" + str(ts) + "\n" + nonce + "\n"
            + hashlib.sha256(body).hexdigest()).encode()


def register_message(challenge: bytes, token: str, public_key: bytes) -> bytes:
    return (REGISTER_TAG + challenge.hex() + "\n" + hashlib.sha256(token.encode()).hexdigest() + "\n"
            + public_key.hex()).encode()


def b64(b: bytes) -> str:
    return base64.b64encode(b).decode()


def unb64(s: str) -> bytes:
    if type(s) is not str:
        raise CheckError("response", "base64 string", s)
    return base64.b64decode(s, validate=True)


def tls_context(ca_file: str | None) -> ssl.SSLContext:
    ctx = ssl.create_default_context(cafile=ca_file)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_3
    return ctx


class _Base:
    def __init__(self, base_url: str, ca_file: str | None = None, *, signer: Signer | None = None,
                 device_id: int = 0, clock=time.time, timeout: float = 30.0):
        self.base = text("base_url", base_url, 8, 512).rstrip("/")
        self.ca_file, self.signer, self.device_id = ca_file, signer, device_id
        self.clock, self.timeout = clock, timeout

    def _clone(self, device_id: int, signer: Signer):
        c = object.__new__(type(self))
        c.__dict__.update(self.__dict__)
        c.device_id, c.signer = integer("device_id", device_id, 1, (1 << 63) - 1), signer
        return c

    def _prepare(self, method: str, path: str, payload: Any, signed: bool, idem: str = "",
                 nonce: str | None = None) -> tuple[str, dict, bytes]:
        body = b"" if payload is None else json.dumps(payload, separators=(",", ":")).encode()
        headers = {"Content-Type": "application/json"}
        if idem:
            headers["Idempotency-Key"] = idem
        if signed:
            if not self.signer or not self.device_id:
                raise CheckError("device", "a registered device (use with_device)")
            ts = int(self.clock())
            nonce = nonce or secrets.token_hex(16)
            sig = self.signer.sign_auth(request_message(method, path, ts, nonce, body))
            headers.update({"X-Pstco-Device": f"{self.device_id:016x}", "X-Pstco-Timestamp": str(ts),
                            "X-Pstco-Nonce": nonce, "X-Pstco-Signature": b64(sig)})
        return self.base + path, headers, body

    @staticmethod
    def _parse(status: int, data: bytes) -> dict:
        try:
            doc = json.loads(data) if data else {}
        except json.JSONDecodeError as e:
            raise APIError(status, "bad_response", str(e)) from e
        if status // 100 != 2:
            raise APIError(status, doc.get("code", "error"), doc.get("message", ""))
        if type(doc) is not dict:
            raise APIError(status, "bad_response", "expected a JSON object")
        return doc

    # ------------------------------------------- request builders (shared)

    @staticmethod
    def _account_start(phone: str, name: str, listed: bool) -> dict:
        return {"phone": text("phone", phone, 8, 20), "name": text("name", name, 1, 64), "listed": boolean("listed", listed)}

    @staticmethod
    def _account_verify(phone: str, otp: str) -> dict:
        return {"phone": text("phone", phone, 8, 20), "otp": digits("otp", otp, 6, 6)}

    @staticmethod
    def _amount(field: str, v: int, lo: int = 1) -> int:
        return integer(field, v, lo, MAX_AMOUNT)

    @staticmethod
    def _records(records: list[bytes]) -> list[str]:
        if type(records) is not list or not 1 <= len(records) <= 500:
            raise CheckError("records", "a list of 1 to 500 records", records)
        return [b64(binary(f"records[{i}]", r, 114, 114)) for i, r in enumerate(records)]


class Client(_Base):
    """Blocking client (httpx, TLS 1.3, connection reuse)."""

    def __init__(self, base_url: str, ca_file: str | None = None, **kw):
        super().__init__(base_url, ca_file, **kw)
        self._http = httpx.Client(verify=tls_context(ca_file), timeout=self.timeout)

    def close(self) -> None:
        self._http.close()

    def with_device(self, device_id: int, signer: Signer) -> "Client":
        return self._clone(device_id, signer)

    def _do(self, method, path, payload=None, signed=False, idem="", nonce=None) -> dict:
        url, headers, body = self._prepare(method, path, payload, signed, idem, nonce)
        r = self._http.request(method, url, headers=headers, content=body)
        return self._parse(r.status_code, r.content)

    def _money(self, purpose: str, path: str, payload: dict, idem: str) -> dict:
        n = self.auth_nonce(purpose)["nonce"]
        return self._do("POST", path, payload, True, idem, n)

    def start_account(self, phone: str, name: str, listed: bool = False) -> dict:
        return self._do("POST", "/v1/accounts/start", self._account_start(phone, name, listed))

    def verify_account(self, phone: str, otp: str) -> dict:
        return json_types("verify", self._do("POST", "/v1/accounts/verify", self._account_verify(phone, otp)),
                          {"account_id": str, "payee_id": str, "registration_token": str, "expires_in_seconds": int})

    def challenge(self, token: str) -> bytes:
        doc = self._do("POST", "/v1/devices/challenge", {"registration_token": text("token", token, 64, 64)})
        return unb64(doc["challenge"])

    def register(self, req: dict) -> dict:
        return self._do("POST", "/v1/devices/register", req)

    def ca(self) -> bytes:
        return unb64(self._do("GET", "/v1/ca")["public_key"])

    def auth_nonce(self, purpose: str) -> dict:
        return self._do("POST", "/v1/auth/nonce", {"purpose": one_of("purpose", purpose, ("deposit", "reserve"))}, True)

    def deposit(self, amount_paise: int, idem: str | None = None) -> dict:
        return self._money("deposit", "/v1/wallet/deposit", {"amount_paise": self._amount("amount_paise", amount_paise)},
                           idem or secrets.token_hex(16))

    def wallet(self) -> dict:
        return self._do("GET", "/v1/wallet", None, True)

    def create_reserve(self, amount_paise: int, next_counter: int, chain_head: bytes, idem: str) -> dict:
        payload = {"amount_paise": self._amount("amount_paise", amount_paise, 0),
                   "next_counter": integer("next_counter", next_counter, 1, (1 << 32) - 1),
                   "chain_head": b64(binary("chain_head", chain_head, 16, 16))}
        return self._money("reserve", "/v1/reserves", payload, text("idempotency_key", idem, 16, 64))

    def sync(self, records: list[bytes]) -> dict:
        return self._do("POST", "/v1/sync", {"records": self._records(records)}, True)

    def sync_async(self, records: list[bytes]) -> dict:
        return self._do("POST", "/v1/sync?async=1", {"records": self._records(records)}, True)

    def sync_job(self, job_id: str) -> dict:
        return self._do("GET", "/v1/sync/jobs/" + text("job_id", job_id, 4, 64), None, True)

    def wait_sync_job(self, job_id: str, every: float = 0.2, timeout: float = 30.0) -> dict:
        end = time.monotonic() + timeout
        while True:
            j = self.sync_job(job_id)
            if j["status"] == "DONE" or time.monotonic() > end:
                return j
            time.sleep(every)

    def directory(self) -> dict:
        d = self._do("GET", "/v1/directory", None, True)
        return {"payload": unb64(d["payload"]), "signature": unb64(d["signature"])}

    def payment(self, device_id: int, counter: int) -> dict:
        return self._do("GET", f"/v1/offline-payments/{device_id:016x}/{integer('counter', counter, 1)}", None, True)


class AsyncClient(_Base):
    """asyncio client: every call is a coroutine, so many devices or requests
    can run concurrently on one event loop."""

    def __init__(self, base_url: str, ca_file: str | None = None, **kw):
        super().__init__(base_url, ca_file, **kw)
        self._http = httpx.AsyncClient(verify=tls_context(ca_file), timeout=self.timeout)

    async def aclose(self) -> None:
        await self._http.aclose()

    def with_device(self, device_id: int, signer: Signer) -> "AsyncClient":
        return self._clone(device_id, signer)

    async def _do(self, method, path, payload=None, signed=False, idem="", nonce=None) -> dict:
        url, headers, body = self._prepare(method, path, payload, signed, idem, nonce)
        r = await self._http.request(method, url, headers=headers, content=body)
        return self._parse(r.status_code, r.content)

    async def _money(self, purpose: str, path: str, payload: dict, idem: str) -> dict:
        n = (await self.auth_nonce(purpose))["nonce"]
        return await self._do("POST", path, payload, True, idem, n)

    async def start_account(self, phone: str, name: str, listed: bool = False) -> dict:
        return await self._do("POST", "/v1/accounts/start", self._account_start(phone, name, listed))

    async def verify_account(self, phone: str, otp: str) -> dict:
        return await self._do("POST", "/v1/accounts/verify", self._account_verify(phone, otp))

    async def challenge(self, token: str) -> bytes:
        doc = await self._do("POST", "/v1/devices/challenge", {"registration_token": text("token", token, 64, 64)})
        return unb64(doc["challenge"])

    async def register(self, req: dict) -> dict:
        return await self._do("POST", "/v1/devices/register", req)

    async def auth_nonce(self, purpose: str) -> dict:
        return await self._do("POST", "/v1/auth/nonce", {"purpose": one_of("purpose", purpose, ("deposit", "reserve"))}, True)

    async def deposit(self, amount_paise: int, idem: str | None = None) -> dict:
        return await self._money("deposit", "/v1/wallet/deposit",
                                 {"amount_paise": self._amount("amount_paise", amount_paise)}, idem or secrets.token_hex(16))

    async def wallet(self) -> dict:
        return await self._do("GET", "/v1/wallet", None, True)

    async def create_reserve(self, amount_paise: int, next_counter: int, chain_head: bytes, idem: str) -> dict:
        payload = {"amount_paise": self._amount("amount_paise", amount_paise, 0),
                   "next_counter": integer("next_counter", next_counter, 1, (1 << 32) - 1),
                   "chain_head": b64(binary("chain_head", chain_head, 16, 16))}
        return await self._money("reserve", "/v1/reserves", payload, text("idempotency_key", idem, 16, 64))

    async def sync(self, records: list[bytes]) -> dict:
        return await self._do("POST", "/v1/sync", {"records": self._records(records)}, True)

    async def sync_async(self, records: list[bytes]) -> dict:
        return await self._do("POST", "/v1/sync?async=1", {"records": self._records(records)}, True)

    async def sync_job(self, job_id: str) -> dict:
        return await self._do("GET", "/v1/sync/jobs/" + text("job_id", job_id, 4, 64), None, True)

    async def wait_sync_job(self, job_id: str, every: float = 0.2, timeout: float = 30.0) -> dict:
        async def poll():
            while True:
                j = await self.sync_job(job_id)
                if j["status"] == "DONE":
                    return j
                await asyncio.sleep(every)
        return await asyncio.wait_for(poll(), timeout)

    async def directory(self) -> dict:
        d = await self._do("GET", "/v1/directory", None, True)
        return {"payload": unb64(d["payload"]), "signature": unb64(d["signature"])}
