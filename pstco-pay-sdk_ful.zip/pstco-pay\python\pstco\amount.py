"""INR amounts in paise: exact integer arithmetic, 40-bit big-endian encoding.

Money is never a float here. 0.1 + 0.2 != 0.3 in binary floating point, so
a float amount is refused with an explanation instead of being rounded.
"""

from __future__ import annotations

from .checks import CheckError, integer

MAX_PAISE = (1 << 40) - 1  # 1,099,511,627,775 paise, about Rs 1,099.5 crore
AMOUNT_SIZE = 5


def parse_inr(s: str) -> int:
    """'123', '123.4' or '123.45' rupees -> paise. Same rules as the Go SDK."""
    if type(s) is not str:
        raise CheckError("amount", "str rupees such as '123.45'", s)
    whole, dot, frac = s.partition(".")
    if not whole or not whole.isascii() or not whole.isdigit():
        raise CheckError("amount", "rupee digits", s)
    if dot and (not 1 <= len(frac) <= 2 or not frac.isascii() or not frac.isdigit()):
        raise CheckError("amount", "one or two decimals", s)
    if len(whole) > 1 and whole[0] == "0":
        raise CheckError("amount", "no leading zero", s)
    if len(whole) > 11:
        raise CheckError("amount", f"at most {MAX_PAISE} paise", s)
    paise = int(whole) * 100 + int((frac + "00")[:2])
    if paise == 0:
        raise CheckError("amount", "a positive amount", s)
    if paise > MAX_PAISE:
        raise CheckError("amount", f"at most {MAX_PAISE} paise", s)
    return paise


def to_paise(value: int | str) -> int:
    """Accept int paise or str rupees. Floats are refused."""
    if type(value) is float:
        raise CheckError("amount", "int paise or str rupees (floats lose precision for money)", value)
    if type(value) is str:
        return parse_inr(value)
    return integer("amount", value, 1, MAX_PAISE)


def format_rupees(paise: int) -> str:
    integer("paise", paise)
    sign, paise = ("-", -paise) if paise < 0 else ("", paise)
    return f"{sign}{paise // 100}.{paise % 100:02d}"


def encode_amount(paise: int) -> bytes:
    integer("paise", paise, 1, MAX_PAISE)
    return paise.to_bytes(AMOUNT_SIZE, "big")


def decode_amount(b: bytes) -> int:
    if type(b) is not bytes or len(b) != AMOUNT_SIZE:
        raise CheckError("amount bytes", "exactly 5 bytes", b)
    v = int.from_bytes(b, "big")
    if v == 0:
        raise CheckError("amount bytes", "a non-zero amount")
    return v
