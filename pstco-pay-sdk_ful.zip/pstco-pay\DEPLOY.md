# Deploying and integrating PSTCO-Pay

This guide takes PSTCO-Pay from a laptop to a production server, then shows how apps connect to it.

## 1. What you are deploying

One binary, `pstco-server`, runs the whole backend:

| Port (default) | What it serves | Who connects |
|---|---|---|
| 8444 | Offline payment API, HTTPS with TLS 1.3 | Wallet apps: Android, iOS, Python, CLI |
| 8443 | Merchant gRPC API, TLS 1.3 with mutual TLS | Merchant systems taking online card payments |
| 9464 | `/metrics`, `/healthz`, `/transport` | Your monitoring, on a private network only |

State lives in one directory, `-data`:

| File | What it holds | Back it up? |
|---|---|---|
| `pstco.db` (and `-wal`, `-shm`) | All payments, devices, reserves, events (SQLite) | Yes, continuously |
| `service-keys.json` | Signing keys, including the bank CA key devices trust | Yes, encrypted and offline. Losing it breaks every device |
| `anchors.jsonl` | Signed Merkle roots of the event log | Yes, to separate write-once storage |
| `bank-sim.json`, `processor-sim.json` | Simulator state (development only) | No |

Redis is optional. It holds only temporary data: nonces, locks and a cache.

## 2. Run it locally

```powershell
cd pstco-pay
go build -o bin\ ./cmd/...
.\bin\certgen.exe -out certs
.\bin\pstco-server.exe -certs certs -data data -dev-otp
```

In a second terminal, run a payer and a shop:

```powershell
.\bin\pstco-wallet.exe register -dir shop -ca certs\ca.pem -phone 9876500002 -name "Lakshmi Stores" -listed
.\bin\pstco-wallet.exe register -dir asha -ca certs\ca.pem -phone 9876500001 -name Asha
.\bin\pstco-wallet.exe deposit  -dir asha -ca certs\ca.pem -amount 1000
.\bin\pstco-wallet.exe reserve  -dir asha -ca certs\ca.pem -amount 500
.\bin\pstco-wallet.exe pay      -dir asha -ca certs\ca.pem -phone 9876500002 -amount 123.45
.\bin\pstco-wallet.exe accept   -dir shop -ca certs\ca.pem -code <the PSTCO1:... line>
.\bin\pstco-wallet.exe sync     -dir shop -ca certs\ca.pem
```

`-dev-otp` returns the OTP in the API response so you can test without SMS. Never use it in production.

## 3. Deploy to a Linux server

**1. Build** for Linux on any machine:

```bash
GOOS=linux GOARCH=amd64 go build -o dist/ ./cmd/pstco-server
```

To include the C network library, which adds kernel TCP statistics, build on the target with gcc installed:

```bash
CGO_ENABLED=1 go build -o dist/ ./cmd/pstco-server
```

**2. Prepare the host.**

```bash
sudo useradd --system --home /var/lib/pstco pstco
sudo mkdir -p /var/lib/pstco /etc/pstco/certs && sudo chown pstco: /var/lib/pstco
sudo modprobe tcp_bbr && echo tcp_bbr | sudo tee /etc/modules-load.d/bbr.conf   # BBR congestion control
```

**3. Certificates.**

- The offline API (8444) needs a certificate from a public CA, such as Let's Encrypt, so phones trust it without pinning. Put it at `/etc/pstco/certs/server.pem` and `server-key.pem`.
- The merchant API (8443) uses mutual TLS. Issue each merchant a client certificate from your own CA, kept in `ca.pem`.
- `certgen` is for development only.

**4. Secrets**, in `/etc/pstco/env` with mode 0600:

```bash
PSTCO_MERCHANT_SECRET=<random 32+ characters>
PSTCO_SMS_GATEWAY_SECRET=<shared with your SMS aggregator>
PSTCO_REDIS_URL=rediss://user:password@redis.internal:6380/0
```

**5. A systemd service** at `/etc/systemd/system/pstco.service`:

```ini
[Unit]
Description=PSTCO-Pay server
After=network-online.target

[Service]
User=pstco
EnvironmentFile=/etc/pstco/env
ExecStart=/usr/local/bin/pstco-server -data /var/lib/pstco -certs /etc/pstco/certs \
  -listen 0.0.0.0:8443 -offline-listen 0.0.0.0:8444 -metrics 127.0.0.1:9464 \
  -cc bbr -durability full -redis ${PSTCO_REDIS_URL} \
  -android-roots /etc/pstco/roots/google.pem -apple-roots /etc/pstco/roots/apple.pem \
  -apple-app-ids TEAMID.com.example.wallet -sim-roots /etc/pstco/roots/sim.pem
Restart=always
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=/var/lib/pstco
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload && sudo systemctl enable --now pstco
curl -s http://127.0.0.1:9464/healthz      # ok
```

**6. Firewall.** Open 8444 to the internet, and 8443 only to merchant networks. Keep 9464 private.

**7. Backups.** Run `sqlite3 /var/lib/pstco/pstco.db ".backup /backups/pstco-$(date +%F).db"` hourly, or stream changes with Litestream. Keep `service-keys.json` in an HSM or KMS, or at least in encrypted offline storage.

### Production checklist

- [ ] Real Google, Apple and SIM attestation roots configured (`-android-roots`, `-apple-roots`, `-sim-roots`)
- [ ] `-dev-otp` removed, and a real SMS sender wired to `offlinesvc.SMSSender`
- [ ] A real bank integration replacing `internal/bank`, behind the `offlinesvc.Bank` interface
- [ ] Offline limits in `offlinesvc.Policy` set to the current RBI caps
- [ ] Redis with password and TLS (`rediss://`), because it caches merchant secrets
- [ ] `-durability full` on a local SSD, not a network or synced folder
- [ ] Database, keys and anchor log backed up, and a restore tested

## 4. Integrate an app

| Your app | Use | Start with |
|---|---|---|
| Go service or CLI | `sdk/wallet`, `sdk/client` | [SDK.md](SDK.md) "Use it from Go" |
| Android or iOS | `sdk/mobile` through gomobile | [SDK.md](SDK.md) "Use it from Android and iOS" |
| Python service, kiosk or test | `python/pstco` | [python/README.md](python/README.md) |
| Any other language | HTTPS API | [SDK.md](SDK.md) "Use it from any language" |
| Online card payments | gRPC merchant API | `sdk/merchant` and [proto/pstco/v1/payment.proto](proto/pstco/v1/payment.proto) |

Every integration follows the same lifecycle:

1. **Verify the phone.** `StartAccount`, then `VerifyAccount` with the SMS code.
2. **Register the device.** `Register` uses hardware attestation when available and software trust otherwise.
3. **Fund it.** Approve, then `Deposit`. Approve again, then `CreateReserve`.
4. **Pay offline.** Approve, then `Pay`. Show the QR code, or queue the SMS.
5. **Accept offline.** On the payee's phone, `Accept` verifies the payment with no network.
6. **Sync.** `Sync` whenever there is signal, or `SyncAsync` to submit and continue.

Every money step needs an approval: the user re-confirms with a PIN or biometric, which yields a single-use 256-bit token for that exact amount and payee. Deposits and reserves also carry a single-use server nonce. The SDKs fetch it for you.

## 5. Scale out

- **More instances.** Run several `pstco-server` processes against one database file on one host, with `-redis` shared between them, behind a TCP load balancer. Redis locks keep one payment from being processed by two instances.
- **More than one host.** You need a networked database in place of SQLite. The `store` package is the only place to change.
- **Monitoring.** Watch `/metrics`. Alert on `pstco_csdr_decisions_total{decision="integrity_stop"}`, on reconciliation discrepancies, and on `security_events` rows for frozen devices and lockouts.
