// Package store is the authoritative, durable state of PSTCO-Pay: payments,
// the append-only execution graph, operation idempotency records, the
// transactional settlement outbox, settlement and reconciliation records.
//
// It uses embedded SQLite (pure Go, no cgo) in WAL mode with a single writer
// connection, which gives serialisable transactions without an external
// database server.
package store

import (
	"context"
	"database/sql"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	_ "modernc.org/sqlite"

	"pstcopay/internal/chain"
	"pstcopay/internal/fsm"
	"pstcopay/internal/model"
)

var (
	ErrNotFound  = errors.New("store: not found")
	ErrDuplicate = errors.New("store: duplicate")
	ErrConflict  = errors.New("store: concurrent modification")
)

const schema = `
CREATE TABLE IF NOT EXISTS merchants (
  id TEXT PRIMARY KEY,
  secret TEXT NOT NULL,
  principal TEXT NOT NULL,
  active INTEGER NOT NULL,
  max_amount_minor INTEGER NOT NULL,
  allow_reauth INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  merchant_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  request_hash TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL,
  card_token TEXT NOT NULL,
  client_time INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  deadline_ms INTEGER NOT NULL,
  signature TEXT NOT NULL,
  principal TEXT NOT NULL,
  state TEXT NOT NULL,
  failure_code TEXT NOT NULL DEFAULT '',
  failure_reason TEXT NOT NULL DEFAULT '',
  risk_score REAL NOT NULL DEFAULT 0,
  risk_decision TEXT NOT NULL DEFAULT '',
  risk_approved_at INTEGER NOT NULL DEFAULT 0,
  auth_id TEXT NOT NULL DEFAULT '',
  auth_key TEXT NOT NULL DEFAULT '',
  authorized_at INTEGER NOT NULL DEFAULT 0,
  capture_id TEXT NOT NULL DEFAULT '',
  captured_at INTEGER NOT NULL DEFAULT 0,
  settlement_id TEXT NOT NULL DEFAULT '',
  settled_at INTEGER NOT NULL DEFAULT 0,
  refund_id TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  version INTEGER NOT NULL,
  UNIQUE (merchant_id, idempotency_key)
);
CREATE INDEX IF NOT EXISTS payments_state ON payments(state, updated_at);

CREATE TABLE IF NOT EXISTS payment_stage_events (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id TEXT NOT NULL UNIQUE,
  payment_id TEXT NOT NULL REFERENCES payments(id),
  seq INTEGER NOT NULL,
  stage TEXT NOT NULL,
  attempt_number INTEGER NOT NULL,
  status TEXT NOT NULL,
  previous_event_hash TEXT NOT NULL,
  dependency_hashes TEXT NOT NULL,
  retry_of_event_hash TEXT NOT NULL,
  payload TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  nonce_reference TEXT NOT NULL,
  workflow_version TEXT NOT NULL,
  signer TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  current_hash TEXT NOT NULL UNIQUE,
  signature TEXT NOT NULL,
  UNIQUE (payment_id, seq)
);
CREATE TRIGGER IF NOT EXISTS events_append_only_update
BEFORE UPDATE ON payment_stage_events
BEGIN SELECT RAISE(ABORT, 'payment_stage_events is append-only'); END;
CREATE TRIGGER IF NOT EXISTS events_append_only_delete
BEFORE DELETE ON payment_stage_events
BEGIN SELECT RAISE(ABORT, 'payment_stage_events is append-only'); END;

CREATE TABLE IF NOT EXISTS payment_idempotency (
  op_key TEXT PRIMARY KEY,
  payment_id TEXT NOT NULL,
  operation TEXT NOT NULL,
  status TEXT NOT NULL,
  downstream_ref TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS settlement_outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id TEXT NOT NULL UNIQUE,
  capture_id TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL,
  status TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at INTEGER NOT NULL,
  last_error TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS outbox_due ON settlement_outbox(status, next_attempt_at);

CREATE TABLE IF NOT EXISTS settlement_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  payment_id TEXT NOT NULL UNIQUE,
  settlement_id TEXT NOT NULL,
  capture_id TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL,
  settled_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS reconciliation_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL,
  payment_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  detail TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS anchors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_row_id INTEGER NOT NULL,
  to_row_id INTEGER NOT NULL,
  root TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
`

type querier interface {
	ExecContext(ctx context.Context, query string, args ...any) (sql.Result, error)
	QueryContext(ctx context.Context, query string, args ...any) (*sql.Rows, error)
	QueryRowContext(ctx context.Context, query string, args ...any) *sql.Row
}

// Queries holds every data-access method. Store runs them on the database;
// Tx runs them inside a transaction.
type Queries struct{ q querier }

// Store is the database handle. Writes and transactions go through a single
// writer connection; reads outside transactions use a separate read-only pool,
// which WAL mode lets run concurrently with the writer.
type Store struct {
	Queries
	db  *sql.DB
	rdb *sql.DB
}

// splitQuerier sends reads to the read pool and writes to the writer.
type splitQuerier struct{ r, w *sql.DB }

func (s splitQuerier) ExecContext(ctx context.Context, q string, args ...any) (sql.Result, error) {
	return s.w.ExecContext(ctx, q, args...)
}
func (s splitQuerier) QueryContext(ctx context.Context, q string, args ...any) (*sql.Rows, error) {
	return s.r.QueryContext(ctx, q, args...)
}
func (s splitQuerier) QueryRowContext(ctx context.Context, q string, args ...any) *sql.Row {
	return s.r.QueryRowContext(ctx, q, args...)
}

// Durability modes.
const (
	// DurabilityFull fsyncs every commit: a commit survives power loss.
	DurabilityFull = "full"
	// DurabilityNormal (WAL + synchronous=NORMAL) survives process crashes; the
	// last commits can be lost on power failure or OS crash.
	DurabilityNormal = "normal"
)

// Tx is an open transaction.
type Tx struct {
	Queries
	tx *sql.Tx
}

// Open opens (and migrates) the SQLite database at path with full durability.
func Open(path string) (*Store, error) { return OpenWith(path, DurabilityFull) }

// OpenWith opens the database with the given durability mode.
func OpenWith(path, durability string) (*Store, error) {
	sync := "FULL"
	switch durability {
	case DurabilityFull, "":
	case DurabilityNormal:
		sync = "NORMAL"
	default:
		return nil, fmt.Errorf("store: unknown durability %q", durability)
	}
	base := "file:" + path + "?_pragma=journal_mode(WAL)&_pragma=busy_timeout(10000)&_pragma=foreign_keys(1)"
	// _txlock=immediate: every transaction takes the write lock at BEGIN, so a
	// second process sharing the file waits (busy_timeout) instead of failing
	// a read-to-write lock upgrade with SQLITE_BUSY.
	db, err := sql.Open("sqlite", base+"&_pragma=synchronous("+sync+")&_txlock=immediate")
	if err != nil {
		return nil, err
	}
	// One writer connection: SQLite has a single writer, and this keeps every
	// transaction serialisable without lock-upgrade deadlocks.
	db.SetMaxOpenConns(1)
	if _, err := db.Exec(schema + offlineSchema); err != nil {
		db.Close()
		return nil, fmt.Errorf("store: migrate: %w", err)
	}
	// Migration: anchors gained a log column (online/offline).
	if _, err := db.Exec(`ALTER TABLE anchors ADD COLUMN log TEXT NOT NULL DEFAULT 'online'`); err != nil &&
		!strings.Contains(err.Error(), "duplicate column") {
		db.Close()
		return nil, fmt.Errorf("store: migrate anchors: %w", err)
	}
	rdb, err := sql.Open("sqlite", base+"&_pragma=query_only(1)")
	if err != nil {
		db.Close()
		return nil, err
	}
	rdb.SetMaxOpenConns(8)
	return &Store{Queries: Queries{q: splitQuerier{r: rdb, w: db}}, db: db, rdb: rdb}, nil
}

// Close closes the database.
func (s *Store) Close() error { return errors.Join(s.rdb.Close(), s.db.Close()) }

// DB exposes the raw handle (used by tests to simulate tampering).
func (s *Store) DB() *sql.DB { return s.db }

// Ping checks database connectivity.
func (s *Store) Ping(ctx context.Context) error { return s.db.PingContext(ctx) }

// WithTx runs fn in a transaction, committing on nil error.
func (s *Store) WithTx(ctx context.Context, fn func(tx *Tx) error) error {
	t, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	if err := fn(&Tx{Queries: Queries{q: t}, tx: t}); err != nil {
		_ = t.Rollback()
		return err
	}
	return t.Commit()
}

func ns(t time.Time) int64 {
	if t.IsZero() {
		return 0
	}
	return t.UnixNano()
}

func fromNS(v int64) time.Time {
	if v == 0 {
		return time.Time{}
	}
	return time.Unix(0, v).UTC()
}

func isUnique(err error) bool {
	return err != nil && strings.Contains(err.Error(), "UNIQUE constraint failed")
}

// ---------------------------------------------------------------- merchants

// UpsertMerchant inserts or replaces a merchant.
func (q Queries) UpsertMerchant(ctx context.Context, m *model.Merchant) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO merchants(id, secret, principal, active, max_amount_minor, allow_reauth)
		VALUES(?,?,?,?,?,?)
		ON CONFLICT(id) DO UPDATE SET secret=excluded.secret, principal=excluded.principal,
		active=excluded.active, max_amount_minor=excluded.max_amount_minor, allow_reauth=excluded.allow_reauth`,
		m.ID, m.Secret, m.Principal, m.Active, m.MaxAmountMinor, m.AllowReauth)
	return err
}

// GetMerchant loads a merchant.
func (q Queries) GetMerchant(ctx context.Context, id string) (*model.Merchant, error) {
	var m model.Merchant
	err := q.q.QueryRowContext(ctx, `SELECT id, secret, principal, active, max_amount_minor, allow_reauth
		FROM merchants WHERE id=?`, id).Scan(&m.ID, &m.Secret, &m.Principal, &m.Active, &m.MaxAmountMinor, &m.AllowReauth)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	return &m, err
}

// ----------------------------------------------------------------- payments

const paymentCols = `id, merchant_id, customer_id, idempotency_key, request_hash, amount_minor, currency,
	card_token, client_time, expires_at, deadline_ms, signature, principal, state, failure_code,
	failure_reason, risk_score, risk_decision, risk_approved_at, auth_id, auth_key, authorized_at,
	capture_id, captured_at, settlement_id, settled_at, refund_id, created_at, updated_at, version`

type scanner interface{ Scan(dest ...any) error }

func scanPayment(r scanner) (*model.Payment, error) {
	var p model.Payment
	var clientTime, expires, riskAt, authAt, capAt, setAt, created, updated int64
	var state, fcode string
	err := r.Scan(&p.ID, &p.MerchantID, &p.CustomerID, &p.IdempotencyKey, &p.RequestHash, &p.AmountMinor,
		&p.Currency, &p.CardToken, &clientTime, &expires, &p.DeadlineMS, &p.Signature, &p.Principal,
		&state, &fcode, &p.FailureReason, &p.RiskScore, &p.RiskDecision, &riskAt, &p.AuthID, &p.AuthKey,
		&authAt, &p.CaptureID, &capAt, &p.SettlementID, &setAt, &p.RefundID, &created, &updated, &p.Version)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, err
	}
	p.State, p.FailureCode = model.State(state), model.FailureCode(fcode)
	p.ClientTime, p.ExpiresAt, p.RiskApprovedAt = fromNS(clientTime), fromNS(expires), fromNS(riskAt)
	p.AuthorizedAt, p.CapturedAt, p.SettledAt = fromNS(authAt), fromNS(capAt), fromNS(setAt)
	p.CreatedAt, p.UpdatedAt = fromNS(created), fromNS(updated)
	return &p, nil
}

// InsertPayment creates a payment. It returns ErrDuplicate when the
// (merchant_id, idempotency_key) pair already exists.
func (q Queries) InsertPayment(ctx context.Context, p *model.Payment) error {
	p.Version = 1
	_, err := q.q.ExecContext(ctx, `INSERT INTO payments(`+paymentCols+`) VALUES
		(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
		p.ID, p.MerchantID, p.CustomerID, p.IdempotencyKey, p.RequestHash, p.AmountMinor, p.Currency,
		p.CardToken, ns(p.ClientTime), ns(p.ExpiresAt), p.DeadlineMS, p.Signature, p.Principal,
		string(p.State), string(p.FailureCode), p.FailureReason, p.RiskScore, p.RiskDecision,
		ns(p.RiskApprovedAt), p.AuthID, p.AuthKey, ns(p.AuthorizedAt), p.CaptureID, ns(p.CapturedAt),
		p.SettlementID, ns(p.SettledAt), p.RefundID, ns(p.CreatedAt), ns(p.UpdatedAt), p.Version)
	if isUnique(err) {
		return ErrDuplicate
	}
	return err
}

// GetPayment loads a payment by id.
func (q Queries) GetPayment(ctx context.Context, id string) (*model.Payment, error) {
	return scanPayment(q.q.QueryRowContext(ctx, `SELECT `+paymentCols+` FROM payments WHERE id=?`, id))
}

// GetPaymentByIdempotency loads a payment by merchant and request idempotency key.
func (q Queries) GetPaymentByIdempotency(ctx context.Context, merchantID, key string) (*model.Payment, error) {
	return scanPayment(q.q.QueryRowContext(ctx,
		`SELECT `+paymentCols+` FROM payments WHERE merchant_id=? AND idempotency_key=?`, merchantID, key))
}

// SavePayment persists p after checking that prev -> p.State is a legal
// transition and that nobody else modified the row (optimistic locking).
func (q Queries) SavePayment(ctx context.Context, p *model.Payment, prev model.State, now time.Time) error {
	if prev != p.State {
		if err := fsm.Check(prev, p.State); err != nil {
			return err
		}
	}
	p.UpdatedAt = now
	res, err := q.q.ExecContext(ctx, `UPDATE payments SET state=?, failure_code=?, failure_reason=?,
		risk_score=?, risk_decision=?, risk_approved_at=?, auth_id=?, auth_key=?, authorized_at=?,
		capture_id=?, captured_at=?, settlement_id=?, settled_at=?, refund_id=?, principal=?,
		updated_at=?, version=version+1
		WHERE id=? AND state=? AND version=?`,
		string(p.State), string(p.FailureCode), p.FailureReason, p.RiskScore, p.RiskDecision,
		ns(p.RiskApprovedAt), p.AuthID, p.AuthKey, ns(p.AuthorizedAt), p.CaptureID, ns(p.CapturedAt),
		p.SettlementID, ns(p.SettledAt), p.RefundID, p.Principal, ns(p.UpdatedAt),
		p.ID, string(prev), p.Version)
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n != 1 {
		return ErrConflict
	}
	p.Version++
	return nil
}

// ListPaymentsByState returns payments in any of the given states, oldest first.
func (q Queries) ListPaymentsByState(ctx context.Context, limit int, states ...model.State) ([]*model.Payment, error) {
	if len(states) == 0 {
		return nil, nil
	}
	ph := strings.TrimSuffix(strings.Repeat("?,", len(states)), ",")
	args := make([]any, 0, len(states)+1)
	for _, s := range states {
		args = append(args, string(s))
	}
	args = append(args, limit)
	rows, err := q.q.QueryContext(ctx, `SELECT `+paymentCols+` FROM payments WHERE state IN (`+ph+`)
		ORDER BY updated_at LIMIT ?`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*model.Payment
	for rows.Next() {
		p, err := scanPayment(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, p)
	}
	return out, rows.Err()
}

// CountRecentByCustomer counts payments for a customer created after since.
func (q Queries) CountRecentByCustomer(ctx context.Context, customerID string, since time.Time) (int, error) {
	var n int
	err := q.q.QueryRowContext(ctx, `SELECT COUNT(*) FROM payments WHERE customer_id=? AND created_at>=?`,
		customerID, ns(since)).Scan(&n)
	return n, err
}

// ------------------------------------------------------------------- events

const eventCols = `row_id, event_id, payment_id, seq, stage, attempt_number, status, previous_event_hash,
	dependency_hashes, retry_of_event_hash, payload, payload_hash, idempotency_key, nonce_reference,
	workflow_version, signer, created_at, current_hash, signature`

func scanEvent(r scanner) (*chain.Event, error) {
	var e chain.Event
	var stage, status, deps, payload string
	if err := r.Scan(&e.RowID, &e.EventID, &e.PaymentID, &e.Seq, &stage, &e.Attempt, &status,
		&e.PreviousEventHash, &deps, &e.RetryOfEventHash, &payload, &e.PayloadHash, &e.IdempotencyKey,
		&e.NonceReference, &e.WorkflowVersion, &e.Signer, &e.CreatedAt, &e.CurrentHash, &e.Signature); err != nil {
		return nil, err
	}
	e.Stage, e.Status = model.Stage(stage), model.EventStatus(status)
	if err := json.Unmarshal([]byte(deps), &e.DependencyHashes); err != nil {
		return nil, fmt.Errorf("event %s: dependency_hashes: %w", e.EventID, err)
	}
	if err := json.Unmarshal([]byte(payload), &e.Payload); err != nil {
		return nil, fmt.Errorf("event %s: payload: %w", e.EventID, err)
	}
	return &e, nil
}

// AppendEvent links a new event to the payment's latest event. build receives
// the previous hash and next sequence number and must return a sealed event.
// Call it inside a transaction so the read of the tail and the insert are atomic.
func (q Queries) AppendEvent(ctx context.Context, paymentID string,
	build func(prevHash string, seq int64) (*chain.Event, error)) (*chain.Event, error) {
	return q.appendEventIn(ctx, "payment_stage_events", paymentID, build)
}

// AppendOfflineEvent appends to an offline payment's server-side event chain.
func (q Queries) AppendOfflineEvent(ctx context.Context, key string,
	build func(prevHash string, seq int64) (*chain.Event, error)) (*chain.Event, error) {
	return q.appendEventIn(ctx, "offline_events", key, build)
}

func (q Queries) appendEventIn(ctx context.Context, table, paymentID string,
	build func(prevHash string, seq int64) (*chain.Event, error)) (*chain.Event, error) {
	prev, seq := chain.GenesisHash, int64(1)
	var lastSeq int64
	var lastHash string
	err := q.q.QueryRowContext(ctx, `SELECT seq, current_hash FROM `+table+`
		WHERE payment_id=? ORDER BY seq DESC LIMIT 1`, paymentID).Scan(&lastSeq, &lastHash)
	switch {
	case err == nil:
		prev, seq = lastHash, lastSeq+1
	case errors.Is(err, sql.ErrNoRows):
	default:
		return nil, err
	}
	ev, err := build(prev, seq)
	if err != nil {
		return nil, err
	}
	deps, _ := json.Marshal(nonNil(ev.DependencyHashes))
	payload, _ := json.Marshal(ev.Payload)
	res, err := q.q.ExecContext(ctx, `INSERT INTO `+table+`(event_id, payment_id, seq, stage,
		attempt_number, status, previous_event_hash, dependency_hashes, retry_of_event_hash, payload,
		payload_hash, idempotency_key, nonce_reference, workflow_version, signer, created_at, current_hash,
		signature) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
		ev.EventID, ev.PaymentID, ev.Seq, string(ev.Stage), ev.Attempt, string(ev.Status),
		ev.PreviousEventHash, string(deps), ev.RetryOfEventHash, string(payload), ev.PayloadHash,
		ev.IdempotencyKey, ev.NonceReference, ev.WorkflowVersion, ev.Signer, ev.CreatedAt,
		ev.CurrentHash, ev.Signature)
	if err != nil {
		return nil, err
	}
	ev.RowID, _ = res.LastInsertId()
	return ev, nil
}

func nonNil(s []string) []string {
	if s == nil {
		return []string{}
	}
	return s
}

// ListEvents returns a payment's events in sequence order.
func (q Queries) ListEvents(ctx context.Context, paymentID string) ([]*chain.Event, error) {
	return q.listEventsIn(ctx, "payment_stage_events", paymentID)
}

// ListOfflineEvents returns an offline payment's server-side events.
func (q Queries) ListOfflineEvents(ctx context.Context, key string) ([]*chain.Event, error) {
	return q.listEventsIn(ctx, "offline_events", key)
}

func (q Queries) listEventsIn(ctx context.Context, table, paymentID string) ([]*chain.Event, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT `+eventCols+` FROM `+table+`
		WHERE payment_id=? ORDER BY seq`, paymentID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*chain.Event
	for rows.Next() {
		e, err := scanEvent(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}

// EventHashesAfter returns (row_id, current_hash) for rows in (after, upTo].
// Anchor logs: each append-only event table is anchored separately.
const (
	LogOnline  = "online"  // payment_stage_events
	LogOffline = "offline" // offline_events
)

func logTable(log string) string {
	if log == LogOffline {
		return "offline_events"
	}
	return "payment_stage_events"
}

func (q Queries) EventHashesAfter(ctx context.Context, after, upTo int64) ([]int64, []string, error) {
	return q.EventHashesIn(ctx, LogOnline, after, upTo)
}

// EventHashesIn returns (row_id, current_hash) for rows in (after, upTo] of a log.
func (q Queries) EventHashesIn(ctx context.Context, log string, after, upTo int64) ([]int64, []string, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT row_id, current_hash FROM `+logTable(log)+`
		WHERE row_id>? AND row_id<=? ORDER BY row_id`, after, upTo)
	if err != nil {
		return nil, nil, err
	}
	defer rows.Close()
	var ids []int64
	var hs []string
	for rows.Next() {
		var id int64
		var h string
		if err := rows.Scan(&id, &h); err != nil {
			return nil, nil, err
		}
		ids, hs = append(ids, id), append(hs, h)
	}
	return ids, hs, rows.Err()
}

// MaxEventRowID returns the highest event row id (0 when empty).
func (q Queries) MaxEventRowID(ctx context.Context) (int64, error) {
	return q.MaxEventRowIDIn(ctx, LogOnline)
}

// MaxEventRowIDIn returns the highest row id of a log (0 when empty).
func (q Queries) MaxEventRowIDIn(ctx context.Context, log string) (int64, error) {
	var v sql.NullInt64
	err := q.q.QueryRowContext(ctx, `SELECT MAX(row_id) FROM `+logTable(log)).Scan(&v)
	return v.Int64, err
}

// LastAnchoredRowID returns the to_row_id of the latest anchor.
func (q Queries) LastAnchoredRowID(ctx context.Context) (int64, error) {
	return q.LastAnchoredRowIDFor(ctx, LogOnline)
}

// LastAnchoredRowIDFor returns the to_row_id of a log's latest anchor.
func (q Queries) LastAnchoredRowIDFor(ctx context.Context, log string) (int64, error) {
	var v sql.NullInt64
	err := q.q.QueryRowContext(ctx, `SELECT MAX(to_row_id) FROM anchors WHERE log=?`, log).Scan(&v)
	return v.Int64, err
}

// InsertAnchor records an anchor.
func (q Queries) InsertAnchor(ctx context.Context, a *chain.Anchor) error {
	log := a.Log
	if log == "" {
		log = LogOnline
	}
	_, err := q.q.ExecContext(ctx, `INSERT INTO anchors(from_row_id, to_row_id, root, created_at, log) VALUES (?,?,?,?,?)`,
		a.FromRowID, a.ToRowID, a.Root, a.CreatedAt, log)
	return err
}

// -------------------------------------------------------------- idempotency

// Idempotency record statuses.
const (
	IdemStarted        = "STARTED"
	IdemCompleted      = "COMPLETED"
	IdemDeclined       = "DECLINED"
	IdemFailedNoEffect = "FAILED_NO_EFFECT"
	IdemUnknown        = "UNKNOWN"
)

// IdemRecord tracks one logical downstream financial operation.
type IdemRecord struct {
	OpKey, PaymentID, Operation, Status, DownstreamRef string
	CreatedAt, UpdatedAt                               time.Time
}

// PutIdempotency inserts or updates an operation record.
func (q Queries) PutIdempotency(ctx context.Context, r *IdemRecord, now time.Time) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO payment_idempotency(op_key, payment_id, operation, status,
		downstream_ref, created_at, updated_at) VALUES (?,?,?,?,?,?,?)
		ON CONFLICT(op_key) DO UPDATE SET status=excluded.status,
		downstream_ref=CASE WHEN excluded.downstream_ref<>'' THEN excluded.downstream_ref ELSE downstream_ref END,
		updated_at=excluded.updated_at`,
		r.OpKey, r.PaymentID, r.Operation, r.Status, r.DownstreamRef, ns(now), ns(now))
	return err
}

// GetIdempotency loads an operation record.
func (q Queries) GetIdempotency(ctx context.Context, key string) (*IdemRecord, error) {
	var r IdemRecord
	var c, u int64
	err := q.q.QueryRowContext(ctx, `SELECT op_key, payment_id, operation, status, downstream_ref, created_at,
		updated_at FROM payment_idempotency WHERE op_key=?`, key).
		Scan(&r.OpKey, &r.PaymentID, &r.Operation, &r.Status, &r.DownstreamRef, &c, &u)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	r.CreatedAt, r.UpdatedAt = fromNS(c), fromNS(u)
	return &r, err
}

// ------------------------------------------------------------------- outbox

// Outbox statuses.
const (
	OutboxPending    = "PENDING"
	OutboxProcessing = "PROCESSING"
	OutboxPublished  = "PUBLISHED"
	OutboxFailed     = "FAILED"
	OutboxCancelled  = "CANCELLED"
)

// OutboxItem is one durable settlement instruction.
type OutboxItem struct {
	ID            int64
	PaymentID     string
	CaptureID     string
	AmountMinor   int64
	Currency      string
	Status        string
	Attempts      int
	NextAttemptAt time.Time
	LastError     string
	CreatedAt     time.Time
	UpdatedAt     time.Time
}

const outboxCols = `id, payment_id, capture_id, amount_minor, currency, status, attempts, next_attempt_at,
	last_error, created_at, updated_at`

func scanOutbox(r scanner) (*OutboxItem, error) {
	var o OutboxItem
	var next, c, u int64
	err := r.Scan(&o.ID, &o.PaymentID, &o.CaptureID, &o.AmountMinor, &o.Currency, &o.Status, &o.Attempts,
		&next, &o.LastError, &c, &u)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	o.NextAttemptAt, o.CreatedAt, o.UpdatedAt = fromNS(next), fromNS(c), fromNS(u)
	return &o, err
}

// InsertOutbox enqueues a settlement instruction (inside the capture transaction).
func (q Queries) InsertOutbox(ctx context.Context, o *OutboxItem, now time.Time) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO settlement_outbox(payment_id, capture_id, amount_minor, currency,
		status, attempts, next_attempt_at, created_at, updated_at) VALUES (?,?,?,?,?,0,?,?,?)`,
		o.PaymentID, o.CaptureID, o.AmountMinor, o.Currency, OutboxPending, ns(now), ns(now), ns(now))
	if isUnique(err) {
		return ErrDuplicate
	}
	return err
}

// DueOutbox returns pending items whose next attempt is due.
func (q Queries) DueOutbox(ctx context.Context, now time.Time, limit int) ([]*OutboxItem, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT `+outboxCols+` FROM settlement_outbox
		WHERE status IN (?, ?) AND next_attempt_at<=? ORDER BY next_attempt_at LIMIT ?`,
		OutboxPending, OutboxProcessing, ns(now), limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*OutboxItem
	for rows.Next() {
		o, err := scanOutbox(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, o)
	}
	return out, rows.Err()
}

// GetOutboxByPayment loads the outbox item of a payment.
func (q Queries) GetOutboxByPayment(ctx context.Context, paymentID string) (*OutboxItem, error) {
	return scanOutbox(q.q.QueryRowContext(ctx, `SELECT `+outboxCols+` FROM settlement_outbox WHERE payment_id=?`, paymentID))
}

// UpdateOutbox sets status, attempts, next attempt and last error.
// When fromStatus is non-empty the update only applies if the row is in it.
func (q Queries) UpdateOutbox(ctx context.Context, id int64, fromStatus, status string, attempts int,
	next time.Time, lastErr string, now time.Time) (bool, error) {
	query := `UPDATE settlement_outbox SET status=?, attempts=?, next_attempt_at=?, last_error=?, updated_at=? WHERE id=?`
	args := []any{status, attempts, ns(next), lastErr, ns(now), id}
	if fromStatus != "" {
		query += ` AND status=?`
		args = append(args, fromStatus)
	}
	res, err := q.q.ExecContext(ctx, query, args...)
	if err != nil {
		return false, err
	}
	n, _ := res.RowsAffected()
	return n == 1, nil
}

// ListOutbox returns all outbox items.
func (q Queries) ListOutbox(ctx context.Context) ([]*OutboxItem, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT `+outboxCols+` FROM settlement_outbox ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*OutboxItem
	for rows.Next() {
		o, err := scanOutbox(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, o)
	}
	return out, rows.Err()
}

// -------------------------------------------------------------- settlements

// SettlementRecord is an internally confirmed settlement.
type SettlementRecord struct {
	PaymentID, SettlementID, CaptureID string
	AmountMinor                        int64
	Currency                           string
	SettledAt                          time.Time
}

// InsertSettlement records a confirmed settlement.
func (q Queries) InsertSettlement(ctx context.Context, r *SettlementRecord) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO settlement_records(payment_id, settlement_id, capture_id,
		amount_minor, currency, settled_at) VALUES (?,?,?,?,?,?)`,
		r.PaymentID, r.SettlementID, r.CaptureID, r.AmountMinor, r.Currency, ns(r.SettledAt))
	if isUnique(err) {
		return ErrDuplicate
	}
	return err
}

// ListSettlements returns every settlement record.
func (q Queries) ListSettlements(ctx context.Context) ([]*SettlementRecord, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT payment_id, settlement_id, capture_id, amount_minor, currency,
		settled_at FROM settlement_records ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*SettlementRecord
	for rows.Next() {
		var r SettlementRecord
		var at int64
		if err := rows.Scan(&r.PaymentID, &r.SettlementID, &r.CaptureID, &r.AmountMinor, &r.Currency, &at); err != nil {
			return nil, err
		}
		r.SettledAt = fromNS(at)
		out = append(out, &r)
	}
	return out, rows.Err()
}

// ----------------------------------------------------------- reconciliation

// ReconRecord is one discrepancy found by a reconciliation run.
type ReconRecord struct {
	RunID, PaymentID, Kind, Detail string
	CreatedAt                      time.Time
}

// InsertRecon records a discrepancy.
func (q Queries) InsertRecon(ctx context.Context, r *ReconRecord) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO reconciliation_records(run_id, payment_id, kind, detail, created_at)
		VALUES (?,?,?,?,?)`, r.RunID, r.PaymentID, r.Kind, r.Detail, ns(r.CreatedAt))
	return err
}

// ListRecon returns discrepancies of one run (or all runs when runID is empty).
func (q Queries) ListRecon(ctx context.Context, runID string) ([]*ReconRecord, error) {
	query := `SELECT run_id, payment_id, kind, detail, created_at FROM reconciliation_records`
	var args []any
	if runID != "" {
		query += ` WHERE run_id=?`
		args = append(args, runID)
	}
	rows, err := q.q.QueryContext(ctx, query+` ORDER BY id`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*ReconRecord
	for rows.Next() {
		var r ReconRecord
		var at int64
		if err := rows.Scan(&r.RunID, &r.PaymentID, &r.Kind, &r.Detail, &at); err != nil {
			return nil, err
		}
		r.CreatedAt = fromNS(at)
		out = append(out, &r)
	}
	return out, rows.Err()
}
