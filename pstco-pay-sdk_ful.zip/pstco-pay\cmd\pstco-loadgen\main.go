// Command pstco-loadgen drives concurrent payments through a small pool of
// persistent, multiplexed connections and writes one CSV row per payment,
// which the Python models in ml/ use for deadline prediction and
// network-performance analysis.
package main

import (
	"context"
	"crypto/rand"
	"encoding/csv"
	"encoding/hex"
	"flag"
	"fmt"
	mrand "math/rand/v2"
	"os"
	"slices"
	"strconv"
	"sync"
	"sync/atomic"
	"time"

	"google.golang.org/grpc/status"

	rpc "pstcopay/sdk/merchant"
)

type row struct {
	start                   time.Time
	worker                  int
	paymentID, state, fcode string
	amount                  int64
	clientInflight          int64
	latency                 time.Duration
	v                       *rpc.PaymentView
	errCode                 string
}

func main() {
	var (
		addr     = flag.String("addr", "localhost:8443", "server address")
		certs    = flag.String("certs", "certs", "certificate directory")
		cert     = flag.String("cert", "merchant-demo", "client certificate name")
		merchant = flag.String("merchant", "merchant_demo", "merchant id")
		secret   = flag.String("secret", envOr("PSTCO_MERCHANT_SECRET", "demo-merchant-secret"), "merchant signing secret")
		n        = flag.Int("n", 2000, "total payments")
		c        = flag.Int("c", 64, "concurrent workers (concurrent HTTP/2 streams)")
		conns    = flag.Int("conns", 1, "persistent TCP connections in the pool")
		cc       = flag.String("cc", "", "client-side congestion control (Linux only)")
		label    = flag.String("label", "run", "label stored in the CSV, e.g. bbr or cubic")
		deadline = flag.Int64("deadline-ms", 3000, "fast-path deadline per payment")
		declines = flag.Float64("decline-rate", 0.02, "fraction of payments using a declining card")
		out      = flag.String("out", "loadgen.csv", "CSV output path (empty disables)")
		appendTo = flag.Bool("append", false, "append to the CSV instead of overwriting")
	)
	flag.Parse()

	cl, err := rpc.DialCertDir(*addr, *certs, *cert, *conns, *cc)
	if err != nil {
		fmt.Fprintln(os.Stderr, "dial:", err)
		os.Exit(1)
	}
	defer cl.Close()

	runID := randHex(4)
	var next, inflight atomic.Int64
	rows := make([]row, 0, *n)
	var mu sync.Mutex
	var wg sync.WaitGroup
	began := time.Now()
	for w := range *c {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				i := next.Add(1)
				if i > int64(*n) {
					return
				}
				amount := 100_00 + mrand.Int64N(50_000_00)
				cust := mrand.IntN(5000)
				token := fmt.Sprintf("tok_card_%d", cust) // one card per customer
				if mrand.Float64() < *declines {
					token = "tok_decline_card"
				}
				now := time.Now()
				req := &rpc.CreatePaymentRequest{MerchantID: *merchant, CustomerID: fmt.Sprintf("cust_%d", cust),
					IdempotencyKey: fmt.Sprintf("load-%s-%d", runID, i), AmountMinor: amount, Currency: "INR",
					CardToken: token, ClientTimeMS: now.UnixMilli(), ExpiresAtMS: now.Add(time.Hour).UnixMilli(),
					DeadlineMS: *deadline}
				req.Sign(*secret)
				r := row{start: now, worker: w, amount: amount, clientInflight: inflight.Add(1)}
				ctx, cancel := context.WithTimeout(context.Background(), time.Duration(*deadline)*time.Millisecond+2*time.Second)
				v, err := cl.CreatePayment(ctx, req)
				cancel()
				inflight.Add(-1)
				r.latency = time.Since(now)
				if err != nil {
					r.errCode = status.Code(err).String()
					r.state = "RPC_" + r.errCode
				} else {
					r.v, r.paymentID, r.state, r.fcode = v, v.PaymentID, v.State, v.FailureCode
				}
				mu.Lock()
				rows = append(rows, r)
				mu.Unlock()
			}
		}()
	}
	wg.Wait()
	elapsed := time.Since(began)

	summarize(rows, elapsed, *c, *conns, *deadline)
	if *out != "" {
		if err := writeCSV(*out, *appendTo, rows, *c, *conns, *deadline, *label); err != nil {
			fmt.Fprintln(os.Stderr, "csv:", err)
			os.Exit(1)
		}
		fmt.Printf("wrote %d rows to %s\n", len(rows), *out)
	}
}

func summarize(rows []row, elapsed time.Duration, c, conns int, deadline int64) {
	states := map[string]int{}
	var lat []float64
	missed := 0
	for _, r := range rows {
		states[r.state]++
		ms := float64(r.latency.Microseconds()) / 1000
		lat = append(lat, ms)
		if ms > float64(deadline) || !(r.v != nil && r.v.Final()) {
			missed++
		}
	}
	slices.Sort(lat)
	pct := func(p float64) float64 {
		if len(lat) == 0 {
			return 0
		}
		return lat[min(len(lat)-1, int(p*float64(len(lat))))]
	}
	fmt.Printf("payments=%d workers=%d connections=%d elapsed=%s throughput=%.0f/s\n",
		len(rows), c, conns, elapsed.Round(time.Millisecond), float64(len(rows))/elapsed.Seconds())
	fmt.Printf("latency ms: p50=%.2f p90=%.2f p99=%.2f max=%.2f\n", pct(.5), pct(.9), pct(.99), pct(1))
	fmt.Printf("not final within deadline: %d\n", missed)
	keys := make([]string, 0, len(states))
	for k := range states {
		keys = append(keys, k)
	}
	slices.Sort(keys)
	for _, k := range keys {
		fmt.Printf("  %-26s %d\n", k, states[k])
	}
}

func writeCSV(path string, appendTo bool, rows []row, c, conns int, deadline int64, label string) error {
	flags := os.O_CREATE | os.O_WRONLY | os.O_TRUNC
	writeHeader := true
	if appendTo {
		flags = os.O_CREATE | os.O_WRONLY | os.O_APPEND
		if st, err := os.Stat(path); err == nil && st.Size() > 0 {
			writeHeader = false
		}
	}
	f, err := os.OpenFile(path, flags, 0o644)
	if err != nil {
		return err
	}
	defer f.Close()
	w := csv.NewWriter(f)
	if writeHeader {
		_ = w.Write([]string{"ts_ms", "label", "worker", "payment_id", "amount_minor", "concurrency", "conns",
			"deadline_ms", "client_inflight", "latency_ms", "server_ms", "state", "failure_code", "rpc_error",
			"authorize_attempts", "capture_attempts", "recoveries", "authorize_ms", "capture_ms",
			"server_inflight", "server_streams", "rtt_ms", "congestion_factor", "congestion_control",
			"missed_deadline"})
	}
	f64 := func(v float64) string { return strconv.FormatFloat(v, 'f', 3, 64) }
	for _, r := range rows {
		rec := []string{strconv.FormatInt(r.start.UnixMilli(), 10), label, strconv.Itoa(r.worker), r.paymentID,
			strconv.FormatInt(r.amount, 10), strconv.Itoa(c), strconv.Itoa(conns), strconv.FormatInt(deadline, 10),
			strconv.FormatInt(r.clientInflight, 10), f64(float64(r.latency.Microseconds()) / 1000)}
		missed := float64(r.latency.Milliseconds()) > float64(deadline) || r.v == nil || !r.v.Final()
		if r.v != nil {
			t := r.v.Transport
			var inflight, streams int64
			var rtt, cf float64
			var ccName string
			if t != nil {
				inflight, streams, rtt, cf, ccName = t.Inflight, t.ActiveStreams, t.RTTMillis, t.CongestionFactor, t.Congestion
			}
			rec = append(rec, f64(r.v.ServerMS), r.state, r.fcode, "",
				strconv.Itoa(r.v.Attempts["AUTHORIZE"]), strconv.Itoa(r.v.Attempts["CAPTURE"]), strconv.Itoa(r.v.Recoveries),
				f64(r.v.StageMS["AUTHORIZE"]), f64(r.v.StageMS["CAPTURE"]),
				strconv.FormatInt(inflight, 10), strconv.FormatInt(streams, 10), f64(rtt), f64(cf), ccName)
		} else {
			rec = append(rec, "", r.state, "", r.errCode, "", "", "", "", "", "", "", "", "", "")
		}
		rec = append(rec, strconv.FormatBool(missed))
		if err := w.Write(rec); err != nil {
			return err
		}
	}
	w.Flush()
	return w.Error()
}

func randHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func envOr(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
