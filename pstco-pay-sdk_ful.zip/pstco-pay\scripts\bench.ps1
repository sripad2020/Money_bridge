# Benchmarks PSTCO-Pay: for each durability mode and connection-pool size, starts a
# fresh server, runs the load generator, and appends rows to one CSV for ml/.
#
#   powershell -ExecutionPolicy Bypass -File scripts\bench.ps1 -WorkDir C:\temp\pstco-bench
param(
    [string]$WorkDir = (Join-Path $env:TEMP "pstco-bench"),
    [int]$Payments = 3000,
    [int]$Workers = 64,
    [string]$Faults = "flaky",
    [string[]]$Durability = @("full", "normal"),
    [int[]]$Conns = @(1, 4)
)
$ErrorActionPreference = "Stop"
# Development secret shared by the server and the demo clients. Never use it in production.
if (-not $env:PSTCO_MERCHANT_SECRET) { $env:PSTCO_MERCHANT_SECRET = "demo-merchant-secret" }
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
    go build -o bin\ ./cmd/...
    New-Item -ItemType Directory -Force $WorkDir | Out-Null
    $certs = Join-Path $WorkDir "certs"
    if (-not (Test-Path (Join-Path $certs "ca.pem"))) { & .\bin\certgen.exe -out $certs | Out-Null }
    $csv = Join-Path $WorkDir "loadgen.csv"
    Remove-Item $csv -ErrorAction SilentlyContinue

    foreach ($d in $Durability) {
        foreach ($c in $Conns) {
            $data = Join-Path $WorkDir "data-$d-$c"
            Remove-Item -Recurse -Force $data -ErrorAction SilentlyContinue
            $log = Join-Path $WorkDir "server-$d-$c.log"
            $srv = Start-Process -FilePath (Resolve-Path .\bin\pstco-server.exe) -PassThru -WindowStyle Hidden `
                -ArgumentList "-data `"$data`" -certs `"$certs`" -faults $Faults -durability $d -metrics `"`"" `
                -RedirectStandardError $log -RedirectStandardOutput "$log.out"
            Start-Sleep -Seconds 2
            Write-Host "=== durability=$d conns=$c ==="
            & .\bin\pstco-loadgen.exe -certs $certs -n $Payments -c $Workers -conns $c -label "$d-conns$c" -out $csv -append
            Stop-Process -Id $srv.Id -Force
            Start-Sleep -Milliseconds 500
        }
    }
    Write-Host "CSV: $csv"
} finally {
    Pop-Location
}
