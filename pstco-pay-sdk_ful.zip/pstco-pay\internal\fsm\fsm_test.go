package fsm

import (
	"testing"

	"pstcopay/internal/model"
)

func TestTerminalStatesHaveNoExits(t *testing.T) {
	for _, s := range States() {
		if s.Terminal() && s != model.StateSettled && len(transitions[s]) > 0 {
			t.Errorf("terminal state %s has transitions", s)
		}
	}
}

func TestHappyPathIsLegal(t *testing.T) {
	path := []model.State{model.StateCreated, model.StateValidating, model.StateValidated,
		model.StateAuthenticating, model.StateAuthenticated, model.StateRiskPending, model.StateAuthorizing,
		model.StateAuthorized, model.StateCapturing, model.StateCaptured, model.StateSettlementPending,
		model.StateSettlementProcessing, model.StateSettled}
	for i := 1; i < len(path); i++ {
		if err := Check(path[i-1], path[i]); err != nil {
			t.Fatal(err)
		}
	}
	if Check(model.StateCreated, model.StateCaptured) == nil {
		t.Fatal("skipping stages must be illegal")
	}
	if Check(model.StateDeclined, model.StateAuthorizing) == nil {
		t.Fatal("a declined payment must never be retried")
	}
}
