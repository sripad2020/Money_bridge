package acquirer

import (
	"encoding/json"
	"errors"
	"os"
	"time"
)

// The simulated processor stands in for an external system that keeps its
// own durable records. Snapshots let the simulator survive a graceful server
// restart so CSDR status queries keep working across restarts.

type snapAuth struct {
	ID, Token, Currency string
	Amount              int64
	Captured, Voided    bool
	ExpiresAt           time.Time
}

type snapCapture struct {
	ID, AuthID, Currency string
	Amount               int64
	Refunded, Settled    bool
}

type snapshot struct {
	Results     map[string]*Result
	Auths       []snapAuth
	Captures    []snapCapture
	Balances    map[string]int64
	Settlements []SettlementLine
	Effects     map[Op]int
}

// SaveSnapshot writes the simulator state to path atomically.
func (a *Acquirer) SaveSnapshot(path string) error {
	a.mu.Lock()
	s := snapshot{Results: a.results, Balances: a.balances, Settlements: a.settlements, Effects: a.effects}
	for _, x := range a.auths {
		s.Auths = append(s.Auths, snapAuth{ID: x.id, Token: x.token, Currency: x.currency, Amount: x.amount,
			Captured: x.captured, Voided: x.voided, ExpiresAt: x.expiresAt})
	}
	for _, c := range a.captures {
		s.Captures = append(s.Captures, snapCapture{ID: c.id, AuthID: c.authID, Currency: c.currency,
			Amount: c.amount, Refunded: c.refunded, Settled: c.settled})
	}
	b, err := json.Marshal(s)
	a.mu.Unlock()
	if err != nil {
		return err
	}
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o600); err != nil {
		return err
	}
	return os.Rename(tmp, path)
}

// LoadSnapshot restores simulator state from path, if it exists.
func (a *Acquirer) LoadSnapshot(path string) error {
	b, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil
	}
	if err != nil {
		return err
	}
	var s snapshot
	if err := json.Unmarshal(b, &s); err != nil {
		return err
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	if s.Results != nil {
		a.results = s.Results
	}
	if s.Balances != nil {
		a.balances = s.Balances
	}
	if s.Effects != nil {
		a.effects = s.Effects
	}
	a.settlements = s.Settlements
	for _, x := range s.Auths {
		a.auths[x.ID] = &auth{id: x.ID, token: x.Token, currency: x.Currency, amount: x.Amount,
			captured: x.Captured, voided: x.Voided, expiresAt: x.ExpiresAt}
	}
	for _, c := range s.Captures {
		a.captures[c.ID] = &capture{id: c.ID, authID: c.AuthID, currency: c.Currency, amount: c.Amount,
			refunded: c.Refunded, settled: c.Settled}
	}
	return nil
}
