// Secure Enclave key for the PSTCO-Pay SDK (gomobile binding of sdk/mobile).
//
// Build the SDK:  gomobile bind -target=ios -o Pstco.xcframework ./sdk/mobile
// Use it:         let w = MobileNewWallet(dir, serverURL, "", pin, SecureEnclaveKeyStore(), &error)
//
// The pattern: a Secure Enclave P-256 key signs payments. App Attest
// (DeviceCheck) attests the app instance, and an App Attest assertion over
// challenge || public key binds the Secure Enclave key to it. The server
// verifies both (sdk/attest, apple-appattest).
//
// Reference implementation: written against Security and DeviceCheck and not
// compiled in this repository's CI (no Xcode there). Method names follow
// gomobile's generated protocol; check Mobile.objc.h after binding. Call the
// wallet off the main thread: attestationJSON waits for App Attest callbacks.
import CryptoKit
import DeviceCheck
import Foundation
import Mobile
import Security

final class SecureEnclaveKeyStore: NSObject, MobileNativeKeyStoreProtocol {
    private let tag = "com.example.pstco.device-key".data(using: .utf8)!

    func kind() -> String { "ios-secure-enclave" }

    private func key() throws -> SecKey {
        let query: [String: Any] = [kSecClass as String: kSecClassKey, kSecAttrApplicationTag as String: tag,
                                    kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom, kSecReturnRef as String: true]
        var item: CFTypeRef?
        if SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess { return item as! SecKey }
        var err: Unmanaged<CFError>?
        guard let access = SecAccessControlCreateWithFlags(nil, kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
                                                           [.privateKeyUsage], &err) else { throw err!.takeRetainedValue() }
        let attrs: [String: Any] = [
            kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom, kSecAttrKeySizeInBits as String: 256,
            kSecAttrTokenID as String: kSecAttrTokenIDSecureEnclave,
            kSecPrivateKeyAttrs as String: [kSecAttrIsPermanent as String: true, kSecAttrApplicationTag as String: tag,
                                            kSecAttrAccessControl as String: access]]
        guard let k = SecKeyCreateRandomKey(attrs as CFDictionary, &err) else { throw err!.takeRetainedValue() }
        return k
    }

    /// 65-byte uncompressed P-256 point.
    func publicKey() throws -> Data {
        var err: Unmanaged<CFError>?
        guard let pub = SecKeyCopyPublicKey(try key()),
              let raw = SecKeyCopyExternalRepresentation(pub, &err) as Data? else { throw err!.takeRetainedValue() }
        return raw
    }

    /// DER ECDSA over SHA-256(msg); the SDK converts it to the 64-byte form.
    func signDER(_ msg: Data?) throws -> Data {
        var err: Unmanaged<CFError>?
        guard let sig = SecKeyCreateSignature(try key(), .ecdsaSignatureMessageX962SHA256, (msg ?? Data()) as CFData, &err)
        else { throw err!.takeRetainedValue() }
        return sig as Data
    }

    func attestationJSON(_ challenge: Data?) throws -> String {
        let service = DCAppAttestService.shared
        guard service.isSupported else { return #"{"format":"none"}"# } // registers with software trust
        let ch = challenge ?? Data()
        let pub = try publicKey()
        let keyID = try wait { done in service.generateKey { id, e in done(id, e) } }
        let attestation = try wait { done in
            service.attestKey(keyID, clientDataHash: Data(SHA256.hash(data: ch))) { obj, e in done(obj, e) } }
        let assertion = try wait { done in
            service.generateAssertion(keyID, clientDataHash: Data(SHA256.hash(data: ch + pub))) { a, e in done(a, e) } }
        let json: [String: String] = ["format": "apple-appattest", "object": attestation.base64EncodedString(),
                                      "assertion": assertion.base64EncodedString()]
        return String(data: try JSONSerialization.data(withJSONObject: json), encoding: .utf8)!
    }

    private func wait<T>(_ op: (@escaping (T?, Error?) -> Void) -> Void) throws -> T {
        let sem = DispatchSemaphore(value: 0)
        var result: T?, failure: Error?
        op { v, e in result = v; failure = e; sem.signal() }
        sem.wait()
        if let failure { throw failure }
        return result!
    }
}
