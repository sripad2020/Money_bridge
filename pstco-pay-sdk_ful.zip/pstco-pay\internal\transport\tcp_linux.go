//go:build linux

package transport

import (
	"net"
	"syscall"
	"time"

	"golang.org/x/sys/unix"
)

// TCPInfoSupported reports whether ReadTCPInfo works on this OS.
const TCPInfoSupported = true

func control(c *net.TCPConn, fn func(fd int) error) error {
	raw, err := c.SyscallConn()
	if err != nil {
		return err
	}
	var inner error
	if err := raw.Control(func(fd uintptr) { inner = fn(int(fd)) }); err != nil {
		return err
	}
	return inner
}

// SetCongestion selects the TCP congestion-control algorithm for a socket.
// The algorithm must be available in the kernel (for BBR: modprobe tcp_bbr).
func SetCongestion(c *net.TCPConn, algo string) error {
	return control(c, func(fd int) error {
		return unix.SetsockoptString(fd, unix.IPPROTO_TCP, unix.TCP_CONGESTION, algo)
	})
}

// GetCongestion returns the socket's congestion-control algorithm.
func GetCongestion(c *net.TCPConn) (string, error) {
	var out string
	err := control(c, func(fd int) error {
		v, err := unix.GetsockoptString(fd, unix.IPPROTO_TCP, unix.TCP_CONGESTION)
		out = v
		return err
	})
	return out, err
}

// ReadTCPInfo reads kernel TCP_INFO for a socket.
func ReadTCPInfo(c *net.TCPConn) (*TCPStats, error) {
	var st TCPStats
	err := control(c, func(fd int) error {
		info, err := unix.GetsockoptTCPInfo(fd, unix.IPPROTO_TCP, unix.TCP_INFO)
		if err != nil {
			return err
		}
		st = TCPStats{
			RTT:          time.Duration(info.Rtt) * time.Microsecond,
			RTTVar:       time.Duration(info.Rttvar) * time.Microsecond,
			TotalRetrans: info.Total_retrans,
			CongWindow:   info.Snd_cwnd,
		}
		return nil
	})
	return &st, err
}

// DialControl applies the congestion-control algorithm before connect.
func DialControl(algo string) func(network, address string, c syscall.RawConn) error {
	if algo == "" {
		return nil
	}
	return func(_, _ string, c syscall.RawConn) error {
		var inner error
		if err := c.Control(func(fd uintptr) {
			inner = unix.SetsockoptString(int(fd), unix.IPPROTO_TCP, unix.TCP_CONGESTION, algo)
		}); err != nil {
			return err
		}
		return inner
	}
}
