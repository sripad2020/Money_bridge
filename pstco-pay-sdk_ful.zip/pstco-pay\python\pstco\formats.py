"""PSTCO-Pay offline wire formats, byte-compatible with sdk/offline in Go:
the 114-byte payment record, device certificates, reserve instructions, the
signed payee directory, payee IDs and QR payloads, and offline verification.
"""

from __future__ import annotations

import base64
import hashlib
import json
import struct
import time
from dataclasses import dataclass, field

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519
from cryptography.hazmat.primitives.asymmetric.utils import encode_dss_signature

from .amount import decode_amount, encode_amount
from .checks import CheckError, binary, integer

RECORD_SIZE = 114
SIGNED_SIZE = 50
HASH_SIZE = 16
RECORD_V1 = 0x01
RECORD_TAG = b"PSTCO-OFF-1"
CERT_TAG = b"PSTCO-CERT-1"
RESERVE_TAG = b"PSTCO-RSV-1"
DIRECTORY_TAG = b"PSTCO-DIR-1\n"
RESERVE_SIZE = 103

ALG_ED25519, ALG_P256 = 1, 2
TRUST_NAMES = {1: "software", 2: "hardware-key", 3: "secure-applet"}


class PaymentRejected(ValueError):
    """A payee must not accept this payment."""


# ---------------------------------------------------------------- signatures

def verify_signature(alg: int, public_key: bytes, msg: bytes, sig: bytes) -> bool:
    if len(sig) != 64:
        return False
    try:
        if alg == ALG_ED25519:
            ed25519.Ed25519PublicKey.from_public_bytes(public_key).verify(sig, msg)
            return True
        if alg == ALG_P256:
            key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), public_key)
            der = encode_dss_signature(int.from_bytes(sig[:32], "big"), int.from_bytes(sig[32:], "big"))
            key.verify(der, msg, ec.ECDSA(hashes.SHA256()))
            return True
    except (InvalidSignature, ValueError):
        return False
    return False


# ------------------------------------------------------------------- record

@dataclass
class Record:
    device_id: int
    counter: int
    amount_paise: int
    payee_id: int
    timestamp: int
    expiry: int
    prev_hash: bytes = bytes(HASH_SIZE)
    signature: bytes = bytes(64)
    version: int = RECORD_V1

    def signed_bytes(self) -> bytes:
        integer("device_id", self.device_id, 1, (1 << 64) - 1)
        integer("counter", self.counter, 1, (1 << 32) - 1)
        integer("payee_id", self.payee_id, 1, (1 << 64) - 1)
        integer("timestamp", self.timestamp, 0, (1 << 32) - 1)
        integer("expiry", self.expiry, 0, (1 << 32) - 1)
        binary("prev_hash", self.prev_hash, HASH_SIZE, HASH_SIZE)
        if self.version != RECORD_V1:
            raise CheckError("version", "1", self.version)
        return (struct.pack(">BQI", self.version, self.device_id, self.counter) + encode_amount(self.amount_paise)
                + struct.pack(">QII", self.payee_id, self.timestamp, self.expiry) + self.prev_hash)

    def to_bytes(self) -> bytes:
        binary("signature", self.signature, 64, 64)
        return self.signed_bytes() + self.signature

    @classmethod
    def from_bytes(cls, b: bytes) -> "Record":
        binary("record", b, RECORD_SIZE, RECORD_SIZE)
        if b[0] != RECORD_V1:
            raise CheckError("record.version", "1", b[0])
        version, device, counter = struct.unpack(">BQI", b[:13])
        amount = decode_amount(b[13:18])
        payee, ts, exp = struct.unpack(">QII", b[18:34])
        if not device or not counter or not payee:
            raise CheckError("record", "non-zero device, counter and payee")
        return cls(device, counter, amount, payee, ts, exp, b[34:50], b[50:114], version)

    @property
    def nonce(self) -> str:
        return f"{self.device_id:016x}:{self.counter}"


def signing_message(signed: bytes) -> bytes:
    return RECORD_TAG + signed


def record_hash(raw: bytes) -> bytes:
    return hashlib.sha256(raw).digest()[:HASH_SIZE]


# -------------------------------------------------------------- certificate

@dataclass
class DeviceCert:
    device_id: int
    owner_payee: int
    alg: int
    trust: int
    per_payment_limit: int
    max_reserve: int
    issued_at: int
    expires_at: int
    public_key: bytes
    signature: bytes = bytes(64)
    version: int = 1

    def body(self) -> bytes:
        return (struct.pack(">BQQBB", self.version, self.device_id, self.owner_payee, self.alg, self.trust)
                + encode_amount(self.per_payment_limit) + encode_amount(self.max_reserve)
                + struct.pack(">IIB", self.issued_at, self.expires_at, len(self.public_key)) + self.public_key)

    def to_bytes(self) -> bytes:
        return self.body() + self.signature

    @classmethod
    def from_bytes(cls, b: bytes) -> tuple["DeviceCert", int]:
        if type(b) is not bytes or len(b) < 38 + 64:
            raise CheckError("certificate", "at least 102 bytes", b)
        n = b[37]
        size = 38 + n + 64
        if len(b) < size:
            raise CheckError("certificate", "complete certificate")
        version, dev, owner, alg, trust = struct.unpack(">BQQBB", b[:19])
        ppl, mr = decode_amount(b[19:24]), decode_amount(b[24:29])
        issued, expires = struct.unpack(">II", b[29:37])
        if version != 1 or n != {ALG_ED25519: 32, ALG_P256: 65}.get(alg):
            raise CheckError("certificate", "version 1 with a matching key size")
        return cls(dev, owner, alg, trust, ppl, mr, issued, expires, b[38:38 + n], b[38 + n:size], version), size

    def verify(self, ca_public_key: bytes, now: float | None = None) -> None:
        now = time.time() if now is None else now
        if not verify_signature(ALG_ED25519, ca_public_key, CERT_TAG + self.body(), self.signature):
            raise PaymentRejected("certificate not signed by the bank CA")
        if now + 300 < self.issued_at or now > self.expires_at:
            raise PaymentRejected("certificate outside its validity window")

    @property
    def trust_name(self) -> str:
        return TRUST_NAMES.get(self.trust, str(self.trust))


# ------------------------------------------------------------------ reserve

@dataclass
class Reserve:
    reserve_id: int
    device_id: int
    amount_paise: int
    counter_start: int
    per_payment_limit: int
    expiry: int
    issued_at: int
    signature: bytes
    raw: bytes = field(repr=False, default=b"")

    @classmethod
    def from_bytes(cls, b: bytes) -> "Reserve":
        binary("reserve", b, RESERVE_SIZE, RESERVE_SIZE)
        if b[0] != 1:
            raise CheckError("reserve.version", "1", b[0])
        rid, dev = struct.unpack(">QQ", b[1:17])
        amt = decode_amount(b[17:22])
        (cstart,) = struct.unpack(">I", b[22:26])
        ppl = decode_amount(b[26:31])
        exp, issued = struct.unpack(">II", b[31:39])
        return cls(rid, dev, amt, cstart, ppl, exp, issued, b[39:], b)

    def verify(self, ca_public_key: bytes) -> None:
        if not verify_signature(ALG_ED25519, ca_public_key, RESERVE_TAG + self.raw[:39], self.signature):
            raise PaymentRejected("reserve not signed by the bank CA")

    @property
    def genesis(self) -> bytes:
        return hashlib.sha256(self.raw).digest()[:HASH_SIZE]


# ------------------------------------------------------- phones and payees

def normalize_phone(s: str) -> str:
    if type(s) is not str:
        raise CheckError("phone", "str", s)
    t = s.strip()
    plus = t.startswith("+")
    digits = ""
    for i, ch in enumerate(t):
        if ch.isascii() and ch.isdigit():
            digits += ch
        elif ch == "+" and i == 0:
            pass
        elif ch in " -()":
            pass
        else:
            raise CheckError("phone", "digits", s)
    if plus and 8 <= len(digits) <= 15:
        return "+" + digits
    if not plus and len(digits) == 10 and digits[0] >= "6":
        return "+91" + digits
    if not plus and len(digits) == 12 and digits.startswith("91"):
        return "+" + digits
    raise CheckError("phone", "a valid phone number", s)


def payee_id_for_phone(phone: str) -> int:
    d = hashlib.sha256(("PSTCO-PAYEE-1\n" + normalize_phone(phone)).encode()).digest()
    return int.from_bytes(d[:8], "big") or 1


def format_id(v: int) -> str:
    return f"{integer('id', v, 0, (1 << 64) - 1):016x}"


def parse_id(s: str) -> int:
    if type(s) is not str or len(s) != 16:
        raise CheckError("id", "16 hex digits", s)
    return int(s, 16)


# ------------------------------------------------------------------- QR codes

def encode_payment_qr(record: bytes, cert: bytes) -> str:
    return "PSTCO1:" + base64.urlsafe_b64encode(record + cert).decode().rstrip("=")


def decode_payment_qr(s: str) -> tuple[bytes, bytes]:
    if type(s) is not str or not s.startswith("PSTCO1:"):
        raise PaymentRejected("not a PSTCO payment code")
    body = s[len("PSTCO1:"):]
    raw = base64.urlsafe_b64decode(body + "=" * (-len(body) % 4))
    if len(raw) <= RECORD_SIZE:
        raise PaymentRejected("corrupt payment code")
    return raw[:RECORD_SIZE], raw[RECORD_SIZE:]


def encode_payee_qr(phone: str, name: str) -> str:
    body = json.dumps({"phone": normalize_phone(phone), "name": name}, separators=(",", ":")).encode()
    return "PSTCOPAYEE1:" + base64.urlsafe_b64encode(body).decode().rstrip("=")


def decode_payee_qr(s: str) -> dict:
    if type(s) is not str or not s.startswith("PSTCOPAYEE1:"):
        raise CheckError("payee code", "PSTCOPAYEE1:...", s)
    body = s[len("PSTCOPAYEE1:"):]
    card = json.loads(base64.urlsafe_b64decode(body + "=" * (-len(body) % 4)))
    card["phone"] = normalize_phone(card["phone"])
    return card


# ------------------------------------------------------------------ directory

def open_directory(payload: bytes, signature: bytes, ca_public_key: bytes) -> dict:
    if not verify_signature(ALG_ED25519, ca_public_key, DIRECTORY_TAG + payload, signature):
        raise PaymentRejected("directory not signed by the bank CA")
    return json.loads(payload)


# ----------------------------------------------------- offline verification

def verify_payment(record: bytes, cert: bytes, ca_public_key: bytes, payee_id: int = 0,
                   now: float | None = None) -> tuple[Record, DeviceCert]:
    """What a payee runs with no signal. Raises PaymentRejected."""
    now = time.time() if now is None else now
    try:
        r = Record.from_bytes(record)
        c, n = DeviceCert.from_bytes(cert)
    except CheckError as e:
        raise PaymentRejected(str(e)) from e
    if n != len(cert):
        raise PaymentRejected("trailing bytes after certificate")
    c.verify(ca_public_key, now)
    if r.device_id != c.device_id:
        raise PaymentRejected("certificate is for another device")
    if not verify_signature(c.alg, c.public_key, signing_message(record[:SIGNED_SIZE]), record[SIGNED_SIZE:]):
        raise PaymentRejected("payment signature does not verify")
    if r.amount_paise > c.per_payment_limit:
        raise PaymentRejected("amount above the payer's per-payment limit")
    if now > r.expiry:
        raise PaymentRejected("payment expired")
    if payee_id and r.payee_id != payee_id:
        raise PaymentRejected("payment is addressed to someone else")
    return r, c


# ------------------------------------------------------------------ receipts

RECEIPT_SIZE = 98
RECEIPT_TAG = b"PSTCO-RCPT-1"
RECEIPT_STATUS = {1: "accepted", 2: "settled", 3: "duplicate"}


def verify_receipt(receipt: bytes, record: bytes, server_public_key: bytes) -> str:
    """Check the server's signed receipt covers exactly this record; returns its status."""
    if type(receipt) is not bytes or len(receipt) != RECEIPT_SIZE or receipt[0] != 1:
        raise PaymentRejected("malformed receipt")
    if not verify_signature(ALG_ED25519, server_public_key, RECEIPT_TAG + receipt[:34], receipt[34:]):
        raise PaymentRejected("receipt not signed by the server")
    r = Record.from_bytes(record)
    dev, ctr = struct.unpack(">QI", receipt[1:13])
    if dev != r.device_id or ctr != r.counter or receipt[13:29] != record_hash(record):
        raise PaymentRejected("receipt is for a different record")
    return RECEIPT_STATUS.get(receipt[29], "unknown")