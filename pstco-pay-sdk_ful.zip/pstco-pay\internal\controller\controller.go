// Package controller is the PSTCO controller. It joins payment execution
// with transport conditions: admission control and backpressure from
// in-flight load, per-operation latency and error estimates, transport RTT
// and retransmission telemetry, and deadline-aware timeouts and backoff.
package controller

import (
	"errors"
	"math"
	"math/rand/v2"
	"sync"
	"sync/atomic"
	"time"
)

var (
	// ErrOverloaded means admission control rejected the request.
	ErrOverloaded = errors.New("controller: overloaded, retry later")
	// ErrDeadlineTooShort means the remaining deadline cannot fit the fast path.
	ErrDeadlineTooShort = errors.New("controller: deadline shorter than expected fast-path latency")
)

// Config tunes the controller.
type Config struct {
	MaxInflight    int64
	BaseBackoff    time.Duration
	MaxBackoff     time.Duration
	MinStageBudget time.Duration
	DefaultLatency time.Duration
	Alpha          float64 // EWMA weight of a new sample
}

// DefaultConfig returns sensible defaults.
func DefaultConfig() Config {
	return Config{
		MaxInflight:    512,
		BaseBackoff:    20 * time.Millisecond,
		MaxBackoff:     2 * time.Second,
		MinStageBudget: 10 * time.Millisecond,
		DefaultLatency: 25 * time.Millisecond,
		Alpha:          0.2,
	}
}

type estimator struct {
	mean, variance float64 // seconds
	errRate        float64
	samples        int64
}

// TransportSample is one measurement of transport health.
type TransportSample struct {
	RTT         time.Duration
	RTTVar      time.Duration
	Retransmits uint32 // retransmissions since the previous sample
	CongWindow  uint32
	ActiveConns int
	Congestion  string
	Unsupported bool
}

// TransportState is the controller's smoothed view of the transport.
type TransportState struct {
	RTTMillis         float64 `json:"rtt_ms"`
	BaselineRTTMillis float64 `json:"baseline_rtt_ms"`
	RetransRate       float64 `json:"retrans_per_sample"`
	CongWindow        uint32  `json:"cwnd"`
	ActiveConns       int     `json:"active_conns"`
	ActiveStreams     int64   `json:"active_streams"`
	Inflight          int64   `json:"inflight_payments"`
	CongestionFactor  float64 `json:"congestion_factor"`
	Congestion        string  `json:"congestion_control"`
	TCPInfoSupported  bool    `json:"tcp_info_supported"`
}

// OpStats is the latency and error estimate of one operation.
type OpStats struct {
	MeanMillis   float64 `json:"mean_ms"`
	StdDevMillis float64 `json:"stddev_ms"`
	ErrorRate    float64 `json:"error_rate"`
	Samples      int64   `json:"samples"`
}

// Controller is safe for concurrent use.
type Controller struct {
	cfg       Config
	inflight  atomic.Int64
	streams   atomic.Int64
	liveConns atomic.Int64

	mu        sync.Mutex
	ops       map[string]*estimator
	rtt       float64 // seconds, EWMA
	baseline  float64 // seconds, minimum observed
	retrans   float64
	cwnd      uint32
	conns     int
	cc        string
	tcpInfoOK bool
}

// New creates a controller.
func New(cfg Config) *Controller {
	return &Controller{cfg: cfg, ops: map[string]*estimator{}}
}

// Admit applies admission control. On success the caller must call release.
func (c *Controller) Admit(deadline time.Time) (release func(), err error) {
	if n := c.inflight.Add(1); n > c.cfg.MaxInflight {
		c.inflight.Add(-1)
		return nil, ErrOverloaded
	}
	if !deadline.IsZero() {
		need := c.Expected("authorize") + c.Expected("capture")
		if time.Until(deadline) < need {
			c.inflight.Add(-1)
			return nil, ErrDeadlineTooShort
		}
	}
	var once sync.Once
	return func() { once.Do(func() { c.inflight.Add(-1) }) }, nil
}

// ConnOpened and ConnClosed track live client TCP connections.
func (c *Controller) ConnOpened() { c.liveConns.Add(1) }
func (c *Controller) ConnClosed() { c.liveConns.Add(-1) }

// StreamStarted and StreamEnded track active HTTP/2 RPC streams.
func (c *Controller) StreamStarted() { c.streams.Add(1) }
func (c *Controller) StreamEnded()   { c.streams.Add(-1) }

// Observe records the latency and outcome of an operation.
func (c *Controller) Observe(op string, d time.Duration, failed bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	e, ok := c.ops[op]
	if !ok {
		e = &estimator{mean: d.Seconds()}
		c.ops[op] = e
	}
	a := c.cfg.Alpha
	x := d.Seconds()
	diff := x - e.mean
	e.mean += a * diff
	e.variance = (1 - a) * (e.variance + a*diff*diff)
	f := 0.0
	if failed {
		f = 1
	}
	e.errRate += a * (f - e.errRate)
	e.samples++
}

// Expected returns a high-percentile latency estimate (mean + 2 sigma).
func (c *Controller) Expected(op string) time.Duration {
	c.mu.Lock()
	defer c.mu.Unlock()
	e, ok := c.ops[op]
	if !ok || e.samples < 3 {
		return c.cfg.DefaultLatency
	}
	return time.Duration((e.mean + 2*math.Sqrt(e.variance)) * float64(time.Second))
}

// StageTimeout returns a per-call timeout: generous relative to the
// estimate, but never beyond the payment's remaining deadline.
func (c *Controller) StageTimeout(op string, deadline time.Time) time.Duration {
	t := 4 * c.Expected(op) * time.Duration(c.CongestionFactor()*100) / 100
	if t < c.cfg.MinStageBudget {
		t = c.cfg.MinStageBudget
	}
	if !deadline.IsZero() {
		if rem := time.Until(deadline); rem < t {
			t = rem
		}
	}
	return t
}

// CongestionFactor scales backoff and timeouts by transport stress: RTT
// inflation over baseline, retransmissions and in-flight load. Range [1, 4].
func (c *Controller) CongestionFactor() float64 {
	c.mu.Lock()
	f := 1.0
	if c.baseline > 0 && c.rtt > c.baseline {
		f *= c.rtt / c.baseline
	}
	f *= 1 + c.retrans/10
	c.mu.Unlock()
	if load := float64(c.inflight.Load()) / float64(c.cfg.MaxInflight); load > 0.5 {
		f *= 1 + (load - 0.5)
	}
	return math.Min(math.Max(f, 1), 4)
}

// Backoff returns a full-jitter exponential backoff for retry attempt n (1-based),
// stretched by congestion and the operation's recent error rate.
func (c *Controller) Backoff(op string, attempt int) time.Duration {
	if attempt < 1 {
		attempt = 1
	}
	b := float64(c.cfg.BaseBackoff) * math.Pow(2, float64(attempt-1)) * c.CongestionFactor()
	c.mu.Lock()
	if e, ok := c.ops[op]; ok {
		b *= 1 + e.errRate
	}
	c.mu.Unlock()
	b = math.Min(b, float64(c.cfg.MaxBackoff))
	return time.Duration(b/2 + rand.Float64()*b/2)
}

// CanRetry reports whether another attempt fits in the remaining deadline.
func (c *Controller) CanRetry(op string, attempt, maxAttempts int, deadline time.Time) bool {
	if attempt >= maxAttempts {
		return false
	}
	if deadline.IsZero() {
		return true
	}
	return time.Until(deadline) > c.Expected(op)+c.cfg.MinStageBudget
}

// UpdateTransport folds a transport telemetry sample into the state.
func (c *Controller) UpdateTransport(s TransportSample) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.conns = s.ActiveConns
	if s.Congestion != "" {
		c.cc = s.Congestion
	}
	if s.Unsupported {
		return
	}
	c.tcpInfoOK = true
	r := s.RTT.Seconds()
	if r > 0 {
		if c.rtt == 0 {
			c.rtt = r
		} else {
			c.rtt += c.cfg.Alpha * (r - c.rtt)
		}
		if c.baseline == 0 || r < c.baseline {
			c.baseline = r
		}
	}
	c.retrans += c.cfg.Alpha * (float64(s.Retransmits) - c.retrans)
	c.cwnd = s.CongWindow
}

// ObserveRTT records an application-level round trip (used where TCP_INFO is
// unavailable, for example on Windows).
func (c *Controller) ObserveRTT(d time.Duration) {
	c.mu.Lock()
	defer c.mu.Unlock()
	r := d.Seconds()
	if c.tcpInfoOK || r <= 0 {
		return
	}
	if c.rtt == 0 {
		c.rtt = r
	} else {
		c.rtt += c.cfg.Alpha * (r - c.rtt)
	}
	if c.baseline == 0 || r < c.baseline {
		c.baseline = r
	}
}

// Inflight returns the number of admitted, unfinished payments.
func (c *Controller) Inflight() int64 { return c.inflight.Load() }

// Transport returns a snapshot of transport state.
func (c *Controller) Transport() TransportState {
	f := c.CongestionFactor()
	c.mu.Lock()
	defer c.mu.Unlock()
	return TransportState{
		RTTMillis: c.rtt * 1000, BaselineRTTMillis: c.baseline * 1000,
		RetransRate: c.retrans, CongWindow: c.cwnd, ActiveConns: int(c.liveConns.Load()),
		ActiveStreams: c.streams.Load(), Inflight: c.inflight.Load(),
		CongestionFactor: f, Congestion: c.cc, TCPInfoSupported: c.tcpInfoOK,
	}
}

// Ops returns per-operation estimates.
func (c *Controller) Ops() map[string]OpStats {
	c.mu.Lock()
	defer c.mu.Unlock()
	out := map[string]OpStats{}
	for k, e := range c.ops {
		out[k] = OpStats{
			MeanMillis: e.mean * 1000, StdDevMillis: math.Sqrt(e.variance) * 1000,
			ErrorRate: e.errRate, Samples: e.samples,
		}
	}
	return out
}
