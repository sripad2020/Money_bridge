package engine

import (
	"context"
	"fmt"

	"pstcopay/internal/model"
	"pstcopay/internal/store"
)

// Reconciliation discrepancy kinds.
const (
	ReconCapturedNotSubmitted     = "captured_not_submitted"
	ReconSubmittedNoConfirmation  = "submitted_no_confirmation"
	ReconSettledExternallyPending = "settled_externally_pending_internally"
	ReconSettledInternallyMissing = "settled_internally_missing_externally"
	ReconAmountMismatch           = "amount_mismatch"
	ReconDuplicateSettlement      = "duplicate_settlement_instruction"
)

// ReconReport summarises one reconciliation run.
type ReconReport struct {
	RunID         string               `json:"run_id"`
	Checked       int                  `json:"payments_checked"`
	ExternalLines int                  `json:"external_lines"`
	Discrepancies []*store.ReconRecord `json:"discrepancies"`
}

// Reconcile compares internal payment and settlement records with the
// processor's settlement report and records every discrepancy.
func (e *Engine) Reconcile(ctx context.Context) (*ReconReport, error) {
	rep := &ReconReport{RunID: newID("recon")}
	now := e.now()
	lines := e.acq.SettlementReport()
	rep.ExternalLines = len(lines)

	type ext struct {
		count  int
		amount int64
	}
	byCapture := map[string]*ext{}
	for _, l := range lines {
		x := byCapture[l.CaptureID]
		if x == nil {
			x = &ext{}
			byCapture[l.CaptureID] = x
		}
		x.count++
		x.amount += l.AmountMinor
	}

	settlements, err := e.store.ListSettlements(ctx)
	if err != nil {
		return nil, err
	}
	internal := map[string]*store.SettlementRecord{}
	for _, s := range settlements {
		internal[s.PaymentID] = s
	}
	outbox, err := e.store.ListOutbox(ctx)
	if err != nil {
		return nil, err
	}
	outboxBy := map[string]*store.OutboxItem{}
	for _, o := range outbox {
		outboxBy[o.PaymentID] = o
	}

	payments, err := e.store.ListPaymentsByState(ctx, 100000,
		model.StateCaptured, model.StateSettlementPending, model.StateSettlementProcessing,
		model.StateSettled, model.StateReconciliationRequired, model.StateCompensated)
	if err != nil {
		return nil, err
	}
	add := func(p *model.Payment, kind, detail string) {
		rep.Discrepancies = append(rep.Discrepancies, &store.ReconRecord{
			RunID: rep.RunID, PaymentID: p.ID, Kind: kind, Detail: detail, CreatedAt: now})
	}
	for _, p := range payments {
		if p.CaptureID == "" {
			continue
		}
		rep.Checked++
		x := byCapture[p.CaptureID]
		ob := outboxBy[p.ID]
		stale := now.Sub(p.UpdatedAt) > e.cfg.CaptureNotSubmittedAfter

		if p.State == model.StateCaptured && ob == nil && stale {
			add(p, ReconCapturedNotSubmitted, "captured with no settlement instruction")
		}
		if ob != nil && (ob.Status == store.OutboxPublished || (ob.Status == store.OutboxProcessing && stale)) &&
			x == nil && p.State != model.StateCompensated {
			add(p, ReconSubmittedNoConfirmation, "settlement submitted, no external confirmation (outbox "+ob.Status+")")
		}
		if x != nil {
			if p.State != model.StateSettled && p.State != model.StateCompensated && stale {
				add(p, ReconSettledExternallyPending, "processor settled, internal state "+string(p.State))
			}
			if x.count > 1 {
				add(p, ReconDuplicateSettlement, fmt.Sprintf("%d external settlement lines for one capture", x.count))
			}
			if x.amount != p.AmountMinor*int64(x.count) || (internal[p.ID] != nil && internal[p.ID].AmountMinor != p.AmountMinor) {
				add(p, ReconAmountMismatch, fmt.Sprintf("payment %d, external total %d", p.AmountMinor, x.amount))
			}
		}
		if p.State == model.StateSettled && x == nil {
			add(p, ReconSettledInternallyMissing, "internal SETTLED with no external settlement line")
		}
	}

	if len(rep.Discrepancies) > 0 {
		err := e.store.WithTx(ctx, func(tx *store.Tx) error {
			for _, d := range rep.Discrepancies {
				if err := tx.InsertRecon(ctx, d); err != nil {
					return err
				}
			}
			return nil
		})
		if err != nil {
			return nil, err
		}
	}
	for _, d := range rep.Discrepancies {
		e.metrics.Reconciliation(d.Kind)
	}
	return rep, nil
}
