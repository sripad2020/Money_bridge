// Android Keystore key for the PSTCO-Pay SDK (gomobile binding of sdk/mobile).
//
// Build the SDK:   gomobile bind -target=android -o pstco.aar ./sdk/mobile
// Use it:          val w = Mobile.newWallet(filesDir.path + "/pstco", serverUrl, "", pin, StrongBoxKeyStore())
//
// Reference implementation: written against the Android Keystore API and not
// compiled in this repository's CI (no Android SDK there). Test on a device.
package com.example.pstco

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.security.keystore.StrongBoxUnavailableException
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec

class StrongBoxKeyStore(private val alias: String = "pstco-device-key") : mobile.NativeKeyStore {
    private val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    private var strongBox = true

    init {
        if (!ks.containsAlias(alias)) generate(null)
    }

    /** Android binds the attestation challenge at key generation, so the key
     *  is (re)created when the server's registration challenge arrives. */
    private fun generate(challenge: ByteArray?) {
        if (ks.containsAlias(alias)) ks.deleteEntry(alias)
        fun spec(useStrongBox: Boolean) = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setIsStrongBoxBacked(useStrongBox)
            // Optional: .setUserAuthenticationRequired(true) to require biometrics per signature.
            .apply { if (challenge != null) setAttestationChallenge(challenge) }
            .build()
        val gen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
        try {
            gen.initialize(spec(true)); gen.generateKeyPair(); strongBox = true
        } catch (e: StrongBoxUnavailableException) {
            gen.initialize(spec(false)); gen.generateKeyPair(); strongBox = false // TEE
        }
    }

    override fun kind(): String = if (strongBox) "android-strongbox" else "android-tee"

    /** 65-byte uncompressed P-256 point: 0x04 || X || Y. */
    override fun publicKey(): ByteArray {
        val pub = ks.getCertificate(alias).publicKey as ECPublicKey
        return byteArrayOf(0x04) + fixed32(pub.w.affineX) + fixed32(pub.w.affineY)
    }

    /** DER ECDSA over SHA-256(msg); the SDK converts it to the 64-byte form. */
    override fun signDER(msg: ByteArray): ByteArray {
        val key = ks.getKey(alias, null) as PrivateKey
        return Signature.getInstance("SHA256withECDSA").run { initSign(key); update(msg); sign() }
    }

    override fun attestationJSON(challenge: ByteArray): String {
        generate(challenge)
        val chain = JSONArray()
        ks.getCertificateChain(alias).forEach { chain.put(Base64.encodeToString(it.encoded, Base64.NO_WRAP)) }
        return JSONObject().put("format", "android-key").put("chain", chain).toString()
    }

    private fun fixed32(v: BigInteger): ByteArray {
        val b = v.toByteArray()
        return when {
            b.size == 32 -> b
            b.size > 32 -> b.copyOfRange(b.size - 32, b.size)
            else -> ByteArray(32 - b.size) + b
        }
    }
}
