// Package acquirer simulates the downstream payment processor (acquirer,
// card network and clearing house). It is idempotent by operation key, keeps
// a queryable record of every executed operation, and can inject the faults
// that CSDR exists to handle: unavailability before execution and lost
// responses after execution.
package acquirer

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	mrand "math/rand/v2"
	"strings"
	"sync"
	"time"
)

var (
	// ErrUnavailable means the request was rejected before any effect.
	ErrUnavailable = errors.New("acquirer: service unavailable")
	// ErrTimeout means the outcome is unknown: the effect may have happened.
	ErrTimeout = errors.New("acquirer: response timeout")
	// ErrAuthExpired means the authorization can no longer be captured.
	ErrAuthExpired = errors.New("acquirer: authorization expired")
	// ErrNotFound means no operation was executed under the key.
	ErrNotFound = errors.New("acquirer: not found")
)

// DeclineError is a business rejection. It is final and must not be retried.
type DeclineError struct{ Code, Reason string }

func (e *DeclineError) Error() string { return "acquirer: declined " + e.Code + ": " + e.Reason }

// Op is a downstream operation type.
type Op string

const (
	OpAuthorize Op = "authorize"
	OpCapture   Op = "capture"
	OpVoid      Op = "void"
	OpRefund    Op = "refund"
	OpSettle    Op = "settle"
)

// Fault is an injected failure mode.
type Fault int

const (
	FaultNone         Fault = iota
	FaultUnavailable        // fail before executing
	FaultLostResponse       // execute, then lose the response
)

// FaultInjector decides the fault for each call.
type FaultInjector interface {
	Fault(op Op, key string) Fault
}

// NoFaults never injects a fault.
type NoFaults struct{}

func (NoFaults) Fault(Op, string) Fault { return FaultNone }

// RandomFaults injects faults with fixed probabilities.
type RandomFaults struct {
	Unavailable  float64
	LostResponse float64
}

func (r RandomFaults) Fault(Op, string) Fault {
	x := mrand.Float64()
	switch {
	case x < r.Unavailable:
		return FaultUnavailable
	case x < r.Unavailable+r.LostResponse:
		return FaultLostResponse
	}
	return FaultNone
}

// ScriptedFaults returns queued faults per operation, then FaultNone. Used by tests.
type ScriptedFaults struct {
	mu     sync.Mutex
	script map[Op][]Fault
}

// NewScriptedFaults creates an empty script.
func NewScriptedFaults() *ScriptedFaults { return &ScriptedFaults{script: map[Op][]Fault{}} }

// Push queues faults for an operation.
func (s *ScriptedFaults) Push(op Op, f ...Fault) {
	s.mu.Lock()
	s.script[op] = append(s.script[op], f...)
	s.mu.Unlock()
}

func (s *ScriptedFaults) Fault(op Op, _ string) Fault {
	s.mu.Lock()
	defer s.mu.Unlock()
	q := s.script[op]
	if len(q) == 0 {
		return FaultNone
	}
	s.script[op] = q[1:]
	return q[0]
}

// Result is the recorded outcome of one executed operation.
type Result struct {
	Key         string
	Op          Op
	Ref         string // auth, capture, void, refund or settlement id
	Approved    bool
	DeclineCode string
	Reason      string
	AmountMinor int64
	Currency    string
	At          time.Time
}

type auth struct {
	id        string
	token     string
	amount    int64
	currency  string
	captured  bool
	voided    bool
	expiresAt time.Time
}

type capture struct {
	id       string
	authID   string
	amount   int64
	currency string
	refunded bool
	settled  bool
}

// SettlementLine is one line of the clearing house's settlement report.
type SettlementLine struct {
	SettlementID string
	CaptureID    string
	Key          string
	AmountMinor  int64
	Currency     string
	At           time.Time
}

// Config tunes the simulator.
type Config struct {
	AuthValidity   time.Duration
	Latency        func(op Op) time.Duration
	Faults         FaultInjector
	DefaultBalance int64
	Now            func() time.Time
}

// Acquirer is the simulated downstream processor.
type Acquirer struct {
	cfg Config

	mu          sync.Mutex
	results     map[string]*Result
	auths       map[string]*auth
	captures    map[string]*capture
	balances    map[string]int64
	settlements []SettlementLine
	effects     map[Op]int
	calls       map[Op]int
}

// New creates a simulator.
func New(cfg Config) *Acquirer {
	if cfg.AuthValidity == 0 {
		cfg.AuthValidity = 7 * 24 * time.Hour
	}
	if cfg.Latency == nil {
		cfg.Latency = func(Op) time.Duration { return 0 }
	}
	if cfg.Faults == nil {
		cfg.Faults = NoFaults{}
	}
	if cfg.DefaultBalance == 0 {
		cfg.DefaultBalance = 10_000_000_00 // 1 crore rupees in paise
	}
	if cfg.Now == nil {
		cfg.Now = time.Now
	}
	return &Acquirer{
		cfg: cfg, results: map[string]*Result{}, auths: map[string]*auth{},
		captures: map[string]*capture{}, balances: map[string]int64{},
		effects: map[Op]int{}, calls: map[Op]int{},
	}
}

// SetFaults replaces the fault injector.
func (a *Acquirer) SetFaults(f FaultInjector) {
	a.mu.Lock()
	a.cfg.Faults = f
	a.mu.Unlock()
}

// SetNow replaces the clock (tests use it to expire authorizations).
func (a *Acquirer) SetNow(now func() time.Time) {
	a.mu.Lock()
	a.cfg.Now = now
	a.mu.Unlock()
}

func newID(prefix string) string {
	b := make([]byte, 8)
	_, _ = rand.Read(b)
	return prefix + "_" + hex.EncodeToString(b)
}

// exec runs an operation idempotently by key with fault injection and latency.
// effect runs under the lock and returns the result to record, or an error
// that means "no effect".
func (a *Acquirer) exec(ctx context.Context, op Op, key string, effect func(now time.Time) (*Result, error)) (*Result, error) {
	a.mu.Lock()
	a.calls[op]++
	fault := a.cfg.Faults.Fault(op, key)
	latency := a.cfg.Latency(op)
	a.mu.Unlock()

	if fault == FaultUnavailable {
		return nil, ErrUnavailable
	}
	if err := ctx.Err(); err != nil {
		return nil, ErrUnavailable // never left the client
	}

	a.mu.Lock()
	r, seen := a.results[key]
	if !seen {
		var err error
		r, err = effect(a.cfg.Now())
		if err != nil {
			a.mu.Unlock()
			return nil, err
		}
		r.Key, r.Op = key, op
		a.results[key] = r
		a.effects[op]++
	}
	out := *r
	a.mu.Unlock()

	// The request reached the processor and the effect is committed. From
	// here on, a slow or lost response leaves the caller with an unknown outcome.
	if latency > 0 {
		t := time.NewTimer(latency)
		select {
		case <-t.C:
		case <-ctx.Done():
			t.Stop()
			return nil, ErrTimeout
		}
	}
	if fault == FaultLostResponse {
		return nil, ErrTimeout
	}
	if !out.Approved {
		return &out, &DeclineError{Code: out.DeclineCode, Reason: out.Reason}
	}
	return &out, nil
}

// Authorize places a hold for amount on the card token.
func (a *Acquirer) Authorize(ctx context.Context, key, token string, amount int64, currency string) (*Result, error) {
	return a.exec(ctx, OpAuthorize, key, func(now time.Time) (*Result, error) {
		r := &Result{AmountMinor: amount, Currency: currency, At: now}
		switch {
		case strings.HasPrefix(token, "tok_decline"):
			r.DeclineCode, r.Reason = "05", "do not honour"
			return r, nil
		case strings.HasPrefix(token, "tok_stolen"):
			r.DeclineCode, r.Reason = "43", "stolen card"
			return r, nil
		}
		bal, ok := a.balances[token]
		if !ok {
			bal = a.cfg.DefaultBalance
		}
		if strings.HasPrefix(token, "tok_lowbal") {
			bal = 100_00
		}
		if amount > bal {
			r.DeclineCode, r.Reason = "51", "insufficient funds"
			return r, nil
		}
		a.balances[token] = bal - amount
		id := newID("auth")
		a.auths[id] = &auth{id: id, token: token, amount: amount, currency: currency,
			expiresAt: now.Add(a.cfg.AuthValidity)}
		r.Approved, r.Ref = true, id
		return r, nil
	})
}

// Capture captures a previous authorization.
func (a *Acquirer) Capture(ctx context.Context, key, authID string, amount int64) (*Result, error) {
	return a.exec(ctx, OpCapture, key, func(now time.Time) (*Result, error) {
		au, ok := a.auths[authID]
		if !ok {
			return nil, fmt.Errorf("acquirer: unknown authorization %s", authID)
		}
		if au.voided || now.After(au.expiresAt) {
			return nil, ErrAuthExpired
		}
		r := &Result{AmountMinor: amount, Currency: au.currency, At: now}
		if au.captured {
			r.DeclineCode, r.Reason = "94", "authorization already captured"
			return r, nil
		}
		if amount > au.amount {
			r.DeclineCode, r.Reason = "13", "capture exceeds authorization"
			return r, nil
		}
		au.captured = true
		id := newID("cap")
		a.captures[id] = &capture{id: id, authID: authID, amount: amount, currency: au.currency}
		r.Approved, r.Ref = true, id
		return r, nil
	})
}

// Void releases an uncaptured authorization.
func (a *Acquirer) Void(ctx context.Context, key, authID string) (*Result, error) {
	return a.exec(ctx, OpVoid, key, func(now time.Time) (*Result, error) {
		au, ok := a.auths[authID]
		if !ok {
			return nil, fmt.Errorf("acquirer: unknown authorization %s", authID)
		}
		r := &Result{AmountMinor: au.amount, Currency: au.currency, At: now}
		if au.captured {
			r.DeclineCode, r.Reason = "12", "authorization already captured"
			return r, nil
		}
		if !au.voided {
			au.voided = true
			a.balances[au.token] += au.amount
		}
		r.Approved, r.Ref = true, newID("void")
		return r, nil
	})
}

// Refund returns captured funds, before or after settlement.
func (a *Acquirer) Refund(ctx context.Context, key, captureID string, amount int64) (*Result, error) {
	return a.exec(ctx, OpRefund, key, func(now time.Time) (*Result, error) {
		c, ok := a.captures[captureID]
		if !ok {
			return nil, fmt.Errorf("acquirer: unknown capture %s", captureID)
		}
		r := &Result{AmountMinor: amount, Currency: c.currency, At: now}
		if c.refunded {
			r.DeclineCode, r.Reason = "94", "already refunded"
			return r, nil
		}
		if amount > c.amount {
			r.DeclineCode, r.Reason = "13", "refund exceeds capture"
			return r, nil
		}
		c.refunded = true
		if au := a.auths[c.authID]; au != nil {
			a.balances[au.token] += amount
		}
		r.Approved, r.Ref = true, newID("rfd")
		return r, nil
	})
}

// Settle submits a capture to clearing and settlement.
func (a *Acquirer) Settle(ctx context.Context, key, captureID string) (*Result, error) {
	return a.exec(ctx, OpSettle, key, func(now time.Time) (*Result, error) {
		c, ok := a.captures[captureID]
		if !ok {
			return nil, fmt.Errorf("acquirer: unknown capture %s", captureID)
		}
		r := &Result{AmountMinor: c.amount, Currency: c.currency, At: now}
		c.settled = true
		r.Approved, r.Ref = true, newID("stl")
		a.settlements = append(a.settlements, SettlementLine{
			SettlementID: r.Ref, CaptureID: captureID, Key: key,
			AmountMinor: c.amount, Currency: c.currency, At: now,
		})
		return r, nil
	})
}

// Query returns the recorded outcome of an operation key. It is how CSDR
// resolves an unknown outcome without risking a second financial effect.
func (a *Acquirer) Query(_ context.Context, key string) (*Result, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	r, ok := a.results[key]
	if !ok {
		return nil, ErrNotFound
	}
	out := *r
	return &out, nil
}

// SettlementReport returns the clearing house's settlement lines.
func (a *Acquirer) SettlementReport() []SettlementLine {
	a.mu.Lock()
	defer a.mu.Unlock()
	return append([]SettlementLine(nil), a.settlements...)
}

// InjectSettlementLine adds a report line directly (tests use it to create
// external discrepancies).
func (a *Acquirer) InjectSettlementLine(l SettlementLine) {
	a.mu.Lock()
	a.settlements = append(a.settlements, l)
	a.mu.Unlock()
}

// Effects returns how many operations of this type actually executed.
func (a *Acquirer) Effects(op Op) int {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.effects[op]
}

// Calls returns how many calls of this type were received (including deduplicated ones).
func (a *Acquirer) Calls(op Op) int {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.calls[op]
}
