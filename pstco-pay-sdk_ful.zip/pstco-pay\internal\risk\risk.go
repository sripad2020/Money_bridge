// Package risk is the rule-based fraud and risk engine. It is pure and fast
// so the orchestrator can run it in parallel with authentication.
package risk

import (
	"fmt"
	"strings"
	"sync"
	"time"

	"pstcopay/internal/model"
)

// Decision is the risk outcome.
type Decision string

const (
	Approve Decision = "APPROVE"
	Review  Decision = "REVIEW" // approved, but flagged for post-transaction review
	Decline Decision = "DECLINE"
)

// Assessment is one risk evaluation.
type Assessment struct {
	Score    float64
	Decision Decision
	Reasons  []string
	At       time.Time
}

// Config tunes the rules.
type Config struct {
	HighAmountMinor  int64         // amounts above this add risk
	VelocityWindow   time.Duration // window for per-customer velocity
	VelocityLimit    int           // payments per window before risk rises
	DeclineThreshold float64
	ReviewThreshold  float64
	Validity         time.Duration // how long an approval stays valid
}

// DefaultConfig returns production-like defaults.
func DefaultConfig() Config {
	return Config{
		HighAmountMinor:  2_00_000_00, // ₹2,00,000
		VelocityWindow:   time.Minute,
		VelocityLimit:    20,
		DeclineThreshold: 0.8,
		ReviewThreshold:  0.5,
		Validity:         10 * time.Minute,
	}
}

// Engine evaluates payments.
type Engine struct {
	cfg Config
	now func() time.Time

	mu       sync.Mutex
	velocity map[string][]time.Time
}

// New creates an engine.
func New(cfg Config) *Engine {
	return &Engine{cfg: cfg, now: time.Now, velocity: map[string][]time.Time{}}
}

// Validity returns how long an approval stays valid.
func (e *Engine) Validity() time.Duration { return e.cfg.Validity }

// Assess scores a payment.
func (e *Engine) Assess(p *model.Payment) Assessment {
	now := e.now()
	a := Assessment{At: now}

	if strings.HasPrefix(p.CardToken, "tok_fraud") {
		a.Score += 1.0
		a.Reasons = append(a.Reasons, "card token on fraud list")
	}
	if p.AmountMinor > e.cfg.HighAmountMinor {
		a.Score += 0.35
		a.Reasons = append(a.Reasons, "high amount")
	}
	if p.AmountMinor > 5*e.cfg.HighAmountMinor {
		a.Score += 0.3
		a.Reasons = append(a.Reasons, "very high amount")
	}

	e.mu.Lock()
	win := e.velocity[p.CustomerID][:0]
	for _, t := range e.velocity[p.CustomerID] {
		if now.Sub(t) < e.cfg.VelocityWindow {
			win = append(win, t)
		}
	}
	win = append(win, now)
	e.velocity[p.CustomerID] = win
	n := len(win)
	e.mu.Unlock()
	if n > e.cfg.VelocityLimit {
		a.Score += 0.5
		a.Reasons = append(a.Reasons, fmt.Sprintf("velocity %d in %s", n, e.cfg.VelocityWindow))
	}

	if a.Score > 1 {
		a.Score = 1
	}
	switch {
	case a.Score >= e.cfg.DeclineThreshold:
		a.Decision = Decline
	case a.Score >= e.cfg.ReviewThreshold:
		a.Decision = Review
	default:
		a.Decision = Approve
	}
	return a
}
