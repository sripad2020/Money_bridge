//go:build !linux && !(windows && cgo)

package transport

import (
	"net"
	"syscall"
)

// TCPInfoSupported reports whether ReadTCPInfo works on this OS. Selecting
// BBR or CUBIC and reading TCP_INFO are Linux kernel features; on other
// systems the controller falls back to application-measured round trips.
const TCPInfoSupported = false

// SetCongestion is unsupported on this OS.
func SetCongestion(*net.TCPConn, string) error { return ErrUnsupported }

// GetCongestion is unsupported on this OS.
func GetCongestion(*net.TCPConn) (string, error) { return "", ErrUnsupported }

// ReadTCPInfo is unsupported on this OS.
func ReadTCPInfo(*net.TCPConn) (*TCPStats, error) { return nil, ErrUnsupported }

// DialControl is a no-op on this OS.
func DialControl(string) func(network, address string, c syscall.RawConn) error { return nil }
