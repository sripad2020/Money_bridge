package offlinesvc_test

import (
	"bytes"
	"context"
	"io"
	"log/slog"
	"strings"
	"testing"
	"time"

	"pstcopay/internal/offlinesvc"
	"pstcopay/internal/store"
	"pstcopay/sdk/client"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/offline/api"
	"pstcopay/sdk/wallet"
	"pstcopay/sdk/wallet/emulator"
)

func TestReceiptsProveAcceptance(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	w, _ := registered(t, e, "9876900001")
	sdir := t.TempDir()
	shop, _ := e.onboard("9876900002", "Shop", true, softElement(t, sdir), sdir)
	e.fund(w, 500_00, 300_00)
	p, _ := w.PayPhone("9876900002", 25_00, wallet.DeliverQR, approvePhone(t, w, "9876900002", 25_00))
	if _, err := shop.Accept(p.QR); err != nil {
		t.Fatal(err)
	}
	rep, err := shop.Sync(ctx)
	if err != nil || rep.Accepted != 1 || rep.BadReceipts != 0 {
		t.Fatalf("sync %+v %v", rep, err)
	}
	_, got, _ := shop.History()
	st, err := offline.VerifyReceipt(got[0].Receipt, got[0].Raw, e.svc.ReceiptPublicKey())
	if err != nil || st != offline.ReceiptAccepted {
		t.Fatalf("receipt: %d %v", st, err)
	}
	// A receipt cannot be moved to another record or forged.
	other := bytes.Clone(got[0].Raw)
	other[60] ^= 1
	if _, err := offline.VerifyReceipt(got[0].Receipt, other, e.svc.ReceiptPublicKey()); err == nil {
		t.Fatal("receipt verified for a different record")
	}
	forged := bytes.Clone(got[0].Receipt)
	forged[29] = offline.ReceiptSettled
	if _, err := offline.VerifyReceipt(forged, got[0].Raw, e.svc.ReceiptPublicKey()); err == nil {
		t.Fatal("altered receipt verified")
	}
	// The payer's later upload gets a duplicate receipt for the same bytes.
	rep, _ = w.Sync(ctx)
	sent, _, _ := w.History()
	if st, err := offline.VerifyReceipt(sent[0].Receipt, sent[0].Raw, e.svc.ReceiptPublicKey()); err != nil || st != offline.ReceiptDuplicate {
		t.Fatalf("payer receipt %d %v (%+v)", st, err, rep)
	}
}

func TestTamperedChainIsCaughtAtTopUp(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	w, dev := registered(t, e, "9876910001")
	e.fund(w, 1000_00, 400_00)
	for _, a := range []int64{10_00, 20_00, 30_00} {
		if _, err := w.PayPhone("9876910002", a, wallet.DeliverQR, approvePhone(t, w, "9876910002", a)); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := w.Sync(ctx); err != nil {
		t.Fatal(err)
	}
	// Someone with database access rewrites one link.
	if _, err := e.st.DB().Exec(`UPDATE offline_records SET prev_hash=? WHERE device_id=? AND counter=2`,
		make([]byte, 16), int64(dev)); err != nil {
		t.Fatal(err)
	}
	_, err := w.CreateReserve(ctx, 100_00, approveOp(t, w, wallet.OpReserve, 100_00))
	if !client.IsCode(err, "chain_broken") {
		t.Fatalf("top-up over a broken chain: %v", err)
	}
	d, _ := e.st.GetDevice(ctx, dev)
	if d.Status != store.DeviceFrozen {
		t.Fatalf("device %s", d.Status)
	}
}

func TestOTPBruteForceLimits(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	c := e.client()
	for i := 0; i < 5; i++ {
		if _, err := c.StartAccount(ctx, api.AccountStartRequest{Phone: "9876920001", Name: "X"}); err != nil {
			t.Fatalf("send %d: %v", i, err)
		}
		e.advance(31 * time.Second)
	}
	if _, err := c.StartAccount(ctx, api.AccountStartRequest{Phone: "9876920001", Name: "X"}); !client.IsCode(err, "otp_rate_limited") {
		t.Fatalf("6th code in an hour: %v", err)
	}
	locked := false
	for i := 0; i < 6; i++ {
		_, err := c.VerifyAccount(ctx, api.AccountVerifyRequest{Phone: "9876920001", OTP: "000000"})
		if client.IsCode(err, "otp_locked") {
			locked = true
			break
		}
	}
	if !locked {
		t.Fatal("wrong codes never locked verification")
	}
}

func TestLogsNeverHoldOTPsOrFullNumbers(t *testing.T) {
	var buf bytes.Buffer
	l := offlinesvc.LogSMS{Log: slog.New(slog.NewTextHandler(&buf, nil))}
	_ = l.Send(context.Background(), "+919876543210", "Your PSTCO-Pay code is 482913. Do not share it.")
	out := buf.String()
	if strings.Contains(out, "482913") || strings.Contains(out, "9876543210") || !strings.Contains(out, "3210") {
		t.Fatalf("log leaks secrets: %s", out)
	}
	_ = io.Discard
}

// swappedKey signs with its own key but replays a genuine app's assertion.
type swappedKey struct {
	*emulator.AppleKeyStore // the attacker's own Secure Enclave key
	genuine                 *emulator.AppleKeyStore
}

func (s swappedKey) Attest(ch []byte) (api.Attestation, error) { return s.genuine.Attest(ch) }

func TestAppAttestAssertionCannotBeReusedForAnotherKey(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	genuine, _ := emulator.NewAppleKeyStore(e.apple, appID)
	attacker, _ := emulator.NewAppleKeyStore(e.apple, appID)
	dir := t.TempDir()
	w := e.openWallet(dir, hwElement(t, dir, swappedKey{AppleKeyStore: attacker, genuine: genuine}))
	otp, _ := w.StartAccount(ctx, "9876930001", "Attacker", false)
	_ = w.VerifyAccount(ctx, "9876930001", otp)
	if _, err := w.Register(ctx); !client.IsCode(err, "attestation_invalid") {
		t.Fatalf("assertion for another key accepted: %v", err)
	}
}
