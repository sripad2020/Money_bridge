// Package engine is the payment orchestration engine: the state-machine
// driven pipeline, the CSDR recovery engine, compensation, the settlement
// worker, reconciliation and Merkle anchoring.
package engine

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"log/slog"
	"slices"
	"sync"
	"time"

	"pstcopay/internal/acquirer"
	"pstcopay/internal/chain"
	"pstcopay/internal/controller"
	"pstcopay/internal/model"
	"pstcopay/internal/risk"
	"pstcopay/internal/store"
)

var (
	ErrInvalidRequest      = errors.New("engine: invalid request")
	ErrIdempotencyConflict = errors.New("engine: idempotency key reused with a different request")
	ErrNotFound            = errors.New("engine: payment not found")
	ErrForbidden           = errors.New("engine: caller may not act on this payment")
	ErrNotRefundable       = errors.New("engine: payment is not in a refundable state")
	ErrBusy                = errors.New("engine: payment is being processed, retry shortly")
)

// Config tunes the engine.
type Config struct {
	DefaultDeadline          time.Duration
	MaxDeadline              time.Duration
	RecoveryDeadline         time.Duration
	MinRecoveryBudget        time.Duration
	MaxAttempts              int
	MaxSettleAttempts        int
	MaxCompensationAttempts  int
	AuthValidity             time.Duration
	ClockSkew                time.Duration
	MaxPaymentTTL            time.Duration
	MaxAmountMinor           int64
	RecoveryInterval         time.Duration
	SettleInterval           time.Duration
	ReconInterval            time.Duration
	AnchorInterval           time.Duration
	CaptureNotSubmittedAfter time.Duration
	AnchorFile               string
	SupportedCurrencies      []string
}

// DefaultConfig returns production-like defaults.
func DefaultConfig() Config {
	return Config{
		DefaultDeadline:          3 * time.Second,
		MaxDeadline:              30 * time.Second,
		RecoveryDeadline:         10 * time.Second,
		MinRecoveryBudget:        15 * time.Millisecond,
		MaxAttempts:              4,
		MaxSettleAttempts:        8,
		MaxCompensationAttempts:  12,
		AuthValidity:             7 * 24 * time.Hour,
		ClockSkew:                5 * time.Minute,
		MaxPaymentTTL:            24 * time.Hour,
		MaxAmountMinor:           1_000_000_000_00,
		RecoveryInterval:         2 * time.Second,
		SettleInterval:           200 * time.Millisecond,
		ReconInterval:            30 * time.Second,
		AnchorInterval:           10 * time.Second,
		CaptureNotSubmittedAfter: time.Minute,
		SupportedCurrencies:      []string{"INR", "USD", "EUR", "GBP", "SGD", "AED", "JPY"},
	}
}

// Metrics receives engine telemetry. The metrics package implements it.
type Metrics interface {
	StageObserved(stage, status string, d time.Duration)
	PaymentFinished(state string, d time.Duration)
	Recovery(decision string)
	Reconciliation(kind string)
	Admission(result string)
	Settlement(result string)
}

type noMetrics struct{}

func (noMetrics) StageObserved(string, string, time.Duration) {}
func (noMetrics) PaymentFinished(string, time.Duration)       {}
func (noMetrics) Recovery(string)                             {}
func (noMetrics) Reconciliation(string)                       {}
func (noMetrics) Admission(string)                            {}
func (noMetrics) Settlement(string)                           {}

// NonceStore issues and consumes single-use execution-authorization nonces.
// Implemented in memory (package nonce) and in Redis (package coord).
type NonceStore interface {
	Issue(ctx context.Context, scope string) (nonce, ref string, err error)
	Consume(ctx context.Context, nonce, scope string) error
}

// Locker serialises processing of one payment. The engine always uses an
// in-process lock; a distributed Locker (Redis) is layered on top so several
// server instances can share one database safely.
type Locker interface {
	Lock(ctx context.Context, key string) (unlock func(), err error)
	TryLock(ctx context.Context, key string) (unlock func(), ok bool)
}

// MerchantCache caches merchant records in front of the database.
type MerchantCache interface {
	Get(ctx context.Context, id string) (*model.Merchant, bool)
	Put(ctx context.Context, m *model.Merchant)
}

// Deps are the engine's collaborators. Locker and Merchants are optional.
type Deps struct {
	Store      *store.Store
	Keys       *chain.KeyRing
	Nonces     NonceStore
	Locker     Locker
	Merchants  MerchantCache
	Acquirer   *acquirer.Acquirer
	Risk       *risk.Engine
	Controller *controller.Controller
	Metrics    Metrics
	Logger     *slog.Logger
}

// Engine is the orchestration engine.
type Engine struct {
	cfg     Config
	store   *store.Store
	keys    *chain.KeyRing
	nonces  NonceStore
	mcache  MerchantCache
	acq     *acquirer.Acquirer
	risk    *risk.Engine
	ctl     *controller.Controller
	metrics Metrics
	log     *slog.Logger
	locks   Locker
	broker  *broker
	now     func() time.Time

	// crashHook is a test seam: returning true simulates a process crash
	// after the downstream call, before its outcome is recorded.
	crashHook func(stage model.Stage) bool

	wg sync.WaitGroup
}

// errSimulatedCrash is returned when crashHook fires.
var errSimulatedCrash = errors.New("engine: simulated crash")

// New creates an engine.
func New(cfg Config, d Deps) *Engine {
	if d.Metrics == nil {
		d.Metrics = noMetrics{}
	}
	if d.Logger == nil {
		d.Logger = slog.Default()
	}
	var locks Locker = newKeyedLock()
	if d.Locker != nil {
		locks = &twoLevelLock{local: locks, remote: d.Locker}
	}
	return &Engine{
		cfg: cfg, store: d.Store, keys: d.Keys, nonces: d.Nonces, mcache: d.Merchants, acq: d.Acquirer,
		risk: d.Risk, ctl: d.Controller, metrics: d.Metrics, log: d.Logger,
		locks: locks, broker: newBroker(), now: func() time.Time { return time.Now().UTC() },
	}
}

// merchant loads a merchant through the cache. Errors are store errors.
func (e *Engine) merchant(ctx context.Context, id string) (*model.Merchant, error) {
	if e.mcache != nil {
		if m, ok := e.mcache.Get(ctx, id); ok {
			return m, nil
		}
	}
	m, err := e.store.GetMerchant(ctx, id)
	if err == nil && e.mcache != nil {
		e.mcache.Put(ctx, m)
	}
	return m, err
}

// twoLevelLock takes the in-process lock first (cheap, avoids hammering the
// remote store with local contention) and then the distributed lock.
type twoLevelLock struct {
	local, remote Locker
}

func (t *twoLevelLock) Lock(ctx context.Context, key string) (func(), error) {
	lu, err := t.local.Lock(ctx, key)
	if err != nil {
		return nil, err
	}
	ru, err := t.remote.Lock(ctx, key)
	if err != nil {
		lu()
		return nil, err
	}
	return func() { ru(); lu() }, nil
}

func (t *twoLevelLock) TryLock(ctx context.Context, key string) (func(), bool) {
	lu, ok := t.local.TryLock(ctx, key)
	if !ok {
		return nil, false
	}
	ru, ok := t.remote.TryLock(ctx, key)
	if !ok {
		lu()
		return nil, false
	}
	return func() { ru(); lu() }, true
}

// SetClock replaces the engine clock (tests).
func (e *Engine) SetClock(now func() time.Time) { e.now = now }

// Controller returns the PSTCO controller.
func (e *Engine) Controller() *controller.Controller { return e.ctl }

// Config returns the engine configuration.
func (e *Engine) Config() Config { return e.cfg }

func newID(prefix string) string {
	b := make([]byte, 12)
	_, _ = rand.Read(b)
	return prefix + "_" + hex.EncodeToString(b)
}

// persist runs fn in a transaction that is not cancelled by the payment's
// deadline: once a downstream call has happened its outcome must be recorded.
func (e *Engine) persist(ctx context.Context, fn func(tx *store.Tx) error) error {
	c, cancel := context.WithTimeout(context.WithoutCancel(ctx), 10*time.Second)
	defer cancel()
	return e.store.WithTx(c, fn)
}

// move changes the payment state inside a transaction.
func (e *Engine) move(ctx context.Context, tx *store.Tx, p *model.Payment, to model.State) error {
	prev := p.State
	p.State = to
	if err := tx.SavePayment(ctx, p, prev, e.now()); err != nil {
		p.State = prev
		return err
	}
	return nil
}

type evSpec struct {
	stage    model.Stage
	attempt  int
	status   model.EventStatus
	deps     []string
	retryOf  string
	payload  map[string]string
	idemKey  string
	nonceRef string
	signer   string
}

// appendEvent seals and appends one event to the payment's execution graph.
func (e *Engine) appendEvent(ctx context.Context, tx *store.Tx, paymentID string, s evSpec) (*chain.Event, error) {
	return tx.AppendEvent(ctx, paymentID, func(prev string, seq int64) (*chain.Event, error) {
		ev := &chain.Event{
			EventID:           newID("evt"),
			PaymentID:         paymentID,
			Seq:               seq,
			Stage:             s.stage,
			Attempt:           max(s.attempt, 1),
			Status:            s.status,
			PreviousEventHash: prev,
			DependencyHashes:  slices.Clone(s.deps),
			RetryOfEventHash:  s.retryOf,
			Payload:           s.payload,
			IdempotencyKey:    s.idemKey,
			NonceReference:    s.nonceRef,
			WorkflowVersion:   chain.WorkflowVersion,
			CreatedAt:         e.now().UnixNano(),
		}
		return ev, ev.Seal(e.keys.Signer(s.signer))
	})
}

func (e *Engine) reload(ctx context.Context, p *model.Payment) *model.Payment {
	fresh, err := e.store.GetPayment(context.WithoutCancel(ctx), p.ID)
	if err != nil {
		return p
	}
	return fresh
}

func deadlineOf(ctx context.Context) time.Time {
	d, _ := ctx.Deadline()
	return d
}

func remaining(ctx context.Context) time.Duration {
	d, ok := ctx.Deadline()
	if !ok {
		return time.Hour
	}
	return time.Until(d)
}

// latestSuccess returns the most recent successful event of a stage.
func latestSuccess(events []*chain.Event, stage model.Stage) *chain.Event {
	for i := len(events) - 1; i >= 0; i-- {
		if events[i].Stage == stage && events[i].Status == model.EventSuccess {
			return events[i]
		}
	}
	return nil
}

// nextAttempt returns the attempt number for a new attempt of stage and the
// unsuccessful event it retries (empty if the stage's last event succeeded).
func nextAttempt(events []*chain.Event, stage model.Stage) (int, string) {
	attempt, retryOf := 0, ""
	for _, ev := range events {
		if ev.Stage != stage {
			continue
		}
		attempt = max(attempt, ev.Attempt)
		if ev.Status == model.EventSuccess {
			retryOf = ""
		} else {
			retryOf = ev.CurrentHash
		}
	}
	return attempt + 1, retryOf
}

func hashes(evs ...*chain.Event) []string {
	var out []string
	for _, ev := range evs {
		if ev != nil {
			out = append(out, ev.CurrentHash)
		}
	}
	return out
}

// GetPayment loads a payment.
func (e *Engine) GetPayment(ctx context.Context, id string) (*model.Payment, error) {
	p, err := e.store.GetPayment(ctx, id)
	if errors.Is(err, store.ErrNotFound) {
		return nil, ErrNotFound
	}
	return p, err
}

// GetPaymentByIdempotency loads a payment by merchant request key.
func (e *Engine) GetPaymentByIdempotency(ctx context.Context, merchantID, key string) (*model.Payment, error) {
	p, err := e.store.GetPaymentByIdempotency(ctx, merchantID, key)
	if errors.Is(err, store.ErrNotFound) {
		return nil, ErrNotFound
	}
	return p, err
}

// Events returns a payment's execution graph.
func (e *Engine) Events(ctx context.Context, id string) ([]*chain.Event, error) {
	return e.store.ListEvents(ctx, id)
}

// VerifyPayment verifies a payment's execution graph.
func (e *Engine) VerifyPayment(ctx context.Context, id string) error {
	evs, err := e.store.ListEvents(ctx, id)
	if err != nil {
		return err
	}
	return chain.VerifyGraph(evs, e.keys)
}

// Merchant loads a merchant record.
func (e *Engine) Merchant(ctx context.Context, id string) (*model.Merchant, error) {
	m, err := e.merchant(ctx, id)
	if errors.Is(err, store.ErrNotFound) {
		return nil, ErrNotFound
	}
	return m, err
}

// PublicKeys exports the service verification keys.
func (e *Engine) PublicKeys() map[string]string { return e.keys.PublicKeys() }

// Subscribe streams state updates for one payment.
func (e *Engine) Subscribe(paymentID string) (<-chan Update, func()) {
	return e.broker.subscribe(paymentID)
}

func (e *Engine) notify(p *model.Payment) {
	e.broker.publish(Update{PaymentID: p.ID, State: p.State, FailureCode: p.FailureCode, At: e.now()})
}

// ------------------------------------------------------------- keyed lock

// keyedLock serialises processing per payment within this process.
type keyedLock struct {
	mu sync.Mutex
	m  map[string]*lockEntry
}

type lockEntry struct {
	ch   chan struct{}
	refs int
}

func newKeyedLock() *keyedLock { return &keyedLock{m: map[string]*lockEntry{}} }

func (k *keyedLock) entry(key string) *lockEntry {
	k.mu.Lock()
	defer k.mu.Unlock()
	e, ok := k.m[key]
	if !ok {
		e = &lockEntry{ch: make(chan struct{}, 1)}
		k.m[key] = e
	}
	e.refs++
	return e
}

func (k *keyedLock) release(key string, e *lockEntry) {
	k.mu.Lock()
	defer k.mu.Unlock()
	e.refs--
	if e.refs == 0 {
		delete(k.m, key)
	}
}

// Lock blocks until the key is held or ctx ends.
func (k *keyedLock) Lock(ctx context.Context, key string) (func(), error) {
	e := k.entry(key)
	select {
	case e.ch <- struct{}{}:
		return func() { <-e.ch; k.release(key, e) }, nil
	case <-ctx.Done():
		k.release(key, e)
		return nil, ctx.Err()
	}
}

// TryLock acquires the key without waiting.
func (k *keyedLock) TryLock(_ context.Context, key string) (func(), bool) {
	e := k.entry(key)
	select {
	case e.ch <- struct{}{}:
		return func() { <-e.ch; k.release(key, e) }, true
	default:
		k.release(key, e)
		return nil, false
	}
}

// ----------------------------------------------------------------- broker

// Update is a payment state change pushed to watchers.
type Update struct {
	PaymentID   string
	State       model.State
	FailureCode model.FailureCode
	At          time.Time
}

type broker struct {
	mu   sync.Mutex
	subs map[string]map[chan Update]struct{}
}

func newBroker() *broker { return &broker{subs: map[string]map[chan Update]struct{}{}} }

func (b *broker) subscribe(id string) (<-chan Update, func()) {
	ch := make(chan Update, 32)
	b.mu.Lock()
	if b.subs[id] == nil {
		b.subs[id] = map[chan Update]struct{}{}
	}
	b.subs[id][ch] = struct{}{}
	b.mu.Unlock()
	var once sync.Once
	return ch, func() {
		once.Do(func() {
			b.mu.Lock()
			delete(b.subs[id], ch)
			if len(b.subs[id]) == 0 {
				delete(b.subs, id)
			}
			b.mu.Unlock()
			close(ch)
		})
	}
}

func (b *broker) publish(u Update) {
	b.mu.Lock()
	defer b.mu.Unlock()
	for ch := range b.subs[u.PaymentID] {
		select {
		case ch <- u:
		default: // slow watcher: drop rather than block payment processing
		}
	}
}
