package engine

import (
	"context"
	"io"
	"log/slog"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/alicebob/miniredis/v2"

	"pstcopay/internal/acquirer"
	"pstcopay/internal/chain"
	"pstcopay/internal/controller"
	"pstcopay/internal/coord"
	"pstcopay/internal/model"
	"pstcopay/internal/risk"
	"pstcopay/internal/store"
)

// instance builds one server instance over a shared database file, Redis and processor.
func instance(t *testing.T, dbPath, redisAddr string, keys *chain.KeyRing, acq *acquirer.Acquirer) (*Engine, *store.Store) {
	t.Helper()
	st, err := store.Open(dbPath)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { st.Close() })
	rd, err := coord.Dial(context.Background(), "redis://"+redisAddr, coord.Options{})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { rd.Close() })
	ccfg := controller.DefaultConfig()
	ccfg.BaseBackoff = time.Millisecond
	cfg := DefaultConfig()
	cfg.AnchorFile = filepath.Join(filepath.Dir(dbPath), "anchors.jsonl")
	e := New(cfg, Deps{Store: st, Keys: keys, Nonces: rd, Locker: rd, Merchants: rd, Acquirer: acq,
		Risk: risk.New(risk.DefaultConfig()), Controller: controller.New(ccfg),
		Logger: slog.New(slog.NewTextHandler(io.Discard, nil))})
	return e, st
}

func TestTwoInstancesShareSQLiteAndRedisSafely(t *testing.T) {
	mr := miniredis.RunT(t)
	dir := t.TempDir()
	db := filepath.Join(dir, "shared.db")
	keys := chain.NewEphemeralKeyRing()
	faults := acquirer.NewScriptedFaults()
	acq := acquirer.New(acquirer.Config{Faults: faults, Latency: func(acquirer.Op) time.Duration { return time.Millisecond }})
	a, st := instance(t, db, mr.Addr(), keys, acq)
	b, _ := instance(t, db, mr.Addr(), keys, acq)
	ctx := context.Background()
	if err := st.UpsertMerchant(ctx, &model.Merchant{ID: testMerchant, Secret: testSecret, Principal: testPrincipal,
		Active: true, MaxAmountMinor: 1e12, AllowReauth: true}); err != nil {
		t.Fatal(err)
	}
	h := &harness{t: t}

	// 1. Duplicate requests split across both instances execute exactly once.
	req := h.request("order-multi", 1234_00, "tok_visa_ok")
	var wg sync.WaitGroup
	ids := make([]string, 12)
	for i := range ids {
		wg.Add(1)
		go func() {
			defer wg.Done()
			e := a
			if i%2 == 1 {
				e = b
			}
			p, err := e.Process(ctx, req, testPrincipal)
			if err != nil {
				t.Errorf("instance %d: %v", i%2, err)
				return
			}
			ids[i] = p.ID
		}()
	}
	wg.Wait()
	for _, id := range ids {
		if id != ids[0] {
			t.Fatalf("instances created different payments: %v", ids)
		}
	}
	if acq.Effects(acquirer.OpAuthorize) != 1 || acq.Effects(acquirer.OpCapture) != 1 {
		t.Fatalf("authorize=%d capture=%d, want 1 each",
			acq.Effects(acquirer.OpAuthorize), acq.Effects(acquirer.OpCapture))
	}

	// 2. A lost capture response is resolved by CSDR using Redis-issued nonces.
	faults.Push(acquirer.OpCapture, acquirer.FaultLostResponse)
	p, err := b.Process(ctx, h.request("order-multi-2", 99_00, "tok_visa_ok"), testPrincipal)
	if err != nil {
		t.Fatal(err)
	}
	if p.State != model.StateSettlementPending || acq.Effects(acquirer.OpCapture) != 2 {
		t.Fatalf("state %s, captures %d", p.State, acq.Effects(acquirer.OpCapture))
	}

	// 3. Both instances run settlement workers concurrently: each payment settles once.
	var sw sync.WaitGroup
	for _, e := range []*Engine{a, b} {
		sw.Add(1)
		go func() { defer sw.Done(); _, _ = e.SettleDue(ctx) }()
	}
	sw.Wait()
	_, _ = a.SettleDue(ctx)
	if got := acq.Effects(acquirer.OpSettle); got != 2 {
		t.Fatalf("settlements %d, want 2", got)
	}
	for _, id := range []string{ids[0], p.ID} {
		evs, _ := st.ListEvents(ctx, id)
		if err := chain.VerifyGraph(evs, keys); err != nil {
			t.Fatalf("graph %s: %v", id, err)
		}
		q, _ := a.GetPayment(ctx, id)
		if q.State != model.StateSettled {
			t.Fatalf("payment %s state %s", id, q.State)
		}
	}

	// 4. The merchant was cached in Redis, and nonces live there with a TTL.
	if !mr.Exists("pstco:merchant:" + testMerchant) {
		t.Fatal("merchant not cached in Redis")
	}
	if len(mr.Keys()) == 0 {
		t.Fatal("no coordination keys in Redis")
	}
}

func TestRedisOutageFailsSafely(t *testing.T) {
	mr := miniredis.RunT(t)
	dir := t.TempDir()
	keys := chain.NewEphemeralKeyRing()
	acq := acquirer.New(acquirer.Config{})
	e, st := instance(t, filepath.Join(dir, "x.db"), mr.Addr(), keys, acq)
	ctx := context.Background()
	_ = st.UpsertMerchant(ctx, &model.Merchant{ID: testMerchant, Secret: testSecret, Principal: testPrincipal,
		Active: true, MaxAmountMinor: 1e12})
	h := &harness{t: t}
	mr.Close() // Redis goes away

	c, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	if _, err := e.Process(c, h.request("order-noredis", 100_00, "tok_visa_ok"), testPrincipal); err == nil {
		t.Fatal("payment proceeded without its coordination lock")
	}
	if acq.Calls(acquirer.OpAuthorize) != 0 {
		t.Fatal("money moved without coordination")
	}
}
