//go:build windows && cgo

package transport

import (
	"net"
	"syscall"

	"pstcopay/sdk/netprobe"
)

// TCPInfoSupported: with cgo, the C library reads SIO_TCP_INFO on Windows
// 10 1703 and later, so the PSTCO controller gets kernel RTT and cwnd.
const TCPInfoSupported = true

// SetCongestion is unsupported: Windows selects congestion control per
// system template (netsh int tcp set supplemental), not per socket.
func SetCongestion(*net.TCPConn, string) error { return ErrUnsupported }

// GetCongestion reports the system choice.
func GetCongestion(*net.TCPConn) (string, error) { return "windows-system", nil }

// ReadTCPInfo reads kernel TCP statistics through the C library.
func ReadTCPInfo(c *net.TCPConn) (*TCPStats, error) {
	s, err := netprobe.Stats(c)
	if err != nil {
		return nil, err
	}
	return &TCPStats{RTT: s.RTT, RTTVar: s.RTTVar, TotalRetrans: s.Retransmitted, CongWindow: s.CongWindow}, nil
}

// DialControl is a no-op on Windows.
func DialControl(string) func(network, address string, c syscall.RawConn) error { return nil }
