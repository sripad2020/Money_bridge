// Package nonce issues single-use, scoped, expiring execution-authorization
// nonces. A stage attempt must consume its nonce before calling downstream,
// so a duplicated or replayed internal instruction cannot execute twice.
//
// Nonces are temporary coordination data. Expiry only removes the nonce; the
// durable execution graph keeps a hash reference to it forever.
package nonce

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"sync"
	"time"
)

var (
	ErrUnknown       = errors.New("nonce: unknown")
	ErrExpired       = errors.New("nonce: expired")
	ErrUsed          = errors.New("nonce: already used")
	ErrScopeMismatch = errors.New("nonce: scope mismatch")
)

type entry struct {
	scope string
	exp   time.Time
	used  bool
}

// Store is an in-memory TTL nonce store.
type Store struct {
	mu   sync.Mutex
	m    map[string]*entry
	ttl  time.Duration
	now  func() time.Time
	stop chan struct{}
}

// New creates a store and starts a janitor that purges expired nonces.
func New(ttl time.Duration) *Store {
	s := &Store{m: map[string]*entry{}, ttl: ttl, now: time.Now, stop: make(chan struct{})}
	go s.janitor()
	return s
}

// Close stops the janitor.
func (s *Store) Close() { close(s.stop) }

// Issue creates a nonce for scope. It returns the secret nonce and its public
// reference (a hash), which is what gets recorded in the execution graph.
func (s *Store) Issue(_ context.Context, scope string) (nonce, ref string, err error) {
	nonce = New16()
	s.mu.Lock()
	s.m[nonce] = &entry{scope: scope, exp: s.now().Add(s.ttl)}
	s.mu.Unlock()
	return nonce, Ref(nonce), nil
}

// New16 returns a random 128-bit nonce in hex.
func New16() string {
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

// Ref returns the public reference of a nonce.
func Ref(nonce string) string {
	sum := sha256.Sum256([]byte("pstco-nonce/1\x00" + nonce))
	return hex.EncodeToString(sum[:16])
}

// Consume marks the nonce used. It fails if the nonce is unknown, expired,
// already used, or bound to a different scope.
func (s *Store) Consume(_ context.Context, nonce, scope string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, ok := s.m[nonce]
	switch {
	case !ok:
		return ErrUnknown
	case e.scope != scope:
		return ErrScopeMismatch
	case e.used:
		return ErrUsed
	case s.now().After(e.exp):
		return ErrExpired
	}
	e.used = true
	return nil
}

// Len returns the number of live nonces.
func (s *Store) Len() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.m)
}

func (s *Store) janitor() {
	t := time.NewTicker(time.Second)
	defer t.Stop()
	for {
		select {
		case <-s.stop:
			return
		case <-t.C:
			now := s.now()
			s.mu.Lock()
			for k, e := range s.m {
				if now.After(e.exp) {
					delete(s.m, k)
				}
			}
			s.mu.Unlock()
		}
	}
}
