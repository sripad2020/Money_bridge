# Builds the C network library (native/pstconet) as a shared library for
# Python (ctypes) and optionally builds the Go binaries with it linked in.
#
#   powershell -ExecutionPolicy Bypass -File scripts\build-native.ps1          # pstconet.dll
#   powershell -ExecutionPolicy Bypass -File scripts\build-native.ps1 -Go      # + cgo Go binaries in bin\native
#
# Uses CC if set, else gcc/clang on PATH, else zig cc (pip install ziglang).
param([switch]$Go)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$src = Join-Path $root "native\pstconet\pstconet.c"
$out = Join-Path $root "native\pstconet\build"
New-Item -ItemType Directory -Force $out | Out-Null

$cc = $env:CC
if (-not $cc) {
    foreach ($c in "gcc", "clang") { if (Get-Command $c -ErrorAction SilentlyContinue) { $cc = $c; break } }
}
if (-not $cc) {
    $zig = python -c "import ziglang, os; print(os.path.join(os.path.dirname(ziglang.__file__), 'zig.exe'))" 2>$null
    if ($zig -and (Test-Path $zig)) { $cc = "$zig cc -target x86_64-windows-gnu" }
}
if (-not $cc) { throw "No C compiler: install gcc/clang, or run: python -m pip install ziglang" }

$parts = $cc -split " "
$exe = $parts[0]; $ccArgs = @($parts | Select-Object -Skip 1)
& $exe @ccArgs -shared -O2 -o (Join-Path $out "pstconet.dll") $src -lws2_32
if ($LASTEXITCODE -ne 0) { throw "C build failed" }
Write-Host "built $(Join-Path $out 'pstconet.dll')"

if ($Go) {
    $env:CGO_ENABLED = "1"; $env:CC = $cc
    Push-Location $root
    try { go build -o bin\native\ ./cmd/... ; Write-Host "built cgo binaries in bin\native" } finally { Pop-Location }
}
