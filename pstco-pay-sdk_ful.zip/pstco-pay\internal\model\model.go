// Package model defines the core payment domain types shared by every
// PSTCO-Pay component: stages, states, failure codes, requests and payments.
package model

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"strconv"
	"strings"
	"time"
)

// Stage is one operation in the payment execution graph.
type Stage string

const (
	StageCreate       Stage = "CREATE"
	StageValidate     Stage = "VALIDATE"
	StageAuthenticate Stage = "AUTHENTICATE"
	StageRisk         Stage = "RISK"
	StageAuthorize    Stage = "AUTHORIZE"
	StageCapture      Stage = "CAPTURE"
	StageSettle       Stage = "SETTLE"
	StageVoid         Stage = "VOID"
	StageRefund       Stage = "REFUND"
	StageRecovery     Stage = "RECOVERY"

	// Offline payment stages, recorded server-side for each synced record.
	StageOfflineReceive Stage = "OFFLINE_RECEIVE"
	StageOfflineVerify  Stage = "OFFLINE_VERIFY"
	StageOfflineSettle  Stage = "OFFLINE_SETTLE"
)

// EventStatus is the outcome recorded by one execution event.
type EventStatus string

const (
	EventPending  EventStatus = "PENDING"
	EventSuccess  EventStatus = "SUCCESS"
	EventSoftFail EventStatus = "SOFT_FAIL"
	EventHardFail EventStatus = "HARD_FAIL"
)

// State is the payment state-machine state.
type State string

const (
	StateCreated              State = "CREATED"
	StateValidating           State = "VALIDATING"
	StateValidated            State = "VALIDATED"
	StateAuthenticating       State = "AUTHENTICATING"
	StateAuthenticated        State = "AUTHENTICATED"
	StateRiskPending          State = "RISK_PENDING"
	StateAuthorizing          State = "AUTHORIZING"
	StateAuthorized           State = "AUTHORIZED"
	StateCapturing            State = "CAPTURING"
	StateCaptured             State = "CAPTURED"
	StateSettlementPending    State = "SETTLEMENT_PENDING"
	StateSettlementProcessing State = "SETTLEMENT_PROCESSING"
	StateSettled              State = "SETTLED"

	StateSoftFailure            State = "SOFT_FAILURE"
	StateRecoveryPending        State = "RECOVERY_PENDING"
	StateDependencyVerification State = "DEPENDENCY_VERIFICATION"
	StateRetryOrResume          State = "RETRY_OR_RESUME"

	StateDeclined               State = "DECLINED"
	StateUnknownOutcome         State = "UNKNOWN_OUTCOME"
	StateReconciliationRequired State = "RECONCILIATION_REQUIRED"
	StateFailed                 State = "FAILED"
	StateCompensating           State = "COMPENSATING"
	StateCompensated            State = "COMPENSATED"
)

// Terminal reports whether no further automatic processing will happen.
func (s State) Terminal() bool {
	switch s {
	case StateSettled, StateDeclined, StateFailed, StateCompensated:
		return true
	}
	return false
}

// NeedsRecovery reports whether CSDR must inspect the payment before it can move.
func (s State) NeedsRecovery() bool {
	switch s {
	case StateSoftFailure, StateUnknownOutcome, StateRecoveryPending,
		StateDependencyVerification, StateRetryOrResume,
		StateAuthorizing, StateCapturing, StateCompensating:
		return true
	}
	return false
}

// Resumable reports whether the payment sits cleanly between two stages and
// the orchestrator can simply continue the pipeline.
func (s State) Resumable() bool {
	switch s {
	case StateCreated, StateValidated, StateRiskPending, StateAuthorized, StateCaptured:
		return true
	}
	return false
}

// FailureCode classifies why a stage did not succeed.
type FailureCode string

const (
	FailNone               FailureCode = ""
	FailTransientNetwork   FailureCode = "TRANSIENT_NETWORK"
	FailServiceUnavailable FailureCode = "SERVICE_UNAVAILABLE"
	FailResponseTimeout    FailureCode = "RESPONSE_TIMEOUT"
	FailAuthExpired        FailureCode = "AUTH_EXPIRED"
	FailBusinessRejection  FailureCode = "BUSINESS_REJECTION"
	FailSignatureMismatch  FailureCode = "SIGNATURE_MISMATCH"
	FailHashMismatch       FailureCode = "HASH_MISMATCH"
	FailDependencyInvalid  FailureCode = "DEPENDENCY_INVALID"
	FailOverload           FailureCode = "OVERLOAD"
	FailValidation         FailureCode = "VALIDATION_FAILED"
	FailAuthentication     FailureCode = "AUTHENTICATION_FAILED"
	FailRiskDeclined       FailureCode = "RISK_DECLINED"
	FailPaymentExpired     FailureCode = "PAYMENT_EXPIRED"
	FailMerchantDisabled   FailureCode = "MERCHANT_DISABLED"
	FailRetriesExhausted   FailureCode = "RETRIES_EXHAUSTED"
	FailInternal           FailureCode = "INTERNAL"
)

// Retryable reports whether CSDR may attempt the same logical operation again.
func (c FailureCode) Retryable() bool {
	switch c {
	case FailTransientNetwork, FailServiceUnavailable, FailResponseTimeout, FailOverload, FailInternal:
		return true
	}
	return false
}

// PaymentRequest is what a merchant submits. Amounts are in minor units
// (paise for INR), never floating point.
type PaymentRequest struct {
	MerchantID     string
	CustomerID     string
	IdempotencyKey string
	AmountMinor    int64
	Currency       string
	CardToken      string
	ClientTime     time.Time
	ExpiresAt      time.Time
	DeadlineMS     int64
	Signature      string
}

// SigningString is the canonical byte string covered by the merchant's
// request signature. Validation guarantees no field contains a newline.
func (r *PaymentRequest) SigningString() string {
	return strings.Join([]string{
		"pstco-req/1",
		r.MerchantID,
		r.CustomerID,
		r.IdempotencyKey,
		strconv.FormatInt(r.AmountMinor, 10),
		r.Currency,
		r.CardToken,
		strconv.FormatInt(r.ClientTime.UnixMilli(), 10),
		strconv.FormatInt(r.ExpiresAt.UnixMilli(), 10),
	}, "\n")
}

// Fingerprint identifies the request body, used to detect idempotency-key reuse
// with a different payload.
func (r *PaymentRequest) Fingerprint() string {
	sum := sha256.Sum256([]byte(r.SigningString()))
	return hex.EncodeToString(sum[:])
}

// SignRequest computes the HMAC-SHA256 request signature for a merchant secret.
func SignRequest(r *PaymentRequest, secret string) string {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(r.SigningString()))
	return hex.EncodeToString(mac.Sum(nil))
}

// VerifyRequestSignature checks the request signature in constant time.
func VerifyRequestSignature(r *PaymentRequest, secret string) bool {
	want, err := hex.DecodeString(SignRequest(r, secret))
	if err != nil {
		return false
	}
	got, err := hex.DecodeString(r.Signature)
	if err != nil {
		return false
	}
	return hmac.Equal(want, got)
}

// Payment is the authoritative payment record.
type Payment struct {
	ID             string
	MerchantID     string
	CustomerID     string
	IdempotencyKey string
	RequestHash    string
	AmountMinor    int64
	Currency       string
	CardToken      string
	ClientTime     time.Time
	ExpiresAt      time.Time
	DeadlineMS     int64
	Signature      string
	Principal      string

	State         State
	FailureCode   FailureCode
	FailureReason string

	RiskScore      float64
	RiskDecision   string
	RiskApprovedAt time.Time

	AuthID       string
	AuthKey      string
	AuthorizedAt time.Time
	CaptureID    string
	CapturedAt   time.Time
	SettlementID string
	SettledAt    time.Time
	RefundID     string

	CreatedAt time.Time
	UpdatedAt time.Time
	Version   int64
}

// Request rebuilds the signed merchant request from the stored payment.
func (p *Payment) Request() *PaymentRequest {
	return &PaymentRequest{
		MerchantID:     p.MerchantID,
		CustomerID:     p.CustomerID,
		IdempotencyKey: p.IdempotencyKey,
		AmountMinor:    p.AmountMinor,
		Currency:       p.Currency,
		CardToken:      p.CardToken,
		ClientTime:     p.ClientTime,
		ExpiresAt:      p.ExpiresAt,
		DeadlineMS:     p.DeadlineMS,
		Signature:      p.Signature,
	}
}

// Merchant is a registered merchant allowed to submit payments.
type Merchant struct {
	ID             string
	Secret         string
	Principal      string // expected mTLS certificate common name
	Active         bool
	MaxAmountMinor int64
	AllowReauth    bool
}
