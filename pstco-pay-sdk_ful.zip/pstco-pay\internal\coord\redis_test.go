package coord

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/alicebob/miniredis/v2"
	"github.com/redis/go-redis/v9"

	"pstcopay/internal/model"
	"pstcopay/internal/nonce"
)

func newRedis(t *testing.T, o Options) (*Redis, *miniredis.Miniredis) {
	t.Helper()
	mr := miniredis.RunT(t)
	r, err := Dial(context.Background(), "redis://"+mr.Addr(), o)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { r.Close() })
	return r, mr
}

func TestRedisNonceSingleUseScopedExpiring(t *testing.T) {
	ctx := context.Background()
	r, mr := newRedis(t, Options{NonceTTL: time.Minute})
	n, ref, err := r.Issue(ctx, "pay_1:CAPTURE:1")
	if err != nil || ref != nonce.Ref(n) {
		t.Fatalf("issue: %v", err)
	}
	if err := r.Consume(ctx, n, "pay_1:CAPTURE:2"); !errors.Is(err, nonce.ErrScopeMismatch) {
		t.Fatalf("scope: %v", err)
	}
	if err := r.Consume(ctx, n, "pay_1:CAPTURE:1"); err != nil {
		t.Fatal(err)
	}
	if err := r.Consume(ctx, n, "pay_1:CAPTURE:1"); !errors.Is(err, nonce.ErrUsed) {
		t.Fatalf("replay: %v", err)
	}
	m, _, _ := r.Issue(ctx, "x")
	mr.FastForward(2 * time.Minute)
	if err := r.Consume(ctx, m, "x"); !errors.Is(err, nonce.ErrUnknown) {
		t.Fatalf("expired: %v", err)
	}
}

func TestRedisLockIsExclusiveAndRenewed(t *testing.T) {
	ctx := context.Background()
	r, mr := newRedis(t, Options{LockTTL: 300 * time.Millisecond})
	unlock, ok := r.TryLock(ctx, "pay_1")
	if !ok {
		t.Fatal("first lock failed")
	}
	if _, ok := r.TryLock(ctx, "pay_1"); ok {
		t.Fatal("second holder acquired a held lock")
	}
	time.Sleep(700 * time.Millisecond) // longer than the TTL: the watchdog must renew
	if _, ok := r.TryLock(ctx, "pay_1"); ok {
		t.Fatal("lock expired while still held")
	}
	unlock()
	if !mr.Exists("pstco:lock:pay_1") {
		u2, ok := r.TryLock(ctx, "pay_1")
		if !ok {
			t.Fatal("lock not reacquirable after unlock")
		}
		u2()
	} else {
		t.Fatal("unlock left the key behind")
	}
}

func TestRedisLockSerialisesConcurrentHolders(t *testing.T) {
	r, _ := newRedis(t, Options{})
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	var inside, maxInside atomic.Int32
	var wg sync.WaitGroup
	for range 20 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			unlock, err := r.Lock(ctx, "pay_hot")
			if err != nil {
				t.Error(err)
				return
			}
			n := inside.Add(1)
			for {
				m := maxInside.Load()
				if n <= m || maxInside.CompareAndSwap(m, n) {
					break
				}
			}
			time.Sleep(2 * time.Millisecond)
			inside.Add(-1)
			unlock()
		}()
	}
	wg.Wait()
	if maxInside.Load() != 1 {
		t.Fatalf("%d holders inside the lock at once", maxInside.Load())
	}
}

func TestRedisMerchantCache(t *testing.T) {
	ctx := context.Background()
	r, mr := newRedis(t, Options{CacheTTL: time.Minute})
	if _, ok := r.Get(ctx, "m1"); ok {
		t.Fatal("empty cache hit")
	}
	r.Put(ctx, &model.Merchant{ID: "m1", Principal: "p", Active: true, MaxAmountMinor: 5})
	m, ok := r.Get(ctx, "m1")
	if !ok || m.Principal != "p" || !m.Active {
		t.Fatalf("cache get: %+v %v", m, ok)
	}
	mr.FastForward(2 * time.Minute)
	if _, ok := r.Get(ctx, "m1"); ok {
		t.Fatal("cache entry outlived its TTL")
	}
	r.Put(ctx, &model.Merchant{ID: "m1"})
	_ = r.Invalidate(ctx, "m1")
	if _, ok := r.Get(ctx, "m1"); ok {
		t.Fatal("invalidate did not remove entry")
	}
}

var _ redis.UniversalClient = (*redis.Client)(nil)
