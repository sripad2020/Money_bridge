package offlinesvc_test

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"testing"
	"time"

	"pstcopay/internal/offlinesvc"
	"pstcopay/sdk/client"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/offline/api"
	"pstcopay/sdk/wallet"
)

// signedPost sends a raw device-signed request, so tests can send bodies the
// Go client would refuse to build.
func signedPost(t *testing.T, e *env, w *wallet.Wallet, dev uint64, path, nonce string, body []byte) (int, api.Error) {
	t.Helper()
	ts := e.clock().Unix()
	sig, err := w.Element().SignAuth(api.RequestMessage("POST", path, ts, nonce, body))
	if err != nil {
		t.Fatal(err)
	}
	req, _ := http.NewRequest("POST", e.srv.URL+path, bytes.NewReader(body))
	req.Header.Set(api.HeaderDevice, offline.FormatID(dev))
	req.Header.Set(api.HeaderTimestamp, strconv.FormatInt(ts, 10))
	req.Header.Set(api.HeaderNonce, nonce)
	req.Header.Set(api.HeaderSignature, b64(sig))
	req.Header.Set(api.HeaderIdempotency, client.NewIdempotencyKey())
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	var ae api.Error
	_ = json.NewDecoder(resp.Body).Decode(&ae)
	return resp.StatusCode, ae
}

func registered(t *testing.T, e *env, phone string) (*wallet.Wallet, uint64) {
	dir := t.TempDir()
	w, reg := e.onboard(phone, "User "+phone, false, softElement(t, dir), dir)
	dev, _ := offline.ParseID(reg.DeviceID)
	return w, dev
}

func TestStrictTypesAtTheAPIBoundary(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	w, dev := registered(t, e, "9876700001")
	cl := e.client().WithDevice(dev, w.Element())
	cases := map[string]string{
		"decimal for an integer":  `{"amount_paise":100.5}`,
		"exponent for an integer": `{"amount_paise":1e4}`,
		"string for an integer":   `{"amount_paise":"10000"}`,
		"boolean for an integer":  `{"amount_paise":true}`,
		"unknown field":           `{"amount_paise":100,"credit":true}`,
		"duplicate field":         `{"amount_paise":1,"amount_paise":99999999}`,
		"negative amount":         `{"amount_paise":-5}`,
	}
	for name, body := range cases {
		n, err := cl.AuthNonce(ctx, api.PurposeDeposit)
		if err != nil {
			t.Fatal(err)
		}
		status, ae := signedPost(t, e, w, dev, api.PathDeposit, n.Nonce, []byte(body))
		if status != 400 || ae.Code != "invalid_request" {
			t.Errorf("%s: status %d %+v", name, status, ae)
		}
	}
	// Public endpoints are checked the same way.
	resp, _ := http.Post(e.srv.URL+api.PathAccountVerify, "application/json",
		bytes.NewReader([]byte(`{"phone":"9876700001","otp":123456}`)))
	if resp.StatusCode != 400 {
		t.Fatalf("numeric OTP accepted: %d", resp.StatusCode)
	}
	resp.Body.Close()
}

func TestMoneyRequestsNeedAServerNonce(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	w, dev := registered(t, e, "9876710001")
	body := []byte(`{"amount_paise":100}`)
	if s, ae := signedPost(t, e, w, dev, api.PathDeposit, client.NewIdempotencyKey(), body); s != 401 || ae.Code != "server_nonce_required" {
		t.Fatalf("client-made nonce: %d %+v", s, ae)
	}
	cl := e.client().WithDevice(dev, w.Element())
	n, _ := cl.AuthNonce(ctx, api.PurposeReserve)
	if s, ae := signedPost(t, e, w, dev, api.PathDeposit, n.Nonce, body); s != 401 || ae.Code != "server_nonce_invalid" {
		t.Fatalf("reserve nonce used for a deposit: %d %+v", s, ae)
	}
	n, _ = cl.AuthNonce(ctx, api.PurposeDeposit)
	if s, _ := signedPost(t, e, w, dev, api.PathDeposit, n.Nonce, body); s != 200 {
		t.Fatalf("valid nonce: %d", s)
	}
	if s, ae := signedPost(t, e, w, dev, api.PathDeposit, n.Nonce, body); s != 401 {
		t.Fatalf("reused nonce: %d %+v", s, ae)
	}
	if len(n.Nonce) != 64 {
		t.Fatalf("nonce is %d hex characters, want 64 (256 bits)", len(n.Nonce))
	}
	seen := map[string]bool{}
	for range 200 {
		m, err := cl.AuthNonce(ctx, api.PurposeDeposit)
		if err != nil {
			t.Fatal(err)
		}
		if seen[m.Nonce] {
			t.Fatal("server nonce repeated")
		}
		seen[m.Nonce] = true
	}
}

func TestRepeatedAuthFailuresLockTheDevice(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	_, dev := registered(t, e, "9876720001")
	_, other := registered(t, e, "9876720002")
	_ = other
	impostor, _ := wallet.CreateSealedElement(t.TempDir(), pin, nil, wallet.ElementOptions{KDF: wallet.TestKDF})
	_ = impostor.Unlock(pin)
	bad := e.client().WithDevice(dev, impostor) // signs with the wrong key
	for i := 0; i < 5; i++ {
		if _, err := bad.Wallet(ctx); !client.IsCode(err, "unauthenticated") {
			t.Fatalf("attempt %d: %v", i, err)
		}
	}
	if _, err := bad.Wallet(ctx); !client.IsCode(err, "device_locked") {
		t.Fatalf("after 5 failures: %v", err)
	}
	evs, _ := e.st.ListSecurityEvents(ctx, offlinesvc.EventAuthLockout, 10)
	if len(evs) != 1 {
		t.Fatalf("lockout events %d", len(evs))
	}
}

func TestPublicEndpointsAreRateLimitedPerIP(t *testing.T) {
	e := newEnv(t)
	limited := false
	for i := 0; i < 40; i++ {
		resp, err := http.Get(e.srv.URL + api.PathCA)
		if err != nil {
			t.Fatal(err)
		}
		resp.Body.Close()
		if resp.StatusCode == 429 {
			limited = true
			break
		}
	}
	if !limited {
		t.Fatal("no rate limit after 40 requests in a minute")
	}
}

func TestWalletApprovalGuardrail(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	w, _ := registered(t, e, "9876730001")
	e.fund(w, 500_00, 300_00)
	q, _ := w.QuotePhone("9876730002")

	if _, err := w.Pay(q, 50_00, wallet.DeliverQR, nil); !errors.Is(err, wallet.ErrApprovalRequired) {
		t.Fatalf("no approval: %v", err)
	}
	a := approvePay(t, w, q.PayeeID, 50_00)
	if len(a.Token) != 64 {
		t.Fatalf("approval token %d hex characters", len(a.Token))
	}
	if _, err := w.Pay(q, 90_00, wallet.DeliverQR, a); !errors.Is(err, wallet.ErrApprovalInvalid) {
		t.Fatalf("approval for 50 used for 90: %v", err)
	}
	// The mismatched attempt burned the token.
	if _, err := w.Pay(q, 50_00, wallet.DeliverQR, a); !errors.Is(err, wallet.ErrApprovalInvalid) {
		t.Fatalf("burned approval reused: %v", err)
	}
	if b, _ := w.Balance(); b.OfflinePaise != 300_00 {
		t.Fatalf("money moved without approval: %d", b.OfflinePaise)
	}
	good := approvePay(t, w, q.PayeeID, 50_00)
	if _, err := w.Pay(q, 50_00, wallet.DeliverQR, good); err != nil {
		t.Fatalf("approved payment: %v", err)
	}
	// Third violation locks the wallet.
	forged := &wallet.Approval{Token: "00" + good.Token[2:], Intent: good.Intent}
	if _, err := w.Pay(q, 50_00, wallet.DeliverQR, forged); !errors.Is(err, wallet.ErrAccessDenied) {
		t.Fatalf("third violation: %v", err)
	}
	if _, err := w.Approve(wallet.Intent{Op: wallet.OpPay, AmountPaise: 1, PayeeID: q.PayeeID}, pin); !errors.Is(err, wallet.ErrLocked) {
		t.Fatalf("wallet still usable after lockout: %v", err)
	}
	if err := w.Unlock(pin); err != nil {
		t.Fatal(err)
	}
	// Approvals expire.
	old := approvePay(t, w, q.PayeeID, 10_00)
	e.advance(2 * time.Minute)
	if _, err := w.Pay(q, 10_00, wallet.DeliverQR, old); !errors.Is(err, wallet.ErrApprovalInvalid) {
		t.Fatalf("expired approval: %v", err)
	}
	// Wrong PINs at approval lock the wallet after five tries.
	for i := 0; i < 4; i++ {
		if _, err := w.Approve(wallet.Intent{Op: wallet.OpDeposit, AmountPaise: 1}, "000000"); !errors.Is(err, wallet.ErrWrongPIN) {
			t.Fatalf("wrong PIN %d: %v", i, err)
		}
	}
	if _, err := w.Approve(wallet.Intent{Op: wallet.OpDeposit, AmountPaise: 1}, "000000"); !errors.Is(err, wallet.ErrLockedOut) {
		t.Fatalf("fifth wrong PIN: %v", err)
	}
	_ = ctx
}

func TestAsyncSyncJob(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	w, dev := registered(t, e, "9876740001")
	otherW, other := registered(t, e, "9876740002")
	e.fund(w, 500_00, 300_00)
	var records [][]byte
	for _, amt := range []int64{10_00, 20_00, 30_00} {
		p, err := w.PayPhone("9876740002", amt, wallet.DeliverQR, approvePhone(t, w, "9876740002", amt))
		if err != nil {
			t.Fatal(err)
		}
		records = append(records, p.Record)
	}
	cl := e.client().WithDevice(dev, w.Element())
	job, err := cl.SyncAsync(ctx, api.SyncRequest{Records: records})
	if err != nil || job.Status != "QUEUED" || job.Submitted != 3 {
		t.Fatalf("submit: %+v %v", job, err)
	}
	wctx, cancel := context.WithTimeout(ctx, 10*time.Second)
	defer cancel()
	done, err := cl.WaitSyncJob(wctx, job.JobID, 20*time.Millisecond)
	if err != nil || len(done.Results) != 3 {
		t.Fatalf("wait: %+v %v", done, err)
	}
	for _, r := range done.Results {
		if r.Status != api.StatusAccepted {
			t.Fatalf("result %+v", r)
		}
	}
	// Another device cannot read the job.
	ow := e.client().WithDevice(other, otherW.Element())
	if _, err := ow.SyncJob(ctx, job.JobID); !client.IsCode(err, "not_found") {
		t.Fatalf("other device read the job: %v", err)
	}
	// Async helper overlaps calls.
	r1 := client.Async(ctx, func(c context.Context) (*api.WalletResponse, error) { return cl.Wallet(c) })
	r2 := client.Async(ctx, func(c context.Context) (*api.DirectoryResponse, error) { return cl.Directory(c) })
	if a, b := <-r1, <-r2; a.Err != nil || b.Err != nil {
		t.Fatalf("async calls: %v %v", a.Err, b.Err)
	}
}
