"""End-to-end against a real pstco-server: Python wallets (blocking and
asyncio), guardrails, strict server types, the C probe, and interop with
the Go wallet CLI."""

import asyncio
import os
import subprocess
import time

import pytest

from pstco import native
from pstco.client import APIError, AsyncClient, Client
from pstco.formats import payee_id_for_phone
from pstco.wallet import AccessDenied, ApprovalInvalid, ApprovalRequired, AsyncSoftwareWallet, SoftwareWallet

PIN = "135790"


def onboard(server, tmp_path, phone, name, listed=False):
    w = SoftwareWallet.create(tmp_path / f"w{phone}", PIN, Client(server["url"], server["ca"]), kdf_n=2 ** 10)
    otp = w.start_account(phone, name, listed)
    w.verify_account(phone, otp)
    w.set_name(name)
    reg = w.register()
    assert reg["trust"] == "software"
    return w


def fund(w, deposit, reserve):
    w.deposit(deposit, w.approve("deposit", deposit, PIN))
    w.create_reserve(reserve, w.approve("reserve", reserve, PIN))


def test_python_wallets_pay_offline_and_settle(server, tmp_path, phone):
    p_payer, p_shop = phone(), phone()
    shop = onboard(server, tmp_path, p_shop, "Python Kirana", listed=True)
    payer = onboard(server, tmp_path, p_payer, "Meena")
    fund(payer, 1000_00, 500_00)
    payer.sync()  # directory
    q = payer.quote_phone(p_shop)
    assert q["listed"] and q["name"] == "Python Kirana"
    pay = payer.pay(q, 199_99, "qr", payer.approve("pay", 199_99, PIN, q["payee_id"]))
    got = shop.accept(pay["qr"])
    assert got["amount_paise"] == 199_99
    rep = shop.sync()
    assert rep["accepted"] == 1 and rep["bad_receipts"] == 0
    from pstco.formats import verify_receipt
    item = shop._state()["received"][0]
    import base64 as _b64
    assert verify_receipt(_b64.b64decode(item["receipt"]), _b64.b64decode(item["raw"]),
                          _b64.b64decode(shop._state()["receipt_key"])) == "accepted"
    assert payer.sync()["duplicate"] == 1
    assert payer.balance()["offline_paise"] == 500_00 - 199_99
    for _ in range(50):
        w = shop.client.with_device(shop.device_id, shop).wallet()
        if w["settled_incoming_paise"] == 199_99:
            break
        time.sleep(0.1)
    assert w["available_paise"] == 199_99


def test_approval_guardrail(server, tmp_path, phone):
    w = onboard(server, tmp_path, phone(), "Guarded")
    with pytest.raises(ApprovalRequired):
        w.deposit(100_00, None)
    a = w.approve("deposit", 100_00, PIN)
    assert len(a.token) == 64
    with pytest.raises(ApprovalInvalid):
        w.deposit(999_00, a)  # approved 100, asked 999
    with pytest.raises(ApprovalInvalid):
        w.deposit(100_00, a)  # burned
    with pytest.raises(AccessDenied):
        w.deposit(100_00, a)  # third violation locks the wallet


def test_server_enforces_strict_types(server, tmp_path, phone):
    w = onboard(server, tmp_path, phone(), "Typed")
    c = w.client.with_device(w.device_id, w)
    for body in ({"amount_paise": 100.5}, {"amount_paise": "100"}, {"amount_paise": True}, {"amount_paise": 1, "x": 1}):
        nonce = c.auth_nonce("deposit")["nonce"]
        with pytest.raises(APIError) as e:
            c._do("POST", "/v1/wallet/deposit", body, True, os.urandom(8).hex(), nonce)
        assert e.value.status == 400 and e.value.code == "invalid_request"
    with pytest.raises(APIError) as e:  # a client-made nonce cannot move money
        c._do("POST", "/v1/wallet/deposit", {"amount_paise": 100}, True, os.urandom(8).hex(), os.urandom(32).hex())
    assert e.value.code == "server_nonce_invalid"


def test_async_wallets_run_concurrently(server, tmp_path, phone):
    async def main():
        p1, p2, shop_phone = phone(), phone(), phone()
        shop = onboard(server, tmp_path, shop_phone, "Async Shop", listed=True)

        async def one(p):
            ac = AsyncClient(server["url"], server["ca"])
            w = AsyncSoftwareWallet.create(tmp_path / f"a{p}", PIN, ac, kdf_n=2 ** 10)
            otp = await w.start_account(p, "Async " + p)
            await w.verify_account(p, otp)
            await w.register()
            await w.deposit(300_00, w.approve("deposit", 300_00, PIN))
            await w.create_reserve(200_00, w.approve("reserve", 200_00, PIN))
            payee = payee_id_for_phone(shop_phone)
            pay = w.pay({"payee_id": payee, "phone": shop_phone}, 50_00, "qr", w.approve("pay", 50_00, PIN, payee))
            job = await w._device_client().sync_async([pay["record"]])
            done = await w._device_client().wait_sync_job(job["job_id"], every=0.05)
            await ac.aclose()
            return done["results"][0]["status"]

        statuses = await asyncio.gather(one(p1), one(p2))
        assert statuses == ["ACCEPTED", "ACCEPTED"]
        return shop
    asyncio.run(main())


def test_native_probe_reaches_server(server):
    rtts = native.probe("127.0.0.1", server["port"], 8, 2000)
    assert len(rtts) == 8 and all(r is not None and r >= 0 for r in rtts), rtts
    arts = asyncio.run(native.aprobe("127.0.0.1", server["port"], 4, 2000))
    assert all(r is not None for r in arts)


def cli(server, wdir, *args):
    env = dict(os.environ, PSTCO_PIN="123456")
    r = subprocess.run([server["wallet_cli"], args[0], "-dir", str(wdir), "-server", server["url"], "-ca", server["ca"],
                        *args[1:]], capture_output=True, text=True, env=env, timeout=60)
    assert r.returncode == 0, r.stderr + r.stdout
    return r.stdout


def test_interop_with_go_wallet(server, tmp_path, phone):
    """A Python payer pays a Go wallet and a Go payer pays a Python wallet,
    each verified offline by the other language."""
    go_phone, py_phone = phone(), phone()
    go_dir = tmp_path / "gowallet"
    cli(server, go_dir, "register", "-phone", go_phone, "-name", "Go Shop", "-listed")
    py = onboard(server, tmp_path, py_phone, "Py User")
    fund(py, 500_00, 300_00)
    q = py.quote_phone(go_phone)
    pay = py.pay(q, 42_00, "qr", py.approve("pay", 42_00, PIN, q["payee_id"]))
    out = cli(server, go_dir, "accept", "-code", pay["qr"])
    assert "received Rs 42.00 offline" in out and "verified" in out

    cli(server, go_dir, "deposit", "-amount", "300")
    cli(server, go_dir, "reserve", "-amount", "200")
    code = cli(server, go_dir, "pay", "-phone", py_phone, "-amount", "17.50").strip().splitlines()[-1]
    got = py.accept(code)
    assert got["amount_paise"] == 17_50
