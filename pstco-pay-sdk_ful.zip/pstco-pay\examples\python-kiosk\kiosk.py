"""Example: a shop kiosk integrating the PSTCO-Pay Python SDK with asyncio.

The kiosk registers as a listed shop, shows its payee card, accepts a
customer's payment code with no network, and syncs in the background.
A second wallet plays the customer so the example runs end to end.

    set PYTHONPATH=python
    python examples/python-kiosk/kiosk.py --server https://localhost:8444 --ca certs/ca.pem
"""

import argparse
import asyncio
import tempfile
from pathlib import Path

from pstco import AsyncClient, AsyncSoftwareWallet, format_rupees
from pstco.formats import payee_id_for_phone

PIN = "135790"  # typed by the user in a real kiosk


async def onboard(client, directory, phone, name, listed):
    w = AsyncSoftwareWallet.create(directory, PIN, client)
    otp = await w.start_account(phone, name, listed)
    if not otp:
        raise SystemExit("server is not in development mode: ask the user for the SMS code")
    await w.verify_account(phone, otp)
    w.set_name(name)
    reg = await w.register()
    print(f"{name}: device {reg['device_id']}, trust {reg['trust']}")
    return w


async def main(server, ca, shop_phone, customer_phone):
    client = AsyncClient(server, ca)
    work = Path(tempfile.mkdtemp(prefix="pstco-kiosk-"))
    kiosk, customer = await asyncio.gather(
        onboard(client, work / "kiosk", shop_phone, "Example Kiosk", True),
        onboard(client, work / "customer", customer_phone, "Example Customer", False))

    await customer.deposit(800_00, customer.approve("deposit", 800_00, PIN))
    await customer.create_reserve(400_00, customer.approve("reserve", 400_00, PIN))
    print("kiosk card:", kiosk.payee_card()[:48] + "...")

    # Customer pays offline; the kiosk verifies offline.
    payee = payee_id_for_phone(shop_phone)
    pay = customer.pay({"payee_id": payee, "phone": shop_phone}, 75_25, "qr",
                       customer.approve("pay", 75_25, PIN, payee))
    got = kiosk.accept(pay["qr"])
    print(f"kiosk verified Rs {format_rupees(got['amount_paise'])} offline")

    # Background sync with the async job API.
    rep = await kiosk.sync()
    print(f"kiosk synced: {rep['accepted']} accepted, {rep['bad_receipts']} bad receipts")
    await client.aclose()


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--server", default="https://localhost:8444")
    p.add_argument("--ca", default="certs/ca.pem")
    p.add_argument("--shop-phone", default="9876533333")
    p.add_argument("--customer-phone", default="9876544444")
    a = p.parse_args()
    asyncio.run(main(a.server, a.ca or None, a.shop_phone, a.customer_phone))
