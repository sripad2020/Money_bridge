/* pstconet: PSTCO-Pay native network operations. See pstconet.h. */
#include "pstconet.h"

#include <stdio.h>
#include <string.h>

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#include <mstcpip.h>
#include <windows.h>
typedef SOCKET pstco_sock;
#define PSTCO_INVALID INVALID_SOCKET
#define pstco_close closesocket
#else
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
typedef int pstco_sock;
#define PSTCO_INVALID (-1)
#define pstco_close close
#endif

const char *pstco_version(void) { return "pstconet 1.0"; }

/* ------------------------------------------------------------ clock */

static int64_t now_us(void) {
#ifdef _WIN32
    static LARGE_INTEGER freq;
    LARGE_INTEGER t;
    if (freq.QuadPart == 0) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t);
    return (int64_t)((t.QuadPart * 1000000LL) / freq.QuadPart);
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000000LL + ts.tv_nsec / 1000;
#endif
}

/* ------------------------------------------------------------ init */

int pstco_init(void) {
#ifdef _WIN32
    static volatile LONG done = 0;
    if (InterlockedCompareExchange(&done, 1, 0) == 0) {
        WSADATA wsa;
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
            done = 0;
            return PSTCO_ESYS;
        }
    }
#endif
    return PSTCO_OK;
}

/* ------------------------------------------------------------ tuning */

int pstco_tune_socket(intptr_t fd, const pstco_tuning *t) {
    if (t == NULL) return PSTCO_EINVAL;
    pstco_sock s = (pstco_sock)fd;
    if (t->nodelay) {
        int one = 1;
        if (setsockopt(s, IPPROTO_TCP, TCP_NODELAY, (const char *)&one, sizeof one) != 0) return PSTCO_ESYS;
    }
    if (t->keepalive_secs > 0) {
        int one = 1;
        if (setsockopt(s, SOL_SOCKET, SO_KEEPALIVE, (const char *)&one, sizeof one) != 0) return PSTCO_ESYS;
#ifdef _WIN32
        struct tcp_keepalive ka;
        DWORD ret = 0;
        ka.onoff = 1;
        ka.keepalivetime = (ULONG)t->keepalive_secs * 1000;
        ka.keepaliveinterval = 1000;
        if (WSAIoctl(s, SIO_KEEPALIVE_VALS, &ka, sizeof ka, NULL, 0, &ret, NULL, NULL) != 0) return PSTCO_ESYS;
#elif defined(TCP_KEEPIDLE)
        int idle = t->keepalive_secs;
        if (setsockopt(s, IPPROTO_TCP, TCP_KEEPIDLE, &idle, sizeof idle) != 0) return PSTCO_ESYS;
#endif
    }
    if (t->sndbuf > 0 && setsockopt(s, SOL_SOCKET, SO_SNDBUF, (const char *)&t->sndbuf, sizeof t->sndbuf) != 0)
        return PSTCO_ESYS;
    if (t->rcvbuf > 0 && setsockopt(s, SOL_SOCKET, SO_RCVBUF, (const char *)&t->rcvbuf, sizeof t->rcvbuf) != 0)
        return PSTCO_ESYS;
    if (t->congestion != NULL && t->congestion[0] != '\0') {
#if defined(__linux__) && defined(TCP_CONGESTION)
        if (setsockopt(s, IPPROTO_TCP, TCP_CONGESTION, t->congestion, (socklen_t)strlen(t->congestion)) != 0)
            return PSTCO_ESYS;
#else
        return PSTCO_EUNSUPPORTED; /* Windows and macOS choose congestion control system-wide */
#endif
    }
    return PSTCO_OK;
}

/* ------------------------------------------------------------ statistics */

#ifdef _WIN32
#ifndef SIO_TCP_INFO
#define SIO_TCP_INFO _WSAIORW(IOC_VENDOR, 39)
#endif
/* Layout of TCP_INFO_v0 (Windows 10 1703+), declared here because not
 * every SDK's headers carry it. */
typedef struct {
    int State;
    ULONG Mss;
    ULONG64 ConnectionTimeMs;
    BOOLEAN TimestampsEnabled;
    ULONG RttUs;
    ULONG MinRttUs;
    ULONG BytesInFlight;
    ULONG Cwnd;
    ULONG SndWnd;
    ULONG RcvWnd;
    ULONG RcvBuf;
    ULONG64 BytesOut;
    ULONG64 BytesIn;
    ULONG BytesReordered;
    ULONG BytesRetrans;
    ULONG FastRetrans;
    ULONG DupAcksIn;
    ULONG TimeoutEpisodes;
    UCHAR SynRetrans;
} pstco_win_tcp_info_v0;
#endif

int pstco_read_tcp_stats(intptr_t fd, pstco_tcp_stats *out) {
    if (out == NULL) return PSTCO_EINVAL;
    memset(out, 0, sizeof *out);
#if defined(_WIN32)
    DWORD version = 0, bytes = 0;
    pstco_win_tcp_info_v0 info;
    memset(&info, 0, sizeof info);
    if (WSAIoctl((SOCKET)fd, SIO_TCP_INFO, &version, sizeof version, &info, sizeof info, &bytes, NULL, NULL) != 0)
        return PSTCO_EUNSUPPORTED;
    out->rtt_us = info.RttUs;
    out->min_rtt_us = info.MinRttUs;
    out->snd_cwnd = info.Cwnd;
    out->mss = info.Mss;
    out->total_retrans = info.BytesRetrans;
    out->bytes_in_flight = info.BytesInFlight;
    return PSTCO_OK;
#elif defined(__linux__) && defined(TCP_INFO)
    struct tcp_info info;
    socklen_t len = sizeof info;
    memset(&info, 0, sizeof info);
    if (getsockopt((int)fd, IPPROTO_TCP, TCP_INFO, &info, &len) != 0) return PSTCO_ESYS;
    out->rtt_us = info.tcpi_rtt;
    out->rttvar_us = info.tcpi_rttvar;
    out->snd_cwnd = info.tcpi_snd_cwnd;
    out->mss = info.tcpi_snd_mss;
    out->total_retrans = info.tcpi_total_retrans;
    out->bytes_in_flight = info.tcpi_unacked;
    return PSTCO_OK;
#else
    (void)fd;
    return PSTCO_EUNSUPPORTED;
#endif
}

/* ------------------------------------------------------------ async probe */

static int set_nonblocking(pstco_sock s) {
#ifdef _WIN32
    u_long on = 1;
    return ioctlsocket(s, FIONBIO, &on) == 0 ? 0 : -1;
#else
    int fl = fcntl(s, F_GETFL, 0);
    return (fl >= 0 && fcntl(s, F_SETFL, fl | O_NONBLOCK) == 0) ? 0 : -1;
#endif
}

static int connect_in_progress(void) {
#ifdef _WIN32
    return WSAGetLastError() == WSAEWOULDBLOCK;
#else
    return errno == EINPROGRESS;
#endif
}

int pstco_probe_many(const char *host, int port, int count, int timeout_ms, int64_t *rtt_us, int *err) {
    if (host == NULL || port <= 0 || port > 65535 || count <= 0 || count > PSTCO_MAX_PROBES ||
        timeout_ms <= 0 || rtt_us == NULL || err == NULL)
        return PSTCO_EINVAL;
    if (pstco_init() != PSTCO_OK) return PSTCO_ESYS;

    char portstr[8];
    snprintf(portstr, sizeof portstr, "%d", port);
    struct addrinfo hints, *ai = NULL;
    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host, portstr, &hints, &ai) != 0 || ai == NULL) return PSTCO_ERESOLVE;

    pstco_sock socks[PSTCO_MAX_PROBES];
    int64_t started[PSTCO_MAX_PROBES];
    int pending = 0, ok = 0;
    for (int i = 0; i < count; i++) {
        rtt_us[i] = 0;
        err[i] = PSTCO_ECONNECT;
        socks[i] = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (socks[i] == PSTCO_INVALID) continue;
        if (set_nonblocking(socks[i]) != 0) {
            pstco_close(socks[i]);
            socks[i] = PSTCO_INVALID;
            continue;
        }
        started[i] = now_us();
        int rc = connect(socks[i], ai->ai_addr, (int)ai->ai_addrlen);
        if (rc == 0) { /* immediate (loopback) */
            rtt_us[i] = now_us() - started[i];
            err[i] = PSTCO_OK;
            ok++;
            pstco_close(socks[i]);
            socks[i] = PSTCO_INVALID;
        } else if (connect_in_progress()) {
            err[i] = PSTCO_ETIMEOUT; /* until it completes */
            pending++;
        } else {
            pstco_close(socks[i]);
            socks[i] = PSTCO_INVALID;
        }
    }
    freeaddrinfo(ai);

    int64_t deadline = now_us() + (int64_t)timeout_ms * 1000;
    while (pending > 0) {
        int64_t left = deadline - now_us();
        if (left <= 0) break;
        fd_set wfds, efds;
        FD_ZERO(&wfds);
        FD_ZERO(&efds);
        int maxfd = 0;
        for (int i = 0; i < count; i++) {
            if (socks[i] == PSTCO_INVALID) continue;
            FD_SET(socks[i], &wfds);
            FD_SET(socks[i], &efds);
            if ((int)socks[i] > maxfd) maxfd = (int)socks[i];
        }
        struct timeval tv;
        tv.tv_sec = (long)(left / 1000000);
        tv.tv_usec = (long)(left % 1000000);
        int n = select(maxfd + 1, NULL, &wfds, &efds, &tv);
        if (n < 0) break;
        if (n == 0) continue;
        int64_t t = now_us();
        for (int i = 0; i < count; i++) {
            if (socks[i] == PSTCO_INVALID) continue;
            if (!FD_ISSET(socks[i], &wfds) && !FD_ISSET(socks[i], &efds)) continue;
            int soerr = 0;
            socklen_t len = sizeof soerr;
            getsockopt(socks[i], SOL_SOCKET, SO_ERROR, (char *)&soerr, &len);
            if (soerr == 0 && FD_ISSET(socks[i], &wfds)) {
                rtt_us[i] = t - started[i];
                err[i] = PSTCO_OK;
                ok++;
            } else {
                err[i] = PSTCO_ECONNECT;
            }
            pstco_close(socks[i]);
            socks[i] = PSTCO_INVALID;
            pending--;
        }
    }
    for (int i = 0; i < count; i++) {
        if (socks[i] != PSTCO_INVALID) {
            pstco_close(socks[i]); /* still pending at the deadline: timed out */
            err[i] = PSTCO_ETIMEOUT;
        }
    }
    return ok;
}
