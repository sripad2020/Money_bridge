// Package transport is the PSTCO-Pay transport layer: TLS 1.3 mutual TLS with
// certificate hot reload, a development PKI generator, and a TCP listener and
// dialer that select the congestion-control algorithm (BBR or CUBIC) and
// sample kernel TCP telemetry where the OS exposes it.
package transport

import (
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"os"
	"sync"
	"time"
)

// CertReloader serves a certificate from disk and reloads it when the files
// change, so certificates can be rotated without restarting.
type CertReloader struct {
	certFile, keyFile string

	mu        sync.Mutex
	cert      *tls.Certificate
	modTime   time.Time
	lastCheck time.Time
}

// NewCertReloader loads the certificate once and returns a reloader.
func NewCertReloader(certFile, keyFile string) (*CertReloader, error) {
	r := &CertReloader{certFile: certFile, keyFile: keyFile}
	if _, err := r.get(); err != nil {
		return nil, err
	}
	return r, nil
}

func (r *CertReloader) get() (*tls.Certificate, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.cert != nil && time.Since(r.lastCheck) < 5*time.Second {
		return r.cert, nil
	}
	r.lastCheck = time.Now()
	st, err := os.Stat(r.certFile)
	if err != nil {
		if r.cert != nil {
			return r.cert, nil
		}
		return nil, err
	}
	if r.cert != nil && !st.ModTime().After(r.modTime) {
		return r.cert, nil
	}
	c, err := tls.LoadX509KeyPair(r.certFile, r.keyFile)
	if err != nil {
		if r.cert != nil {
			return r.cert, nil // keep serving the old cert during a half-written rotation
		}
		return nil, err
	}
	r.cert, r.modTime = &c, st.ModTime()
	return r.cert, nil
}

// GetCertificate implements tls.Config.GetCertificate.
func (r *CertReloader) GetCertificate(*tls.ClientHelloInfo) (*tls.Certificate, error) { return r.get() }

// GetClientCertificate implements tls.Config.GetClientCertificate.
func (r *CertReloader) GetClientCertificate(*tls.CertificateRequestInfo) (*tls.Certificate, error) {
	return r.get()
}

func loadPool(caFile string) (*x509.CertPool, error) {
	b, err := os.ReadFile(caFile)
	if err != nil {
		return nil, err
	}
	pool := x509.NewCertPool()
	if !pool.AppendCertsFromPEM(b) {
		return nil, fmt.Errorf("transport: no certificates in %s", caFile)
	}
	return pool, nil
}

// ServerTLSConfig returns a TLS 1.3-only, client-certificate-required config.
// Go's crypto/tls does not implement TLS 1.3 0-RTT early data, so replayable
// early requests are impossible by construction.
func ServerTLSConfig(certFile, keyFile, caFile string) (*tls.Config, error) {
	r, err := NewCertReloader(certFile, keyFile)
	if err != nil {
		return nil, err
	}
	pool, err := loadPool(caFile)
	if err != nil {
		return nil, err
	}
	return &tls.Config{
		MinVersion:     tls.VersionTLS13,
		MaxVersion:     tls.VersionTLS13,
		ClientAuth:     tls.RequireAndVerifyClientCert,
		ClientCAs:      pool,
		GetCertificate: r.GetCertificate,
		NextProtos:     []string{"h2"},
	}, nil
}

// ClientTLSConfig returns a TLS 1.3-only client config presenting a client certificate.
func ClientTLSConfig(certFile, keyFile, caFile, serverName string) (*tls.Config, error) {
	r, err := NewCertReloader(certFile, keyFile)
	if err != nil {
		return nil, err
	}
	pool, err := loadPool(caFile)
	if err != nil {
		return nil, err
	}
	return &tls.Config{
		MinVersion:           tls.VersionTLS13,
		MaxVersion:           tls.VersionTLS13,
		RootCAs:              pool,
		ServerName:           serverName,
		GetClientCertificate: r.GetClientCertificate,
		NextProtos:           []string{"h2"},
	}, nil
}

// ErrUnsupported is returned where the OS lacks a transport feature.
var ErrUnsupported = errors.New("transport: not supported on this OS")
