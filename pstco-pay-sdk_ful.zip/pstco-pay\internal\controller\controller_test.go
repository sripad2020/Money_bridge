package controller

import (
	"errors"
	"testing"
	"time"
)

func TestAdmissionControlAndBackpressure(t *testing.T) {
	cfg := DefaultConfig()
	cfg.MaxInflight = 2
	c := New(cfg)
	r1, err := c.Admit(time.Time{})
	if err != nil {
		t.Fatal(err)
	}
	r2, _ := c.Admit(time.Time{})
	if _, err := c.Admit(time.Time{}); !errors.Is(err, ErrOverloaded) {
		t.Fatalf("third admission: %v", err)
	}
	r1()
	r1() // release is idempotent
	if c.Inflight() != 1 {
		t.Fatalf("inflight %d", c.Inflight())
	}
	r2()
	if _, err := c.Admit(time.Now().Add(time.Millisecond)); !errors.Is(err, ErrDeadlineTooShort) {
		t.Fatalf("short deadline: %v", err)
	}
}

func TestBackoffGrowsWithCongestionAndStaysBounded(t *testing.T) {
	cfg := DefaultConfig()
	c := New(cfg)
	calm := c.Backoff("capture", 3)
	c.UpdateTransport(TransportSample{RTT: 10 * time.Millisecond})
	c.UpdateTransport(TransportSample{RTT: 40 * time.Millisecond, Retransmits: 20})
	if f := c.CongestionFactor(); f <= 1 {
		t.Fatalf("congestion factor %f under RTT inflation", f)
	}
	if c.Backoff("capture", 3) <= calm/2 {
		t.Fatal("backoff did not grow under congestion")
	}
	if b := c.Backoff("capture", 30); b > cfg.MaxBackoff {
		t.Fatalf("backoff %s above max", b)
	}
	if c.StageTimeout("capture", time.Now().Add(5*time.Millisecond)) > 5*time.Millisecond {
		t.Fatal("stage timeout exceeds remaining deadline")
	}
}

func TestLatencyEstimate(t *testing.T) {
	c := New(DefaultConfig())
	for range 50 {
		c.Observe("authorize", 4*time.Millisecond, false)
	}
	if e := c.Expected("authorize"); e < 3*time.Millisecond || e > 6*time.Millisecond {
		t.Fatalf("expected %s", e)
	}
}
