// Command certgen writes a development PKI: a CA, a server certificate and
// client certificates for mutual TLS. Use real certificates in production.
package main

import (
	"flag"
	"fmt"
	"os"
	"strings"

	"pstcopay/internal/transport"
)

func main() {
	out := flag.String("out", "certs", "output directory")
	hosts := flag.String("hosts", "localhost,127.0.0.1,pstco-server", "server certificate hosts (first is the CN)")
	clients := flag.String("clients", "merchant-demo,pstco-admin,envoy-gateway", "client certificate common names")
	flag.Parse()
	if err := transport.GenerateDevPKI(*out, split(*hosts), split(*clients)); err != nil {
		fmt.Fprintln(os.Stderr, "certgen:", err)
		os.Exit(1)
	}
	fmt.Printf("wrote dev PKI to %s (server: %s; clients: %s)\n", *out, *hosts, *clients)
}

func split(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		if p = strings.TrimSpace(p); p != "" {
			out = append(out, p)
		}
	}
	return out
}
