// Command pstco-wallet is a developer wallet for the PSTCO-Pay offline API:
// it registers a device, funds it, pays and accepts offline payments, and
// syncs, using the same SDK a mobile app embeds.
//
//	pstco-wallet register -phone 9876500001 -name Asha            (dev server: OTP read automatically)
//	pstco-wallet deposit  -amount 1000
//	pstco-wallet reserve  -amount 500
//	pstco-wallet pay      -phone 9876500002 -amount 123.45        (prints a payment code)
//	pstco-wallet accept   -code PSTCO1:...                        (payee, no network needed)
//	pstco-wallet sync
//	pstco-wallet balance
//	pstco-wallet card                                             (this account's payee code)
//
// Common flags: -dir wallet directory, -server offline API URL, -ca server CA
// file, and the PIN in PSTCO_PIN (default 123456 for development).
package main

import (
	"context"
	"encoding/json"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"pstcopay/sdk/client"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/wallet"
)

func main() {
	if len(os.Args) < 2 {
		usage()
	}
	cmd := os.Args[1]
	fs := flag.NewFlagSet(cmd, flag.ExitOnError)
	dir := fs.String("dir", "wallet", "wallet directory")
	server := fs.String("server", "https://localhost:8444", "offline API base URL")
	ca := fs.String("ca", "certs/ca.pem", "server CA certificate (empty for system roots)")
	phone := fs.String("phone", "", "phone number")
	name := fs.String("name", "", "display name")
	listed := fs.Bool("listed", false, "list this account in the payee directory (shops)")
	otp := fs.String("otp", "", "OTP (omit on a development server)")
	amount := fs.String("amount", "", "amount in rupees, e.g. 123.45")
	code := fs.String("code", "", "payment code to accept")
	sms := fs.Bool("sms", false, "deliver the payment by SMS instead of a code")
	_ = fs.Parse(os.Args[2:])

	pin := os.Getenv("PSTCO_PIN")
	if pin == "" {
		pin = "123456"
	}
	var hc = client.NewHTTPClient(nil)
	if *ca != "" {
		pem, err := os.ReadFile(*ca)
		check(err)
		hc = client.NewHTTPClient(pem)
	}
	check(os.MkdirAll(*dir, 0o700))
	var el wallet.Element
	var err error
	if _, statErr := os.Stat(filepath.Join(*dir, "element.sealed")); statErr == nil {
		el, err = wallet.OpenSealedElement(*dir, nil, wallet.ElementOptions{})
	} else {
		el, err = wallet.CreateSealedElement(*dir, pin, nil, wallet.ElementOptions{})
	}
	check(err)
	w, err := wallet.New(wallet.Config{Dir: *dir, Element: el, Client: client.New(*server, hc),
		Model: "pstco-wallet-cli", AppVersion: "dev"})
	check(err)
	check(w.Unlock(pin))
	defer w.Lock()
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	rupees := func() int64 {
		p, err := offline.ParseINR(*amount)
		check(err)
		return p
	}

	switch cmd {
	case "register":
		devOTP, err := w.StartAccount(ctx, *phone, *name, *listed)
		check(err)
		code := *otp
		if code == "" {
			code = devOTP
		}
		if code == "" {
			fail("the server sent an OTP by SMS; run again with -otp")
		}
		check(w.VerifyAccount(ctx, *phone, code))
		check(w.SetDisplayName(*name))
		show(w.Register(ctx))
	case "deposit":
		amt := rupees()
		a, err := w.Approve(wallet.Intent{Op: wallet.OpDeposit, AmountPaise: amt}, pin)
		check(err)
		show(w.Deposit(ctx, amt, a))
	case "reserve":
		amt := rupees()
		a, err := w.Approve(wallet.Intent{Op: wallet.OpReserve, AmountPaise: amt}, pin)
		check(err)
		show(w.CreateReserve(ctx, amt, a))
	case "pay":
		q, err := w.QuotePhone(*phone)
		check(err)
		if q.Listed {
			fmt.Printf("paying %s (%s)\n", q.Name, q.Phone)
		} else {
			fmt.Printf("warning: %s is not a listed shop; check the number\n", q.Phone)
		}
		delivery := wallet.DeliverQR
		if *sms {
			delivery = wallet.DeliverSMS
		}
		amt := rupees()
		a, err := w.Approve(wallet.Intent{Op: wallet.OpPay, AmountPaise: amt, PayeeID: q.PayeeID}, pin)
		check(err)
		p, err := w.Pay(q, amt, delivery, a)
		check(err)
		fmt.Printf("paid Rs %s offline, counter %d\n", offline.FormatRupees(p.AmountPaise), p.Counter)
		if p.SMS != nil {
			fmt.Printf("queued SMS %s to %s (%d bytes)\n", p.SMS.ID, p.SMS.To, len(p.SMS.Payload))
		}
		fmt.Println(p.QR)
	case "accept":
		r, err := w.Accept(*code)
		check(err)
		fmt.Printf("received Rs %s offline from device %s (payment %d), verified\n",
			offline.FormatRupees(r.AmountPaise), offline.FormatID(r.DeviceID), r.Counter)
	case "sync":
		show(w.Sync(ctx))
	case "balance":
		show(w.Balance())
		if ow, err := w.OnlineWallet(ctx); err == nil {
			show(ow, nil)
		}
	case "card":
		qr, err := w.PayeeQR()
		check(err)
		fmt.Println(qr)
	case "sms":
		show(w.PendingSMS(), nil)
	default:
		usage()
	}
}

func show(v any, err error) {
	check(err)
	b, _ := json.MarshalIndent(v, "", "  ")
	fmt.Println(string(b))
}

func check(err error) {
	if err != nil {
		fail(err.Error())
	}
}

func fail(msg string) {
	fmt.Fprintln(os.Stderr, "error:", msg)
	os.Exit(1)
}

func usage() {
	fmt.Fprintln(os.Stderr, "usage: pstco-wallet <register|deposit|reserve|pay|accept|sync|balance|card|sms> [flags]")
	os.Exit(2)
}
