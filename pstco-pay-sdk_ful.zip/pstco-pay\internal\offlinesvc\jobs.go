package offlinesvc

import (
	"context"
	"sync"
	"time"

	"pstcopay/internal/store"
	"pstcopay/sdk/offline/api"
)

// Asynchronous sync: a device posts records with ?async=1 and gets a job id
// at once (HTTP 202); a worker pool verifies the records in the background
// and the device polls the job. Records are durable once accepted, so a job
// lost in a restart is simply re-uploaded and answered DUPLICATE.

type syncJob struct {
	id      string
	device  uint64
	records [][]byte
	rasp    []api.RASPFinding
	status  string
	results []api.SyncResult
	created time.Time
}

type jobQueue struct {
	once  sync.Once
	mu    sync.Mutex
	jobs  map[string]*syncJob
	queue chan *syncJob
}

const (
	jobWorkers  = 4
	jobCapacity = 1024
	jobTTL      = 15 * time.Minute
)

func (s *Service) startJobs(ctx context.Context) {
	s.jobs.once.Do(func() {
		s.jobs.jobs = map[string]*syncJob{}
		s.jobs.queue = make(chan *syncJob, jobCapacity)
		for range jobWorkers {
			go func() {
				for {
					select {
					case <-ctx.Done():
						return
					case j := <-s.jobs.queue:
						s.jobs.mu.Lock()
						j.status = "RUNNING"
						s.jobs.mu.Unlock()
						res := s.Sync(ctx, &store.Device{ID: j.device}, j.records, "internet", nil)
						s.jobs.mu.Lock()
						j.status, j.results, j.records = "DONE", res, nil
						s.jobs.mu.Unlock()
					}
				}
			}()
		}
		go func() {
			t := time.NewTicker(time.Minute)
			defer t.Stop()
			for {
				select {
				case <-ctx.Done():
					return
				case <-t.C:
					s.jobs.mu.Lock()
					for id, j := range s.jobs.jobs {
						if s.now().Sub(j.created) > jobTTL {
							delete(s.jobs.jobs, id)
						}
					}
					s.jobs.mu.Unlock()
				}
			}
		}()
	})
}

// SubmitSync queues records for background verification.
func (s *Service) SubmitSync(ctx context.Context, d *store.Device, req api.SyncRequest) (*api.SyncJob, error) {
	s.startJobs(context.WithoutCancel(ctx))
	if len(req.RASP) > 0 {
		s.Sync(ctx, d, nil, "internet", req.RASP) // records the RASP report only
	}
	j := &syncJob{id: "job_" + randomHex(16), device: d.ID, records: req.Records, status: "QUEUED", created: s.now()}
	s.jobs.mu.Lock()
	s.jobs.jobs[j.id] = j
	s.jobs.mu.Unlock()
	select {
	case s.jobs.queue <- j:
	default:
		s.jobs.mu.Lock()
		delete(s.jobs.jobs, j.id)
		s.jobs.mu.Unlock()
		return nil, apiErr(503, "busy", "sync queue is full; retry shortly")
	}
	return &api.SyncJob{JobID: j.id, Status: "QUEUED", Submitted: len(req.Records)}, nil
}

// SyncJobStatus returns a job; only the device that submitted it may read it.
func (s *Service) SyncJobStatus(d *store.Device, id string) (*api.SyncJob, error) {
	s.startJobs(context.Background())
	s.jobs.mu.Lock()
	defer s.jobs.mu.Unlock()
	j, ok := s.jobs.jobs[id]
	if !ok || j.device != d.ID {
		return nil, apiErr(404, "not_found", "no such sync job")
	}
	out := &api.SyncJob{JobID: j.id, Status: j.status, Submitted: len(j.results)}
	if j.status == "DONE" {
		out.Results = append([]api.SyncResult(nil), j.results...)
	} else {
		out.Submitted = len(j.records)
	}
	return out, nil
}
