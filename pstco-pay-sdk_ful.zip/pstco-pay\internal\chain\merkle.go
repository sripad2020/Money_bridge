package chain

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"strconv"
)

// MerkleRoot computes a binary Merkle root over hex event hashes. Leaves and
// inner nodes use distinct prefixes to prevent second-preimage tricks; an odd
// node is promoted unchanged.
func MerkleRoot(hashes []string) string {
	if len(hashes) == 0 {
		return GenesisHash
	}
	level := make([][]byte, len(hashes))
	for i, h := range hashes {
		b, _ := hex.DecodeString(h)
		sum := sha256.Sum256(append([]byte{0x00}, b...))
		level[i] = sum[:]
	}
	for len(level) > 1 {
		var next [][]byte
		for i := 0; i < len(level); i += 2 {
			if i+1 == len(level) {
				next = append(next, level[i])
				continue
			}
			buf := append([]byte{0x01}, level[i]...)
			buf = append(buf, level[i+1]...)
			sum := sha256.Sum256(buf)
			next = append(next, sum[:])
		}
		level = next
	}
	return hex.EncodeToString(level[0])
}

// Anchor is a signed Merkle root over a contiguous range of event rows. It is
// written to a file outside the database so that rewriting the database alone
// cannot hide tampering.
type Anchor struct {
	FromRowID int64  `json:"from_row_id"` // exclusive
	ToRowID   int64  `json:"to_row_id"`   // inclusive
	Count     int    `json:"count"`
	Root      string `json:"root"`
	CreatedAt int64  `json:"created_at"`
	Signer    string `json:"signer"`
	Signature string `json:"signature"`
	// Log names the anchored event table: "online" (or empty, for anchors
	// written before offline anchoring) or "offline".
	Log string `json:"log,omitempty"`
}

func (a *Anchor) message() []byte {
	if a.Log != "" {
		return []byte("pstco-anchor/2\x00" + a.Log + ":" + strconv.FormatInt(a.FromRowID, 10) + ":" +
			strconv.FormatInt(a.ToRowID, 10) + ":" + strconv.Itoa(a.Count) + ":" + a.Root + ":" +
			strconv.FormatInt(a.CreatedAt, 10))
	}
	return []byte("pstco-anchor/1\x00" + strconv.FormatInt(a.FromRowID, 10) + ":" +
		strconv.FormatInt(a.ToRowID, 10) + ":" + strconv.Itoa(a.Count) + ":" + a.Root + ":" +
		strconv.FormatInt(a.CreatedAt, 10))
}

// SignAnchor signs the anchor in place.
func SignAnchor(a *Anchor, s Signer) {
	a.Signer = s.ID()
	a.Signature = hex.EncodeToString(s.Sign(a.message()))
}

// VerifyAnchorSignature checks the anchor's own signature.
func VerifyAnchorSignature(a *Anchor, v Verifier) bool {
	sig, err := hex.DecodeString(a.Signature)
	return err == nil && a.Signer == SignerAnchor && v.Verify(a.Signer, a.message(), sig)
}

// AppendAnchor appends one JSON line to an append-only anchor log.
func AppendAnchor(path string, a *Anchor) error {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		return err
	}
	defer f.Close()
	b, _ := json.Marshal(a)
	if _, err := f.Write(append(b, '\n')); err != nil {
		return err
	}
	return f.Sync()
}

// ReadAnchors reads every anchor from the log.
func ReadAnchors(path string) ([]*Anchor, error) {
	f, err := os.Open(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var out []*Anchor
	sc := bufio.NewScanner(f)
	line := 0
	for sc.Scan() {
		line++
		var a Anchor
		if err := json.Unmarshal(sc.Bytes(), &a); err != nil {
			return nil, fmt.Errorf("anchor log line %d: %w", line, err)
		}
		out = append(out, &a)
	}
	return out, sc.Err()
}
