package offlinesvc

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"strconv"
	"sync"
	"sync/atomic"
	"time"

	"pstcopay/internal/bank"
	"pstcopay/internal/chain"
	"pstcopay/internal/model"
	"pstcopay/internal/store"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/offline/api"
)

// Conflict kinds that freeze a device.
const (
	ConflictDoubleSpend = "double_spend" // two different records with one counter
	ConflictFork        = "chain_fork"   // a record that does not link to its neighbour
	ConflictOverspend   = "overspend"    // more spent than the reserve holds
	ConflictOverLimit   = "over_limit"   // above the per-payment limit
)

func paymentKey(device uint64, counter uint32) string {
	return "off_" + offline.NonceFor(device, counter)
}

// Sync verifies and accepts uploaded records. The uploader may be the payer,
// the payee or (channel "sms") an SMS gateway; records authenticate themselves.
func (s *Service) Sync(ctx context.Context, uploader *store.Device, records [][]byte, channel string, rasp []api.RASPFinding) []api.SyncResult {
	if uploader != nil && len(rasp) > 0 {
		var rep string
		for _, f := range rasp {
			rep += f.Severity + ":" + f.Check + " "
		}
		_ = s.st.SetDeviceRASP(ctx, uploader.ID, rep, s.now())
	}
	// Records of different devices are independent, so they are verified
	// concurrently; records of one device run in order under its lock.
	out := make([]api.SyncResult, len(records))
	groups := map[uint64][]int{}
	var order []uint64
	for i, raw := range records {
		var dev uint64
		if len(raw) >= 9 {
			for _, b := range raw[1:9] {
				dev = dev<<8 | uint64(b)
			}
		}
		if _, ok := groups[dev]; !ok {
			order = append(order, dev)
		}
		groups[dev] = append(groups[dev], i)
	}
	sem := make(chan struct{}, 8)
	var wg sync.WaitGroup
	for _, dev := range order {
		idx := groups[dev]
		wg.Add(1)
		sem <- struct{}{}
		go func() {
			defer wg.Done()
			defer func() { <-sem }()
			for _, i := range idx {
				out[i] = s.processRecord(ctx, records[i], channel)
			}
		}()
	}
	wg.Wait()
	return out
}

func reject(r *offline.Record, reason string) api.SyncResult {
	res := api.SyncResult{Status: api.StatusRejected, Reason: reason}
	if r != nil {
		res.DeviceID, res.Counter = offline.FormatID(r.DeviceID), r.Counter
	}
	return res
}

func (s *Service) conflict(ctx context.Context, r *offline.Record, raw []byte, kind, detail string) api.SyncResult {
	now := s.now()
	_ = s.st.InsertConflict(ctx, r.DeviceID, r.Counter, raw, kind, detail, now)
	_ = s.st.SetDeviceStatus(ctx, r.DeviceID, store.DeviceFrozen, kind+": "+detail, now)
	s.securityEvent(ctx, EventDeviceFrozen, "device:"+offline.FormatID(r.DeviceID), kind+": "+detail)
	s.log.Warn("offline conflict, device frozen", "device", offline.FormatID(r.DeviceID), "counter", r.Counter, "kind", kind)
	return reject(r, kind)
}

// processRecord verifies one record and, when the server holds it, attaches
// a signed receipt binding the result to the exact record bytes.
func (s *Service) processRecord(ctx context.Context, raw []byte, channel string) api.SyncResult {
	res := s.processRecordInner(ctx, raw, channel)
	var code byte
	switch res.Status {
	case api.StatusAccepted:
		code = offline.ReceiptAccepted
	case api.StatusDuplicate:
		code = offline.ReceiptDuplicate
	default:
		return res
	}
	if rc, err := offline.SignReceipt(raw, code, uint32(s.now().Unix()), s.keys.Signer(chain.SignerOffline).Sign); err == nil {
		res.Receipt = rc
	}
	return res
}

// ReceiptPublicKey is the key receipts are signed with.
func (s *Service) ReceiptPublicKey() []byte { return s.keys.PublicKey(chain.SignerOffline) }

func (s *Service) processRecordInner(ctx context.Context, raw []byte, channel string) api.SyncResult {
	r, err := offline.ParseRecord(raw)
	if err != nil {
		return reject(nil, "malformed: "+err.Error())
	}
	dev, err := s.st.GetDevice(ctx, r.DeviceID)
	if err != nil {
		return reject(r, "unknown_device")
	}
	if err := offline.VerifyRecordSignature(raw, offline.Alg(dev.Alg), dev.PublicKey); err != nil {
		return reject(r, "bad_signature")
	}
	unlock, err := s.lockDevice(ctx, r.DeviceID)
	if err != nil {
		return reject(r, "busy")
	}
	defer unlock()

	if have, err := s.st.GetRecord(ctx, r.DeviceID, r.Counter); err == nil {
		if bytes.Equal(have.Raw, raw) {
			return api.SyncResult{DeviceID: offline.FormatID(r.DeviceID), Counter: r.Counter, Status: api.StatusDuplicate,
				Reason: "already " + lower(have.Status)}
		}
		return s.conflict(ctx, r, raw, ConflictDoubleSpend, "a different record already used this counter")
	}
	rsv, err := s.st.ReserveForCounter(ctx, r.DeviceID, r.Counter)
	if err != nil {
		return reject(r, "no_reserve")
	}
	now := s.now()
	if uint32(now.Add(-s.cfg.Policy.SettlementGrace).Unix()) > rsv.Expiry {
		return reject(r, "expired")
	}
	if r.Expiry != rsv.Expiry {
		return reject(r, "expiry_mismatch")
	}
	if r.AmountPaise > rsv.PerPaymentLimit {
		return s.conflict(ctx, r, raw, ConflictOverLimit, fmt.Sprintf("%d paise above limit %d", r.AmountPaise, rsv.PerPaymentLimit))
	}
	payer, err := s.st.GetAccount(ctx, dev.AccountID)
	if err != nil {
		return reject(r, "unknown_account")
	}
	if r.PayeeID == payer.PayeeID {
		return reject(r, "self_payment")
	}
	// Chain links with whatever neighbours we already hold.
	h := offline.RecordHash(raw)
	if r.Counter == rsv.CounterStart {
		if !bytes.Equal(r.PrevHash[:], rsv.Genesis) {
			return s.conflict(ctx, r, raw, ConflictFork, "first record does not link to its reserve")
		}
	} else if prev, err := s.st.GetRecord(ctx, r.DeviceID, r.Counter-1); err == nil && !bytes.Equal(prev.RecordHash, r.PrevHash[:]) {
		return s.conflict(ctx, r, raw, ConflictFork, "does not link to the previous record")
	}
	if next, err := s.st.GetRecord(ctx, r.DeviceID, r.Counter+1); err == nil && next.ReserveID == rsv.ID && !bytes.Equal(next.PrevHash, h[:]) {
		return s.conflict(ctx, r, raw, ConflictFork, "the next record does not link to this one")
	}

	status := store.SettlePending
	if _, err := s.st.GetAccountByPayee(ctx, r.PayeeID); errors.Is(err, store.ErrNotFound) {
		status = store.SettleWaitPayee
	}
	key := paymentKey(r.DeviceID, r.Counter)
	overspent := false
	err = s.st.WithTx(ctx, func(tx *store.Tx) error {
		ok, err := tx.AddReserveSpent(ctx, rsv.ID, r.AmountPaise)
		if err != nil {
			return err
		}
		if !ok {
			overspent = true
			return errOverspent
		}
		if err := tx.InsertRecord(ctx, &store.OfflineRecord{DeviceID: r.DeviceID, Counter: r.Counter, Raw: raw,
			RecordHash: h[:], PrevHash: r.PrevHash[:], ReserveID: rsv.ID, PayerAccount: payer.ID, PayeeID: r.PayeeID,
			Amount: r.AmountPaise, Status: store.RecordAccepted, Channel: channel, ReceivedAt: now}); err != nil {
			return err
		}
		recv, err := s.event(ctx, tx, key, model.StageOfflineReceive, nil, map[string]string{
			"channel": channel, "record_sha256": shaBytes(raw), "amount_paise": strconv.FormatInt(r.AmountPaise, 10),
			"payee_id": offline.FormatID(r.PayeeID)})
		if err != nil {
			return err
		}
		if _, err := s.event(ctx, tx, key, model.StageOfflineVerify, []string{recv.CurrentHash}, map[string]string{
			"device_trust": offline.Trust(dev.Trust).String(), "reserve_id": offline.FormatID(rsv.ID),
			"checks": "signature,counter,chain,expiry,limit,reserve"}); err != nil {
			return err
		}
		return tx.InsertOfflineSettlement(ctx, &store.OfflineSettlement{DeviceID: r.DeviceID, Counter: r.Counter,
			HoldID: rsv.HoldID, PayeeID: r.PayeeID, Amount: r.AmountPaise, Status: status, NextAttemptAt: now}, now)
	})
	if overspent {
		return s.conflict(ctx, r, raw, ConflictOverspend, "reserve exhausted")
	}
	if err != nil {
		if errors.Is(err, store.ErrDuplicate) {
			return api.SyncResult{DeviceID: offline.FormatID(r.DeviceID), Counter: r.Counter, Status: api.StatusDuplicate}
		}
		s.log.Error("accept record", "err", err)
		return reject(r, "internal_error")
	}
	return api.SyncResult{DeviceID: offline.FormatID(r.DeviceID), Counter: r.Counter, Status: api.StatusAccepted}
}

var errOverspent = errors.New("overspent")

func (s *Service) event(ctx context.Context, tx *store.Tx, key string, stage model.Stage, deps []string, payload map[string]string) (*chain.Event, error) {
	return tx.AppendOfflineEvent(ctx, key, func(prev string, seq int64) (*chain.Event, error) {
		ev := &chain.Event{EventID: "oev_" + randomHex(12), PaymentID: key, Seq: seq, Stage: stage, Attempt: 1,
			Status: model.EventSuccess, PreviousEventHash: prev, DependencyHashes: deps, Payload: payload,
			IdempotencyKey: key, WorkflowVersion: chain.WorkflowVersion, CreatedAt: s.now().UnixNano()}
		return ev, ev.Seal(s.keys.Signer(chain.SignerOffline))
	})
}

// ------------------------------------------------------------ settlement

// SettleDue transfers money for accepted records from the payer's reserve
// hold to the payee. Lost bank responses are resolved by querying the key.
func (s *Service) SettleDue(ctx context.Context) int {
	due, err := s.st.DueOfflineSettlements(ctx, s.now(), 100)
	if err != nil {
		s.log.Warn("offline settlement scan", "err", err)
		return 0
	}
	// Bank transfers run concurrently on a bounded worker pool.
	var n atomic.Int64
	sem := make(chan struct{}, 8)
	var wg sync.WaitGroup
	for _, st := range due {
		wg.Add(1)
		sem <- struct{}{}
		go func() {
			defer wg.Done()
			defer func() { <-sem }()
			if s.settleOne(ctx, st) {
				n.Add(1)
			}
		}()
	}
	wg.Wait()
	return int(n.Load())
}

func (s *Service) settleOne(ctx context.Context, st *store.OfflineSettlement) bool {
	now := s.now()
	payee, err := s.st.GetAccountByPayee(ctx, st.PayeeID)
	if err != nil {
		st.Status = store.SettleWaitPayee
		_ = s.st.UpdateOfflineSettlement(ctx, st, now)
		return false
	}
	key := paymentKey(st.DeviceID, st.Counter)
	res, err := s.bankDo(ctx, key, func(c context.Context) (*bank.Result, error) {
		return s.bank.TransferFromHold(c, key, st.HoldID, payee.ID, st.Amount)
	})
	if err != nil {
		st.Attempts++
		st.LastError = err.Error()
		if errors.Is(err, bank.ErrInsufficient) || st.Attempts >= s.cfg.MaxSettleAttempts {
			st.Status = store.SettleNeedsReview
		} else {
			st.NextAttemptAt = now.Add(time.Duration(1<<min(st.Attempts, 8)) * 100 * time.Millisecond)
		}
		_ = s.st.UpdateOfflineSettlement(ctx, st, now)
		return false
	}
	err = s.st.WithTx(ctx, func(tx *store.Tx) error {
		st.Status, st.BankRef, st.Attempts = store.SettleDone, res.Ref, st.Attempts+1
		if err := tx.UpdateOfflineSettlement(ctx, st, now); err != nil {
			return err
		}
		if err := tx.SetRecordStatus(ctx, st.DeviceID, st.Counter, store.RecordSettled); err != nil {
			return err
		}
		evs, err := tx.ListOfflineEvents(ctx, key)
		if err != nil {
			return err
		}
		var verify string
		for _, e := range evs {
			if e.Stage == model.StageOfflineVerify {
				verify = e.CurrentHash
			}
		}
		_, err = s.event(ctx, tx, key, model.StageOfflineSettle, []string{verify}, map[string]string{
			"bank_ref": res.Ref, "payee_account": payee.ID})
		return err
	})
	if err != nil {
		s.log.Error("record settlement", "err", err)
		return false
	}
	amt := "Rs " + offline.FormatRupees(st.Amount)
	_ = s.sms.Send(ctx, payee.Phone, "PSTCO-Pay: received "+amt+". Ref "+res.Ref)
	if rec, err := s.st.GetRecord(ctx, st.DeviceID, st.Counter); err == nil {
		if payer, err := s.st.GetAccount(ctx, rec.PayerAccount); err == nil {
			_ = s.sms.Send(ctx, payer.Phone, "PSTCO-Pay: your offline payment of "+amt+" to "+payee.Name+" is settled.")
		}
	}
	return true
}

// ExpireReserves releases the unspent part of reserves past expiry plus grace.
func (s *Service) ExpireReserves(ctx context.Context) int {
	cutoff := uint32(s.now().Add(-s.cfg.Policy.SettlementGrace).Unix())
	list, err := s.st.ExpiredReserves(ctx, cutoff)
	if err != nil {
		return 0
	}
	n := 0
	for _, r := range list {
		unspent := r.Amount - r.Spent
		if unspent > 0 {
			key := "expire:" + offline.FormatID(r.ID)
			if _, err := s.bankDo(ctx, key, func(c context.Context) (*bank.Result, error) {
				return s.bank.ReleaseFromHold(c, key, r.HoldID, unspent)
			}); err != nil {
				s.log.Warn("reserve release", "reserve", r.ID, "err", err)
				continue
			}
		}
		_ = s.st.WithTx(ctx, func(tx *store.Tx) error {
			if err := tx.CloseReserve(ctx, r.ID, store.ReserveExpired, s.now()); err != nil {
				return err
			}
			return tx.ShrinkReserveToSpent(ctx, r.ID)
		})
		n++
	}
	return n
}

// ------------------------------------------------------------ directory

// Directory returns the signed payee directory and revocation list.
func (s *Service) Directory(ctx context.Context) (*api.DirectoryResponse, error) {
	accts, err := s.st.ListListedAccounts(ctx)
	if err != nil {
		return nil, err
	}
	inactive, err := s.st.InactiveDeviceIDs(ctx)
	if err != nil {
		return nil, err
	}
	d := &offline.Directory{Version: s.now().Unix(), IssuedAt: s.now().Unix()}
	for _, a := range accts {
		d.Entries = append(d.Entries, offline.DirectoryEntry{PayeeID: offline.FormatID(a.PayeeID), Phone: a.Phone, Name: a.Name})
	}
	for _, id := range inactive {
		d.Revoked = append(d.Revoked, offline.FormatID(id))
	}
	sd, err := offline.SignDirectory(d, s.caSign)
	if err != nil {
		return nil, err
	}
	return &api.DirectoryResponse{Payload: sd.Payload, Signature: sd.Signature}, nil
}

// Payment returns one offline payment, visible to its payer and payee.
func (s *Service) Payment(ctx context.Context, caller *store.Device, device uint64, counter uint32) (*api.PaymentResponse, error) {
	rec, err := s.st.GetRecord(ctx, device, counter)
	if err != nil {
		return nil, apiErr(404, "not_found", "no such offline payment")
	}
	acct, err := s.st.GetAccount(ctx, caller.AccountID)
	if err != nil {
		return nil, err
	}
	if rec.PayerAccount != acct.ID && rec.PayeeID != acct.PayeeID {
		return nil, apiErr(403, "forbidden", "only the payer and payee can view this payment")
	}
	key := paymentKey(device, counter)
	evs, err := s.st.ListOfflineEvents(ctx, key)
	if err != nil {
		return nil, err
	}
	resp := &api.PaymentResponse{DeviceID: offline.FormatID(device), Counter: counter, AmountPaise: rec.Amount,
		PayeeID: offline.FormatID(rec.PayeeID), Status: rec.Status, Channel: rec.Channel,
		Verified: chain.VerifyGraph(evs, s.keys) == nil}
	for _, e := range evs {
		resp.Events = append(resp.Events, api.PaymentEvent{Seq: e.Seq, Stage: string(e.Stage), Status: string(e.Status),
			Signer: e.Signer, Hash: e.CurrentHash, PrevHash: e.PreviousEventHash, Payload: e.Payload, CreatedAt: e.CreatedAt})
	}
	return resp, nil
}

// VerifyPaymentGraph verifies one offline payment's server-side event chain.
func (s *Service) VerifyPaymentGraph(ctx context.Context, device uint64, counter uint32) error {
	evs, err := s.st.ListOfflineEvents(ctx, paymentKey(device, counter))
	if err != nil {
		return err
	}
	return chain.VerifyGraph(evs, s.keys)
}

// ------------------------------------------------------------ reconciliation

// TransferReporter is implemented by banks that publish a transfer report.
type TransferReporter interface {
	Transfers() []bank.Transfer
}

// Reconcile compares settled offline payments with the bank's transfer
// report and returns every discrepancy.
func (s *Service) Reconcile(ctx context.Context) ([]string, error) {
	rep, ok := s.bank.(TransferReporter)
	if !ok {
		return nil, errors.New("offlinesvc: bank does not publish a transfer report")
	}
	all, err := s.st.AllOfflineSettlements(ctx)
	if err != nil {
		return nil, err
	}
	byKey := map[string]bank.Transfer{}
	counts := map[string]int{}
	for _, t := range rep.Transfers() {
		byKey[t.Key] = t
		counts[t.Key]++
	}
	var out []string
	seen := map[string]bool{}
	for _, st := range all {
		key := paymentKey(st.DeviceID, st.Counter)
		seen[key] = true
		t, ok := byKey[key]
		switch {
		case st.Status == store.SettleDone && !ok:
			out = append(out, key+": settled internally, no bank transfer")
		case st.Status != store.SettleDone && ok:
			out = append(out, key+": bank transferred, internal status "+st.Status)
		case ok && t.Amount != st.Amount:
			out = append(out, fmt.Sprintf("%s: amount %d internal vs %d at bank", key, st.Amount, t.Amount))
		}
		if counts[key] > 1 {
			out = append(out, key+": transferred more than once")
		}
	}
	for k := range byKey {
		if !seen[k] && len(k) > 4 && k[:4] == "off_" {
			out = append(out, k+": bank transfer with no internal record")
		}
	}
	return out, nil
}

// ------------------------------------------------------------ background

// Start runs settlement, expiry and cleanup loops until ctx ends.
func (s *Service) Start(ctx context.Context) {
	loop := func(every time.Duration, fn func(context.Context)) {
		s.wg.Add(1)
		go func() {
			defer s.wg.Done()
			t := time.NewTicker(every)
			defer t.Stop()
			for {
				select {
				case <-ctx.Done():
					return
				case <-t.C:
					fn(ctx)
				}
			}
		}()
	}
	loop(s.cfg.SettleInterval, func(c context.Context) { s.SettleDue(c) })
	loop(s.cfg.ExpireInterval, func(c context.Context) { s.ExpireReserves(c) })
	loop(time.Minute, func(c context.Context) { _ = s.st.PurgeExpired(c, s.now()) })
	loop(5*time.Minute, func(c context.Context) {
		if d, err := s.Reconcile(c); err == nil && len(d) > 0 {
			s.log.Warn("offline reconciliation discrepancies", "count", len(d), "first", d[0])
		}
	})
}

// Wait blocks until background loops exit.
func (s *Service) Wait() { s.wg.Wait() }
