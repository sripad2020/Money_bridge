"""Software wallet for Python apps, kiosks and tests.

It follows the same rules as the Go SDK's software element: an Ed25519 key
and the offline balance, counter and chain head sealed with AES-256-GCM
under a scrypt key from the PIN; every payment deducted, linked, signed and
persisted before the record is released; PIN lockout and wipe; and an
approval guardrail where every money operation needs a fresh, single-use,
256-bit approval token bound to the exact operation, amount and payee.

``SoftwareWallet`` is blocking; ``AsyncSoftwareWallet`` has the same API with
coroutines for the network calls.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from . import formats as F
from .amount import MAX_PAISE
from .checks import CheckError, integer, one_of, text
from .client import AsyncClient, Client, register_message, unb64

STATE_FILE, ATTEMPTS_FILE = "pywallet.sealed", "pywallet.attempts"


class WalletError(Exception):
    pass


class Locked(WalletError): pass
class WrongPIN(WalletError): pass
class LockedOut(WalletError): pass
class Wiped(WalletError): pass
class NotProvisioned(WalletError): pass
class NoReserve(WalletError): pass
class ReserveExpired(WalletError): pass
class OverLimit(WalletError): pass
class Insufficient(WalletError): pass
class ApprovalRequired(WalletError): pass
class ApprovalInvalid(WalletError): pass
class AccessDenied(WalletError): pass


@dataclass(frozen=True)
class Approval:
    token: str  # 64 hex characters from secrets (CSPRNG)
    op: str
    amount_paise: int
    payee_id: int
    expires_at: float


def _b(s): return base64.b64decode(s) if s else b""
def _s(b): return base64.b64encode(b).decode() if b else ""


def _atomic_write(path: Path, data: bytes) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _intent(op: str, amount: int, payee: int) -> bytes:
    return hashlib.sha256(f"pstco-intent/1|{op}|{amount}|{payee:016x}".encode()).digest()


class SoftwareWallet:
    """A wallet whose key and state are protected by the PIN in software.
    It registers with software trust and the matching lower limits."""

    approval_ttl = 60.0

    def __init__(self, directory: str | os.PathLike, client: Client | AsyncClient | None = None,
                 *, kdf_n: int = 2 ** 15, clock=time.time):
        self.dir = Path(directory)
        self.client, self.kdf_n, self.clock = client, kdf_n, clock
        self._key: bytes | None = None
        self._st: dict | None = None
        self._reg_token = ""
        self._approvals: dict[bytes, tuple[bytes, float]] = {}
        self._violations = self._pin_fails = 0

    # ---------------------------------------------------------- lifecycle

    @classmethod
    def create(cls, directory, pin: str, client=None, **kw) -> "SoftwareWallet":
        w = cls(directory, client, **kw)
        if not (type(pin) is str and pin.isdigit() and 6 <= len(pin) <= 32):
            raise CheckError("pin", "6 to 32 digits", pin)
        w.dir.mkdir(parents=True, exist_ok=True)
        if (w.dir / STATE_FILE).exists():
            raise WalletError(f"wallet already exists in {w.dir}")
        key = ed25519.Ed25519PrivateKey.generate()
        seed = key.private_bytes_raw()
        w._salt = secrets.token_bytes(16)
        w._key = w._derive(pin, w._salt)
        w._st = {"seed": _s(seed), "public_key": _s(key.public_key().public_bytes_raw()), "device_id": 0,
                 "cert": "", "ca": "", "cert_limit": 0, "reserve": "", "reserve_id": 0, "balance": 0,
                 "next_counter": 1, "chain_head": _s(bytes(16)), "expiry": 0, "per_payment_limit": 0,
                 "account_id": "", "phone": "", "name": "", "payee_id": 0, "trust": "", "directory": None,
                 "sent": [], "received": [], "outbox": [], "pending_reserve_key": "", "pending_reserve_amount": 0}
        w._persist()
        return w

    def _derive(self, pin: str, salt: bytes) -> bytes:
        return hashlib.scrypt(pin.encode(), salt=salt, n=self.kdf_n, r=8, p=1, maxmem=128 * 1024 * 1024, dklen=32)

    def _persist(self) -> None:
        nonce = secrets.token_bytes(12)
        ct = AESGCM(self._key).encrypt(nonce, json.dumps(self._st).encode(), b"pstco-pywallet")
        doc = {"v": 1, "kdf_n": self.kdf_n, "salt": _s(self._salt), "nonce": _s(nonce), "ct": _s(ct)}
        _atomic_write(self.dir / STATE_FILE, json.dumps(doc).encode())

    def unlock(self, pin: str) -> None:
        if self._st is not None:
            return
        path = self.dir / STATE_FILE
        attempts_path = self.dir / ATTEMPTS_FILE
        att = json.loads(attempts_path.read_text()) if attempts_path.exists() else {"failures": 0, "locked_until": 0}
        if not path.exists():
            raise Wiped("wallet wiped after repeated wrong PINs") if att["failures"] else WalletError("no wallet")
        if att["locked_until"] > self.clock():
            raise LockedOut("too many wrong PINs, try later")
        doc = json.loads(path.read_text())
        self.kdf_n, self._salt = doc["kdf_n"], _b(doc["salt"])
        key = self._derive(text("pin", pin, 1, 32), self._salt)
        try:
            plain = AESGCM(key).decrypt(_b(doc["nonce"]), _b(doc["ct"]), b"pstco-pywallet")
        except Exception:
            att["failures"] += 1
            if att["failures"] >= 10:
                path.unlink()
                _atomic_write(attempts_path, json.dumps(att).encode())
                raise Wiped("wallet wiped after 10 wrong PINs")
            if att["failures"] >= 5:
                att["locked_until"] = self.clock() + 30 * 2 ** (att["failures"] - 5)
            _atomic_write(attempts_path, json.dumps(att).encode())
            raise WrongPIN("wrong PIN")
        if att["failures"]:
            _atomic_write(attempts_path, json.dumps({"failures": 0, "locked_until": 0}).encode())
        self._key, self._st = key, json.loads(plain)

    def lock(self) -> None:
        self._key = self._st = None
        self._approvals.clear()
        self._violations = self._pin_fails = 0

    def _state(self) -> dict:
        if self._st is None:
            raise Locked("wallet is locked")
        return self._st

    @property
    def device_id(self) -> int:
        return self._state()["device_id"]

    # ------------------------------------------------------------ signing

    def sign_auth(self, msg: bytes) -> bytes:
        if not (msg.startswith(b"PSTCO-REQ-1\n") or msg.startswith(b"PSTCO-REG-1\n")):
            raise WalletError("refusing to sign a non-API message")
        return ed25519.Ed25519PrivateKey.from_private_bytes(_b(self._state()["seed"])).sign(msg)

    def _device_client(self):
        st = self._state()
        if not st["device_id"]:
            raise NotProvisioned("register the device first")
        if self.client is None:
            raise WalletError("no server client")
        return self.client.with_device(st["device_id"], self)

    # ----------------------------------------------------------- approvals

    def approve(self, op: str, amount_paise: int, pin: str, payee_id: int = 0) -> Approval:
        """Re-confirm the PIN and authorise exactly one operation, once."""
        self._state()
        one_of("op", op, ("pay", "deposit", "reserve"))
        integer("amount_paise", amount_paise, 0 if op == "reserve" else 1, MAX_PAISE)
        integer("payee_id", payee_id, 1 if op == "pay" else 0, (1 << 64) - 1)
        if not hmac.compare_digest(self._derive(text("pin", pin, 1, 32), self._salt), self._key):
            self._pin_fails += 1
            if self._pin_fails >= 5:
                self.lock()
                raise LockedOut("wallet locked after 5 wrong PINs")
            raise WrongPIN("wrong PIN")
        self._pin_fails = 0
        token = secrets.token_hex(32)
        exp = self.clock() + self.approval_ttl
        self._approvals[hashlib.sha256(token.encode()).digest()] = (_intent(op, amount_paise, payee_id), exp)
        return Approval(token, op, amount_paise, payee_id, exp)

    def _consume(self, a: Approval | None, op: str, amount: int, payee: int = 0) -> None:
        if a is None:
            raise ApprovalRequired("this operation needs a fresh approval")
        entry = self._approvals.pop(hashlib.sha256(a.token.encode()).digest(), None)
        if entry is None or self.clock() > entry[1] or not hmac.compare_digest(entry[0], _intent(op, amount, payee)):
            self._violations += 1
            if self._violations >= 3:
                self.lock()
                raise AccessDenied("wallet locked after repeated access violations")
            raise ApprovalInvalid("approval is invalid, used, expired or for another operation")

    # ---------------------------------------------------------- onboarding

    def start_account(self, phone: str, name: str, listed: bool = False) -> str:
        return self.client.start_account(phone, name, listed).get("dev_otp", "")

    def _apply_verify(self, phone: str, r: dict) -> None:
        st = self._state()
        st["account_id"], st["phone"], st["payee_id"] = r["account_id"], F.normalize_phone(phone), F.parse_id(r["payee_id"])
        self._reg_token = r["registration_token"]
        self._persist()

    def verify_account(self, phone: str, otp: str) -> None:
        self._apply_verify(phone, self.client.verify_account(phone, otp))

    def _register_request(self, challenge: bytes) -> dict:
        if not self._reg_token:
            raise WalletError("verify the account first")
        pub = _b(self._state()["public_key"])
        proof = self.sign_auth(register_message(challenge, self._reg_token, pub))
        return {"registration_token": self._reg_token, "challenge": _s(challenge), "algorithm": "ed25519",
                "element_kind": "software", "public_key": _s(pub), "proof": _s(proof),
                "attestation": {"format": "none"}, "model": "python-sdk", "app_version": "1.0"}

    def _apply_register(self, resp: dict) -> dict:
        st = self._state()
        cert_raw, ca = unb64(resp["certificate"]), unb64(resp["ca_public_key"])
        cert, _ = F.DeviceCert.from_bytes(cert_raw)
        cert.verify(ca, self.clock())
        if cert.public_key != _b(st["public_key"]):
            raise WalletError("certificate is for another key")
        st["receipt_key"] = resp.get("receipt_public_key", "")
        st.update(device_id=cert.device_id, cert=_s(cert_raw), ca=_s(ca), cert_limit=cert.per_payment_limit,
                  trust=resp["trust"], account_id=resp["account_id"], payee_id=F.parse_id(resp["payee_id"]))
        self._reg_token = ""
        self._persist()
        return resp

    def set_name(self, name: str) -> None:
        self._state()["name"] = text("name", name, 1, 64)
        self._persist()

    def register(self) -> dict:
        ch = self.client.challenge(self._reg_token)
        return self._apply_register(self.client.register(self._register_request(ch)))

    # -------------------------------------------------------- online money

    def deposit(self, amount_paise: int, approval: Approval | None) -> dict:
        self._consume(approval, "deposit", amount_paise)
        return self._device_client().deposit(amount_paise)

    def _reserve_args(self, amount_paise: int) -> tuple:
        st = self._state()
        if not st["pending_reserve_key"] or st["pending_reserve_amount"] != amount_paise:
            st["pending_reserve_key"], st["pending_reserve_amount"] = secrets.token_hex(16), amount_paise
            self._persist()
        return amount_paise, st["next_counter"], _b(st["chain_head"]), st["pending_reserve_key"]

    def _apply_reserve(self, resp: dict) -> dict:
        st = self._state()
        raw = unb64(resp["instruction"])
        r = F.Reserve.from_bytes(raw)
        r.verify(_b(st["ca"]))
        if r.device_id != st["device_id"]:
            raise WalletError("reserve is for another device")
        if r.reserve_id != st["reserve_id"]:
            if r.counter_start != st["next_counter"]:
                raise WalletError("reserve does not continue this wallet's counter; sync first")
            st.update(reserve=_s(raw), reserve_id=r.reserve_id, balance=r.amount_paise, expiry=r.expiry,
                      per_payment_limit=min(r.per_payment_limit, st["cert_limit"]), chain_head=_s(r.genesis))
        st["pending_reserve_key"], st["pending_reserve_amount"] = "", 0
        self._persist()
        return resp

    def create_reserve(self, amount_paise: int, approval: Approval | None) -> dict:
        self._consume(approval, "reserve", amount_paise)
        self.sync()
        return self._apply_reserve(self._device_client().create_reserve(*self._reserve_args(amount_paise)))

    # ------------------------------------------------------------- paying

    def quote_phone(self, phone: str) -> dict:
        p = F.normalize_phone(phone)
        q = {"payee_id": F.payee_id_for_phone(p), "phone": p, "name": "", "listed": False}
        st = self._state()
        if st["directory"]:
            d = F.open_directory(_b(st["directory"]["payload"]), _b(st["directory"]["signature"]), _b(st["ca"]))
            for e in d.get("entries") or []:
                if e["phone"] == p:
                    q["name"], q["listed"] = e["name"], True
        return q

    def pay(self, quote: dict, amount_paise: int, delivery: str, approval: Approval | None) -> dict:
        """Sign an offline payment. Needs no network."""
        st = self._state()
        one_of("delivery", delivery, ("qr", "sms"))
        integer("amount_paise", amount_paise, 1, MAX_PAISE)
        payee = integer("payee_id", quote["payee_id"], 1, (1 << 64) - 1)
        if not st["device_id"]:
            raise NotProvisioned("register the device first")
        if payee == st["payee_id"]:
            raise WalletError("cannot pay yourself")
        self._consume(approval, "pay", amount_paise, payee)
        now = int(self.clock())
        if not st["reserve_id"]:
            raise NoReserve("no offline balance loaded")
        if now >= st["expiry"]:
            raise ReserveExpired("offline balance expired; sync to renew")
        if amount_paise > st["per_payment_limit"]:
            raise OverLimit("amount above the per-payment limit")
        if amount_paise > st["balance"]:
            raise Insufficient("insufficient offline balance")
        rec = F.Record(st["device_id"], st["next_counter"], amount_paise, payee, now, st["expiry"], _b(st["chain_head"]))
        signed = rec.signed_bytes()
        sig = ed25519.Ed25519PrivateKey.from_private_bytes(_b(st["seed"])).sign(F.signing_message(signed))
        raw = signed + sig
        before = json.dumps(st)
        st["balance"] -= amount_paise
        st["next_counter"] += 1
        st["chain_head"] = _s(F.record_hash(raw))
        st["sent"].append({"counter": rec.counter, "raw": _s(raw), "payee_id": payee, "amount_paise": amount_paise,
                           "delivery": delivery, "synced": False, "status": ""})
        cert = _b(st["cert"])
        out = {"counter": rec.counter, "record": raw, "qr": F.encode_payment_qr(raw, cert), "sms": None}
        if delivery == "sms":
            msg = {"id": secrets.token_hex(8), "to": quote["phone"], "payload": _s(raw + cert), "sent": False}
            st["outbox"].append(msg)
            out["sms"] = msg
        try:
            self._persist()  # before releasing the record
        except Exception:
            self._st = json.loads(before)
            raise
        return out

    # ------------------------------------------------------------ receiving

    def accept(self, code: str) -> dict:
        record, cert = F.decode_payment_qr(code)
        return self.accept_bytes(record + cert)

    def accept_bytes(self, data: bytes) -> dict:
        st = self._state()
        if not st["payee_id"]:
            raise WalletError("account not verified")
        record, cert = data[:F.RECORD_SIZE], data[F.RECORD_SIZE:]
        r, c = F.verify_payment(record, cert, _b(st["ca"]), st["payee_id"], self.clock())
        if st["directory"]:
            d = F.open_directory(_b(st["directory"]["payload"]), _b(st["directory"]["signature"]), _b(st["ca"]))
            if f"{r.device_id:016x}" in (d.get("revoked_devices") or []):
                raise F.PaymentRejected("payer device is revoked")
        if any(x["device_id"] == r.device_id and x["counter"] == r.counter for x in st["received"]):
            raise F.PaymentRejected("payment already received")
        item = {"device_id": r.device_id, "counter": r.counter, "raw": _s(record), "amount_paise": r.amount_paise,
                "payer_payee_id": c.owner_payee, "synced": False, "status": ""}
        st["received"].append(item)
        self._persist()
        return {k: v for k, v in item.items() if k != "raw"}

    # ---------------------------------------------------------------- sync

    def _sync_payload(self) -> list[bytes]:
        st = self._state()
        return [_b(x["raw"]) for x in st["sent"] + st["received"] if not x["synced"]]

    def _apply_sync(self, results: list[dict], directory: dict | None) -> dict:
        st = self._state()
        rep = {"uploaded": len(results), "accepted": 0, "duplicate": 0, "rejected": 0, "bad_receipts": 0,
               "results": results}
        rkey = _b(st.get("receipt_key", ""))

        def proven(raw: str, res: dict) -> bool:
            # An accepted or duplicate result counts only with a valid
            # server receipt for these exact bytes.
            if res["status"] not in ("ACCEPTED", "DUPLICATE") or not rkey:
                return True
            try:
                F.verify_receipt(_b(res.get("receipt", "")), _b(raw), rkey)
                return True
            except (F.PaymentRejected, CheckError, ValueError):
                rep["bad_receipts"] += 1
                return False

        for res in results:
            dev, ctr, status = F.parse_id(res["device_id"]) if res.get("device_id") else 0, res.get("counter", 0), res["status"]
            key = {"ACCEPTED": "accepted", "SETTLED": "accepted", "DUPLICATE": "duplicate"}.get(status, "rejected")
            rep[key] += 1
            for x in st["sent"]:
                if dev == st["device_id"] and x["counter"] == ctr and proven(x["raw"], res):
                    x.update(synced=True, status=status, receipt=res.get("receipt", ""))
            for x in st["received"]:
                if x["device_id"] == dev and x["counter"] == ctr and proven(x["raw"], res):
                    x.update(synced=True, status=status, receipt=res.get("receipt", ""))
        if directory:
            F.open_directory(directory["payload"], directory["signature"], _b(st["ca"]))
            st["directory"] = {"payload": _s(directory["payload"]), "signature": _s(directory["signature"])}
        self._persist()
        return rep

    def sync(self) -> dict:
        c = self._device_client()
        records = self._sync_payload()
        results = c.sync(records)["results"] if records else []
        return self._apply_sync(results, c.directory())

    # -------------------------------------------------------------- status

    def balance(self) -> dict:
        st = self._state()
        return {"offline_paise": st["balance"], "per_payment_limit": st["per_payment_limit"], "expiry": st["expiry"],
                "next_counter": st["next_counter"], "trust": st["trust"], "device_id": st["device_id"],
                "unsynced_sent": sum(not x["synced"] for x in st["sent"]),
                "unsynced_received": sum(not x["synced"] for x in st["received"])}

    def pending_sms(self) -> list[dict]:
        return [m for m in self._state()["outbox"] if not m["sent"]]

    def payee_card(self) -> str:
        st = self._state()
        return F.encode_payee_qr(st["phone"], st["name"] or st["phone"])


class AsyncSoftwareWallet(SoftwareWallet):
    """Same wallet; network operations are coroutines (use with AsyncClient)."""

    async def start_account(self, phone: str, name: str, listed: bool = False) -> str:
        return (await self.client.start_account(phone, name, listed)).get("dev_otp", "")

    async def verify_account(self, phone: str, otp: str) -> None:
        self._apply_verify(phone, await self.client.verify_account(phone, otp))

    async def register(self) -> dict:
        ch = await self.client.challenge(self._reg_token)
        return self._apply_register(await self.client.register(self._register_request(ch)))

    async def deposit(self, amount_paise: int, approval: Approval | None) -> dict:
        self._consume(approval, "deposit", amount_paise)
        return await self._device_client().deposit(amount_paise)

    async def create_reserve(self, amount_paise: int, approval: Approval | None) -> dict:
        self._consume(approval, "reserve", amount_paise)
        await self.sync()
        return self._apply_reserve(await self._device_client().create_reserve(*self._reserve_args(amount_paise)))

    async def sync(self) -> dict:
        c = self._device_client()
        records = self._sync_payload()
        results = (await c.sync(records))["results"] if records else []
        return self._apply_sync(results, await c.directory())
