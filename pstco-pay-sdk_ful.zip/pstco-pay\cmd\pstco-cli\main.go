// Command pstco-cli is a merchant and operator client for PSTCO-Pay.
//
//	pstco-cli pay -amount 1234.00 [-token tok_visa_ok] [-key order-1] [-watch]
//	pstco-cli status -id pay_... [-resolve] | -key order-1
//	pstco-cli watch -id pay_...
//	pstco-cli recover -id pay_...
//	pstco-cli refund -id pay_... -reason "customer request"
//	pstco-cli graph -id pay_... [-json]
//	pstco-cli transport
//	pstco-cli reconcile   (admin certificate)
//	pstco-cli anchors     (admin certificate)
package main

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"

	rpc "pstcopay/sdk/merchant"
)

type common struct {
	addr, certs, cert, merchant, secret string
	timeout                             time.Duration
}

func (c *common) register(fs *flag.FlagSet, defaultCert string) {
	fs.StringVar(&c.addr, "addr", "localhost:8443", "server address")
	fs.StringVar(&c.certs, "certs", "certs", "certificate directory")
	fs.StringVar(&c.cert, "cert", defaultCert, "client certificate name in the certificate directory")
	fs.StringVar(&c.merchant, "merchant", "merchant_demo", "merchant id")
	fs.StringVar(&c.secret, "secret", envOr("PSTCO_MERCHANT_SECRET", "demo-merchant-secret"), "merchant signing secret")
	fs.DurationVar(&c.timeout, "timeout", 15*time.Second, "RPC timeout")
}

func (c *common) dial() *rpc.Client {
	cl, err := rpc.DialCertDir(c.addr, c.certs, c.cert, 1, "")
	if err != nil {
		fail(err)
	}
	return cl
}

func main() {
	if len(os.Args) < 2 {
		usage()
	}
	cmd, args := os.Args[1], os.Args[2:]
	fs := flag.NewFlagSet(cmd, flag.ExitOnError)
	var c common
	defaultCert := "merchant-demo"
	if cmd == "reconcile" || cmd == "anchors" {
		defaultCert = "pstco-admin"
	}
	c.register(fs, defaultCert)

	switch cmd {
	case "pay":
		amount := fs.String("amount", "1234.00", "amount in major units, e.g. 1234.00")
		currency := fs.String("currency", "INR", "ISO currency")
		customer := fs.String("customer", "cust_demo", "customer id")
		token := fs.String("token", "tok_visa_ok", "card token (tok_decline_*, tok_fraud_*, tok_lowbal_* simulate failures)")
		key := fs.String("key", "", "idempotency key (default: random)")
		deadline := fs.Int64("deadline-ms", 3000, "fast-path deadline")
		watch := fs.Bool("watch", false, "stream state updates until final")
		_ = fs.Parse(args)
		minor, err := parseMinor(*amount)
		if err != nil {
			fail(err)
		}
		if *key == "" {
			*key = "order-" + randHex(6)
		}
		now := time.Now()
		req := &rpc.CreatePaymentRequest{MerchantID: c.merchant, CustomerID: *customer, IdempotencyKey: *key,
			AmountMinor: minor, Currency: *currency, CardToken: *token, ClientTimeMS: now.UnixMilli(),
			ExpiresAtMS: now.Add(time.Hour).UnixMilli(), DeadlineMS: *deadline}
		req.Sign(c.secret)
		cl := c.dial()
		defer cl.Close()
		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		defer cancel()
		start := time.Now()
		v, err := cl.CreatePayment(ctx, req)
		if err != nil {
			fail(err)
		}
		fmt.Printf("round trip %.2f ms (server %.2f ms)\n", float64(time.Since(start).Microseconds())/1000, v.ServerMS)
		printJSON(v)
		if *watch {
			watchPayment(cl, v.PaymentID, 30*time.Second)
		}
	case "status":
		id := fs.String("id", "", "payment id")
		key := fs.String("key", "", "idempotency key (instead of -id)")
		resolve := fs.Bool("resolve", false, "run CSDR if the payment is unfinished")
		_ = fs.Parse(args)
		cl := c.dial()
		defer cl.Close()
		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		defer cancel()
		v, err := cl.GetPayment(ctx, &rpc.GetPaymentRequest{PaymentID: *id, MerchantID: c.merchant,
			IdempotencyKey: *key, Resolve: *resolve})
		if err != nil {
			fail(err)
		}
		printJSON(v)
	case "watch":
		id := fs.String("id", "", "payment id")
		d := fs.Duration("for", 60*time.Second, "how long to watch")
		_ = fs.Parse(args)
		cl := c.dial()
		defer cl.Close()
		watchPayment(cl, *id, *d)
	case "recover":
		id := fs.String("id", "", "payment id")
		_ = fs.Parse(args)
		cl := c.dial()
		defer cl.Close()
		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		defer cancel()
		v, err := cl.RecoverPayment(ctx, *id)
		if err != nil {
			fail(err)
		}
		printJSON(v)
	case "refund":
		id := fs.String("id", "", "payment id")
		reason := fs.String("reason", "merchant request", "refund reason")
		_ = fs.Parse(args)
		cl := c.dial()
		defer cl.Close()
		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		defer cancel()
		v, err := cl.RefundPayment(ctx, &rpc.RefundRequest{PaymentID: *id, MerchantID: c.merchant, Reason: *reason})
		if err != nil {
			fail(err)
		}
		printJSON(v)
	case "graph":
		id := fs.String("id", "", "payment id")
		asJSON := fs.Bool("json", false, "print the raw graph as JSON")
		_ = fs.Parse(args)
		cl := c.dial()
		defer cl.Close()
		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		defer cancel()
		g, err := cl.GetExecutionGraph(ctx, *id)
		if err != nil {
			fail(err)
		}
		if *asJSON {
			printJSON(g)
			return
		}
		fmt.Printf("payment %s  verified=%t %s\n", g.PaymentID, g.Verified, g.VerificationError)
		fmt.Printf("%-4s %-13s %-3s %-10s %-18s %-14s %-14s %s\n", "SEQ", "STAGE", "TRY", "STATUS", "SIGNER", "HASH", "PREV", "NOTE")
		for _, ev := range g.Events {
			note := ev.Payload["decision"]
			if note == "" {
				note = ev.Payload["failure_code"]
			}
			if ev.RetryOfEventHash != "" {
				note = strings.TrimSpace(note + " retry_of=" + ev.RetryOfEventHash[:12])
			}
			fmt.Printf("%-4d %-13s %-3d %-10s %-18s %-14s %-14s %s\n", ev.Seq, ev.Stage, ev.Attempt, ev.Status,
				ev.Signer, ev.CurrentHash[:12], ev.PreviousEventHash[:12], note)
		}
	case "transport":
		_ = fs.Parse(args)
		cl := c.dial()
		defer cl.Close()
		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		defer cancel()
		t, err := cl.GetTransportState(ctx)
		if err != nil {
			fail(err)
		}
		printJSON(t)
	case "reconcile":
		_ = fs.Parse(args)
		cl := c.dial()
		defer cl.Close()
		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		defer cancel()
		r, err := cl.Reconcile(ctx)
		if err != nil {
			fail(err)
		}
		printJSON(r)
	case "anchors":
		_ = fs.Parse(args)
		cl := c.dial()
		defer cl.Close()
		ctx, cancel := context.WithTimeout(context.Background(), c.timeout)
		defer cancel()
		r, err := cl.VerifyAnchors(ctx)
		if err != nil {
			fail(err)
		}
		printJSON(r)
	default:
		usage()
	}
}

func watchPayment(cl *rpc.Client, id string, d time.Duration) {
	ctx, cancel := context.WithTimeout(context.Background(), d)
	defer cancel()
	err := cl.WatchPayment(ctx, id, func(ev *rpc.WatchEvent) bool {
		fmt.Printf("%s  %-24s %s\n", time.UnixMilli(ev.AtMS).Format("15:04:05.000"), ev.State, ev.FailureCode)
		return true
	})
	if err != nil && !errors.Is(err, context.DeadlineExceeded) && !strings.Contains(err.Error(), "DeadlineExceeded") {
		fail(err)
	}
}

// parseMinor converts "1234.5" to 123450 without floating point.
func parseMinor(s string) (int64, error) {
	whole, frac, _ := strings.Cut(strings.TrimSpace(s), ".")
	if len(frac) > 2 {
		return 0, fmt.Errorf("amount %q has more than 2 decimals", s)
	}
	frac = (frac + "00")[:2]
	w, err := strconv.ParseInt(whole, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("amount %q: %w", s, err)
	}
	f, err := strconv.ParseInt(frac, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("amount %q: %w", s, err)
	}
	return w*100 + f, nil
}

func randHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func envOr(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}

func printJSON(v any) {
	b, _ := json.MarshalIndent(v, "", "  ")
	fmt.Println(string(b))
}

func fail(err error) {
	fmt.Fprintln(os.Stderr, "error:", err)
	os.Exit(1)
}

func usage() {
	fmt.Fprintln(os.Stderr, "usage: pstco-cli <pay|status|watch|recover|refund|graph|transport|reconcile|anchors> [flags]")
	os.Exit(2)
}
