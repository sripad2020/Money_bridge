// Package bank simulates the bank that holds wallet money for offline
// payments: accounts, deposits, reserve holds for offline balances, and
// transfers out of a hold to a payee. Every operation is idempotent by key
// and queryable, with fault injection, exactly like the card acquirer
// simulator, so the server's recovery logic can be tested end to end.
// A real bank integration replaces this package behind the same methods.
package bank

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"sync"
	"time"
)

var (
	ErrUnavailable  = errors.New("bank: unavailable")      // no effect
	ErrTimeout      = errors.New("bank: response timeout") // outcome unknown
	ErrNotFound     = errors.New("bank: not found")
	ErrInsufficient = errors.New("bank: insufficient funds")
)

// Fault is an injected failure mode.
type Fault int

const (
	FaultNone Fault = iota
	FaultUnavailable
	FaultLostResponse
)

// Result is the recorded outcome of one operation.
type Result struct {
	Key    string    `json:"key"`
	Op     string    `json:"op"`
	Ref    string    `json:"ref"`
	Amount int64     `json:"amount"`
	OK     bool      `json:"ok"`
	Reason string    `json:"reason,omitempty"`
	At     time.Time `json:"at"`
}

// Transfer is one line of the bank's transfer report.
type Transfer struct {
	Key    string    `json:"key"`
	HoldID string    `json:"hold_id"`
	To     string    `json:"to"`
	Amount int64     `json:"amount"`
	At     time.Time `json:"at"`
}

type account struct {
	Available int64 `json:"available"`
	Held      int64 `json:"held"`
}

type hold struct {
	Account   string `json:"account"`
	Remaining int64  `json:"remaining"`
}

// Bank is the simulator.
type Bank struct {
	mu        sync.Mutex
	accounts  map[string]*account
	holds     map[string]*hold
	results   map[string]*Result
	transfers []Transfer
	faults    map[string][]Fault
	effects   map[string]int
	now       func() time.Time
}

// New creates an empty bank.
func New() *Bank {
	return &Bank{accounts: map[string]*account{}, holds: map[string]*hold{}, results: map[string]*Result{},
		faults: map[string][]Fault{}, effects: map[string]int{}, now: time.Now}
}

// PushFault queues faults for an operation ("deposit", "hold", "transfer", "release").
func (b *Bank) PushFault(op string, f ...Fault) {
	b.mu.Lock()
	b.faults[op] = append(b.faults[op], f...)
	b.mu.Unlock()
}

// Effects returns how many operations of a type actually executed.
func (b *Bank) Effects(op string) int {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.effects[op]
}

func (b *Bank) acct(id string) *account {
	a, ok := b.accounts[id]
	if !ok {
		a = &account{}
		b.accounts[id] = a
	}
	return a
}

func (b *Bank) exec(ctx context.Context, op, key string, effect func() (*Result, error)) (*Result, error) {
	b.mu.Lock()
	var f Fault
	if q := b.faults[op]; len(q) > 0 {
		f, b.faults[op] = q[0], q[1:]
	}
	b.mu.Unlock()
	if f == FaultUnavailable || ctx.Err() != nil {
		return nil, ErrUnavailable
	}
	b.mu.Lock()
	r, seen := b.results[key]
	if !seen {
		var err error
		r, err = effect()
		if err != nil {
			b.mu.Unlock()
			return nil, err
		}
		r.Key, r.Op, r.At = key, op, b.now()
		b.results[key] = r
		b.effects[op]++
	}
	out := *r
	b.mu.Unlock()
	if f == FaultLostResponse {
		return nil, ErrTimeout
	}
	if !out.OK {
		return &out, fmt.Errorf("%w: %s", ErrInsufficient, out.Reason)
	}
	return &out, nil
}

// Deposit credits an account (a top-up from the customer's bank or UPI).
func (b *Bank) Deposit(ctx context.Context, key, account string, amount int64) (*Result, error) {
	return b.exec(ctx, "deposit", key, func() (*Result, error) {
		if amount <= 0 {
			return nil, fmt.Errorf("bank: deposit must be positive")
		}
		b.acct(account).Available += amount
		return &Result{Ref: "dep_" + key, Amount: amount, OK: true}, nil
	})
}

// Hold moves money from available into a named hold backing an offline reserve.
func (b *Bank) Hold(ctx context.Context, key, account, holdID string, amount int64) (*Result, error) {
	return b.exec(ctx, "hold", key, func() (*Result, error) {
		a := b.acct(account)
		if amount <= 0 {
			return nil, fmt.Errorf("bank: hold must be positive")
		}
		if a.Available < amount {
			return &Result{Amount: amount, Reason: "available balance too low"}, nil
		}
		if _, dup := b.holds[holdID]; dup {
			return nil, fmt.Errorf("bank: hold %s exists", holdID)
		}
		a.Available -= amount
		a.Held += amount
		b.holds[holdID] = &hold{Account: account, Remaining: amount}
		return &Result{Ref: holdID, Amount: amount, OK: true}, nil
	})
}

// TransferFromHold pays a payee out of a hold.
func (b *Bank) TransferFromHold(ctx context.Context, key, holdID, to string, amount int64) (*Result, error) {
	return b.exec(ctx, "transfer", key, func() (*Result, error) {
		h, ok := b.holds[holdID]
		if !ok {
			return nil, fmt.Errorf("%w: hold %s", ErrNotFound, holdID)
		}
		if h.Remaining < amount {
			return &Result{Amount: amount, Reason: "hold exhausted"}, nil
		}
		h.Remaining -= amount
		b.acct(h.Account).Held -= amount
		b.acct(to).Available += amount
		b.transfers = append(b.transfers, Transfer{Key: key, HoldID: holdID, To: to, Amount: amount, At: b.now()})
		return &Result{Ref: "trf_" + key, Amount: amount, OK: true}, nil
	})
}

// MoveHold moves money between two holds of the same account, creating the
// target hold if needed. A top-up uses it to carry an unspent offline balance
// into the new reserve without ever leaving it unbacked.
func (b *Bank) MoveHold(ctx context.Context, key, fromHold, toHold string, amount int64) (*Result, error) {
	return b.exec(ctx, "move", key, func() (*Result, error) {
		from, ok := b.holds[fromHold]
		if !ok {
			return nil, fmt.Errorf("%w: hold %s", ErrNotFound, fromHold)
		}
		if from.Remaining < amount {
			return &Result{Amount: amount, Reason: "source hold too small"}, nil
		}
		to, ok := b.holds[toHold]
		if !ok {
			to = &hold{Account: from.Account}
			b.holds[toHold] = to
		}
		if to.Account != from.Account {
			return nil, fmt.Errorf("bank: holds belong to different accounts")
		}
		from.Remaining -= amount
		to.Remaining += amount
		return &Result{Ref: toHold, Amount: amount, OK: true}, nil
	})
}

// ReleaseFromHold returns part of a hold to the owner's available balance.
func (b *Bank) ReleaseFromHold(ctx context.Context, key, holdID string, amount int64) (*Result, error) {
	return b.exec(ctx, "release", key, func() (*Result, error) {
		h, ok := b.holds[holdID]
		if !ok {
			return nil, fmt.Errorf("%w: hold %s", ErrNotFound, holdID)
		}
		amount = min(amount, h.Remaining)
		h.Remaining -= amount
		a := b.acct(h.Account)
		a.Held -= amount
		a.Available += amount
		return &Result{Ref: "rel_" + key, Amount: amount, OK: true}, nil
	})
}

// Query returns the recorded outcome of an operation key.
func (b *Bank) Query(_ context.Context, key string) (*Result, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	r, ok := b.results[key]
	if !ok {
		return nil, ErrNotFound
	}
	out := *r
	return &out, nil
}

// Balance returns an account's available and held money.
func (b *Bank) Balance(_ context.Context, account string) (available, held int64) {
	b.mu.Lock()
	defer b.mu.Unlock()
	a := b.acct(account)
	return a.Available, a.Held
}

// HoldRemaining returns what is left in a hold.
func (b *Bank) HoldRemaining(holdID string) int64 {
	b.mu.Lock()
	defer b.mu.Unlock()
	if h, ok := b.holds[holdID]; ok {
		return h.Remaining
	}
	return 0
}

// Transfers returns the transfer report for reconciliation.
func (b *Bank) Transfers() []Transfer {
	b.mu.Lock()
	defer b.mu.Unlock()
	return append([]Transfer(nil), b.transfers...)
}

type snapshot struct {
	Accounts  map[string]*account `json:"accounts"`
	Holds     map[string]*hold    `json:"holds"`
	Results   map[string]*Result  `json:"results"`
	Transfers []Transfer          `json:"transfers"`
	Effects   map[string]int      `json:"effects"`
}

// Save persists the simulator state atomically.
func (b *Bank) Save(path string) error {
	b.mu.Lock()
	data, err := json.Marshal(snapshot{b.accounts, b.holds, b.results, b.transfers, b.effects})
	b.mu.Unlock()
	if err != nil {
		return err
	}
	if err := os.WriteFile(path+".tmp", data, 0o600); err != nil {
		return err
	}
	return os.Rename(path+".tmp", path)
}

// Load restores simulator state if the file exists.
func (b *Bank) Load(path string) error {
	data, err := os.ReadFile(path)
	if errors.Is(err, os.ErrNotExist) {
		return nil
	}
	if err != nil {
		return err
	}
	var s snapshot
	if err := json.Unmarshal(data, &s); err != nil {
		return err
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	if s.Accounts != nil {
		b.accounts = s.Accounts
	}
	if s.Holds != nil {
		b.holds = s.Holds
	}
	if s.Results != nil {
		b.results = s.Results
	}
	if s.Effects != nil {
		b.effects = s.Effects
	}
	b.transfers = s.Transfers
	return nil
}
