package offlinesvc

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"pstcopay/internal/store"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/offline/api"
	"pstcopay/sdk/validate"
)

const maxBody = 1 << 20

type ctxKey struct{}

// Handler returns the offline API.
func (s *Service) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("POST "+api.PathAccountStart, s.public(func(ctx context.Context, b []byte, _ *http.Request) (any, error) {
		var r api.AccountStartRequest
		if err := decode(b, &r); err != nil {
			return nil, err
		}
		return s.StartAccount(ctx, r)
	}))
	mux.HandleFunc("POST "+api.PathAccountVerify, s.public(func(ctx context.Context, b []byte, _ *http.Request) (any, error) {
		var r api.AccountVerifyRequest
		if err := decode(b, &r); err != nil {
			return nil, err
		}
		return s.VerifyAccount(ctx, r)
	}))
	mux.HandleFunc("POST "+api.PathChallenge, s.public(func(ctx context.Context, b []byte, _ *http.Request) (any, error) {
		var r api.ChallengeRequest
		if err := decode(b, &r); err != nil {
			return nil, err
		}
		return s.Challenge(ctx, r)
	}))
	mux.HandleFunc("POST "+api.PathRegister, s.public(func(ctx context.Context, b []byte, _ *http.Request) (any, error) {
		var r api.RegisterRequest
		if err := decode(b, &r); err != nil {
			return nil, err
		}
		return s.Register(ctx, r)
	}))
	mux.HandleFunc("GET "+api.PathCA, s.public(func(context.Context, []byte, *http.Request) (any, error) {
		return &api.CAResponse{PublicKey: s.CAPublicKey(), ReceiptPublicKey: s.ReceiptPublicKey()}, nil
	}))
	mux.HandleFunc("POST "+api.PathDeposit, s.device(func(ctx context.Context, d *store.Device, b []byte, r *http.Request) (any, error) {
		var q api.DepositRequest
		if err := decode(b, &q); err != nil {
			return nil, err
		}
		if err := s.requireServerNonce(r, d, api.PurposeDeposit); err != nil {
			return nil, err
		}
		return s.Deposit(ctx, d, q.AmountPaise, r.Header.Get(api.HeaderIdempotency))
	}))
	mux.HandleFunc("GET "+api.PathWallet, s.device(func(ctx context.Context, d *store.Device, _ []byte, _ *http.Request) (any, error) {
		return s.Wallet(ctx, d)
	}))
	mux.HandleFunc("POST "+api.PathReserves, s.device(func(ctx context.Context, d *store.Device, b []byte, r *http.Request) (any, error) {
		var q api.ReserveRequest
		if err := decode(b, &q); err != nil {
			return nil, err
		}
		if err := s.requireServerNonce(r, d, api.PurposeReserve); err != nil {
			return nil, err
		}
		return s.CreateReserve(ctx, d, q, r.Header.Get(api.HeaderIdempotency))
	}))
	mux.HandleFunc("POST "+api.PathSync, s.device(func(ctx context.Context, d *store.Device, b []byte, r *http.Request) (any, error) {
		var q api.SyncRequest
		if err := decode(b, &q); err != nil {
			return nil, err
		}
		if r.URL.Query().Get("async") == "1" {
			j, err := s.SubmitSync(ctx, d, q)
			if err != nil {
				return nil, err
			}
			return withStatus{202, j}, nil
		}
		return &api.SyncResponse{Results: s.Sync(ctx, d, q.Records, "internet", q.RASP)}, nil
	}))
	mux.HandleFunc("GET "+api.PathSyncJobs+"{id}", s.device(func(_ context.Context, d *store.Device, _ []byte, r *http.Request) (any, error) {
		return s.SyncJobStatus(d, r.PathValue("id"))
	}))
	mux.HandleFunc("POST "+api.PathAuthNonce, s.device(func(ctx context.Context, d *store.Device, b []byte, _ *http.Request) (any, error) {
		var q api.AuthNonceRequest
		if err := decode(b, &q); err != nil {
			return nil, err
		}
		return s.IssueServerNonce(ctx, d, q)
	}))
	mux.HandleFunc("GET "+api.PathDirectory, s.device(func(ctx context.Context, _ *store.Device, _ []byte, _ *http.Request) (any, error) {
		return s.Directory(ctx)
	}))
	mux.HandleFunc("GET "+api.PathPaymentPrefix+"{device}/{counter}", s.device(func(ctx context.Context, d *store.Device, _ []byte, r *http.Request) (any, error) {
		dev, err := offline.ParseID(r.PathValue("device"))
		if err != nil {
			return nil, apiErr(400, "invalid_device", "%v", err)
		}
		ctr, err := strconv.ParseUint(r.PathValue("counter"), 10, 32)
		if err != nil {
			return nil, apiErr(400, "invalid_counter", "%v", err)
		}
		return s.Payment(ctx, d, dev, uint32(ctr))
	}))
	mux.HandleFunc("POST "+api.PathSMSInbound, s.handleSMS)
	return mux
}

// decode is the request checkpoint: strict JSON types (integers only where
// integers belong, and so on), no unknown or duplicate fields, then the
// request's value rules.
func decode(b []byte, v any) error {
	if err := validate.DecodeStrict(b, v); err != nil {
		var ve *validate.Error
		if errors.As(err, &ve) {
			return apiErr(400, "invalid_request", "%v", ve)
		}
		return apiErr(400, "invalid_request", "%v", err)
	}
	return nil
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func (s *Service) fail(w http.ResponseWriter, err error) {
	var e *Error
	if errors.As(err, &e) {
		writeJSON(w, e.Status, api.Error{Code: e.Code, Message: e.Message})
		return
	}
	s.log.Error("offline api", "err", err)
	writeJSON(w, 500, api.Error{Code: "internal_error", Message: "internal error"})
}

func readBody(r *http.Request) ([]byte, error) {
	b, err := io.ReadAll(io.LimitReader(r.Body, maxBody+1))
	if err != nil {
		return nil, apiErr(400, "bad_body", "%v", err)
	}
	if len(b) > maxBody {
		return nil, apiErr(413, "body_too_large", "request body above 1 MiB")
	}
	return b, nil
}

type withStatus struct {
	status int
	body   any
}

func respond(w http.ResponseWriter, out any) {
	if ws, ok := out.(withStatus); ok {
		writeJSON(w, ws.status, ws.body)
		return
	}
	writeJSON(w, 200, out)
}

func (s *Service) public(fn func(context.Context, []byte, *http.Request) (any, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if ip := clientIP(r); !s.guard.allowIP(ip, s.now()) {
			s.securityEvent(r.Context(), EventRateLimited, "ip:"+ip, r.URL.Path)
			s.fail(w, apiErr(429, "rate_limited", "too many requests; slow down"))
			return
		}
		b, err := readBody(r)
		if err != nil {
			s.fail(w, err)
			return
		}
		out, err := fn(r.Context(), b, r)
		if err != nil {
			s.fail(w, err)
			return
		}
		writeJSON(w, 200, out)
	}
}

// device authenticates a request signed by a registered device: timestamp
// within the allowed skew, signature by the device key over method, path,
// timestamp and body hash, and each signature usable once.
func (s *Service) device(fn func(context.Context, *store.Device, []byte, *http.Request) (any, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		b, err := readBody(r)
		if err != nil {
			s.fail(w, err)
			return
		}
		d, err := s.authenticate(r, b)
		if err != nil {
			s.fail(w, err)
			return
		}
		out, err := fn(context.WithValue(r.Context(), ctxKey{}, d), d, b, r)
		if err != nil {
			s.fail(w, err)
			return
		}
		respond(w, out)
	}
}

func (s *Service) authenticate(r *http.Request, body []byte) (*store.Device, error) {
	id, err := offline.ParseID(r.Header.Get(api.HeaderDevice))
	if err != nil {
		return nil, apiErr(401, "unauthenticated", "missing or bad %s", api.HeaderDevice)
	}
	ts, err := strconv.ParseInt(r.Header.Get(api.HeaderTimestamp), 10, 64)
	if err != nil {
		return nil, apiErr(401, "unauthenticated", "missing or bad %s", api.HeaderTimestamp)
	}
	now := s.now()
	if s.guard.isLocked("device:"+offline.FormatID(id), now) {
		return nil, apiErr(429, "device_locked", "too many failed authentications; try again later")
	}
	if d := now.Sub(time.Unix(ts, 0)); d > s.cfg.RequestSkew || d < -s.cfg.RequestSkew {
		s.authFailure(r.Context(), id, "clock skew")
		return nil, apiErr(401, "clock_skew", "request timestamp outside the allowed window")
	}
	sig, err := base64.StdEncoding.DecodeString(r.Header.Get(api.HeaderSignature))
	if err != nil {
		return nil, apiErr(401, "unauthenticated", "bad signature encoding")
	}
	nonce := r.Header.Get(api.HeaderNonce)
	if len(nonce) < 16 || len(nonce) > 64 {
		return nil, apiErr(401, "unauthenticated", "missing or bad %s", api.HeaderNonce)
	}
	d, err := s.st.GetDevice(r.Context(), id)
	if err != nil {
		return nil, apiErr(401, "unauthenticated", "unknown device")
	}
	msg := api.RequestMessage(r.Method, r.URL.RequestURI(), ts, nonce, body)
	if err := offline.VerifySignature(offline.Alg(d.Alg), d.PublicKey, msg, sig); err != nil {
		s.authFailure(r.Context(), id, "bad signature")
		s.securityEvent(r.Context(), EventAuthFailure, "device:"+offline.FormatID(id), "signature does not verify")
		return nil, apiErr(401, "unauthenticated", "signature does not verify")
	}
	if err := s.st.UseRequestNonce(r.Context(), sha(offline.FormatID(id)+":"+nonce), now.Add(2*s.cfg.RequestSkew)); err != nil {
		if errors.Is(err, store.ErrDuplicate) {
			s.authFailure(r.Context(), id, "replayed request")
			return nil, apiErr(401, "replayed", "request already used")
		}
		return nil, err
	}
	return d, nil
}

// handleSMS receives records an SMS aggregator delivered to the short code.
// The aggregator signs the body with the shared gateway secret.
func (s *Service) handleSMS(w http.ResponseWriter, r *http.Request) {
	b, err := readBody(r)
	if err != nil {
		s.fail(w, err)
		return
	}
	if len(s.cfg.GatewaySecret) == 0 {
		s.fail(w, apiErr(503, "sms_disabled", "SMS gateway not configured"))
		return
	}
	// The aggregator signs timestamp and body, and stale or future calls are
	// refused, so a captured webhook cannot be replayed later.
	ts, terr := strconv.ParseInt(r.Header.Get(api.HeaderGatewayTime), 10, 64)
	if d := s.now().Sub(time.Unix(ts, 0)); terr != nil || d > s.cfg.RequestSkew || d < -s.cfg.RequestSkew {
		s.fail(w, apiErr(401, "unauthenticated", "missing or stale gateway timestamp"))
		return
	}
	want := GatewaySignature(s.cfg.GatewaySecret, ts, b)
	if !hmac.Equal([]byte(want), []byte(strings.ToLower(r.Header.Get(api.HeaderGatewaySig)))) {
		s.securityEvent(r.Context(), EventAuthFailure, "sms-gateway:"+clientIP(r), "bad gateway signature")
		s.fail(w, apiErr(401, "unauthenticated", "bad gateway signature"))
		return
	}
	var in api.SMSInbound
	if err := decode(b, &in); err != nil {
		s.fail(w, err)
		return
	}
	if len(in.Payload) == 0 || len(in.Payload)%offline.RecordSize != 0 {
		s.fail(w, apiErr(400, "bad_payload", "payload must be whole 114-byte records"))
		return
	}
	var records [][]byte
	for p := in.Payload; len(p) > 0; p = p[offline.RecordSize:] {
		records = append(records, bytes.Clone(p[:offline.RecordSize]))
	}
	results := s.Sync(r.Context(), nil, records, "sms", nil)
	if from, err := offline.NormalizePhone(in.From); err == nil {
		ok := 0
		for _, res := range results {
			if res.Status == api.StatusAccepted || res.Status == api.StatusDuplicate {
				ok++
			}
		}
		_ = s.sms.Send(r.Context(), from, "PSTCO-Pay: "+strconv.Itoa(ok)+" of "+strconv.Itoa(len(results))+" payments received.")
	}
	writeJSON(w, 200, &api.SyncResponse{Results: results})
}

// GatewaySignature computes the header an SMS aggregator must send:
// hex HMAC-SHA256 over "<unix timestamp>\n<body>".
func GatewaySignature(secret []byte, unix int64, body []byte) string {
	m := hmac.New(sha256.New, secret)
	m.Write([]byte(strconv.FormatInt(unix, 10) + "\n"))
	m.Write(body)
	return hex.EncodeToString(m.Sum(nil))
}
