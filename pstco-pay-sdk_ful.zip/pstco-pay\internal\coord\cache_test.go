package coord

import (
	"bytes"
	"context"
	"testing"

	"github.com/alicebob/miniredis/v2"

	"pstcopay/internal/model"
)

func TestMerchantCacheIsEncryptedInRedis(t *testing.T) {
	ctx := context.Background()
	mr := miniredis.RunT(t)
	key := bytes.Repeat([]byte{7}, 32)
	r, err := Dial(ctx, "redis://"+mr.Addr(), Options{CacheKey: key})
	if err != nil {
		t.Fatal(err)
	}
	defer r.Close()
	r.Put(ctx, &model.Merchant{ID: "m1", Secret: "super-secret-hmac-key", Principal: "p"})
	raw, _ := mr.Get("pstco:merchant:m1")
	if bytes.Contains([]byte(raw), []byte("super-secret")) {
		t.Fatal("merchant secret stored in Redis in clear text")
	}
	if m, ok := r.Get(ctx, "m1"); !ok || m.Secret != "super-secret-hmac-key" {
		t.Fatal("encrypted cache entry not readable with the key")
	}
	other, _ := Dial(ctx, "redis://"+mr.Addr(), Options{CacheKey: bytes.Repeat([]byte{8}, 32)})
	defer other.Close()
	if _, ok := other.Get(ctx, "m1"); ok {
		t.Fatal("cache entry readable with a different key")
	}
}
