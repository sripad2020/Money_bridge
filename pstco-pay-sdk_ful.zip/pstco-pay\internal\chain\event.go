// Package chain implements the cryptographic payment execution graph:
// hash-linked, Ed25519-signed stage events with dependency and retry edges,
// plus Merkle anchoring for external audit.
package chain

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"slices"
	"strings"

	"pstcopay/internal/model"
)

// WorkflowVersion identifies the dependency rules events were written under.
const WorkflowVersion = "pstco-wf/1"

// GenesisHash is the previous_event_hash of the first event of every payment.
var GenesisHash = strings.Repeat("0", 64)

const sigDomain = "pstco-event-sig/1\x00"

// Event is one node in a payment's execution graph.
type Event struct {
	RowID             int64             `json:"row_id"`
	EventID           string            `json:"event_id"`
	PaymentID         string            `json:"payment_id"`
	Seq               int64             `json:"seq"`
	Stage             model.Stage       `json:"stage"`
	Attempt           int               `json:"attempt_number"`
	Status            model.EventStatus `json:"status"`
	PreviousEventHash string            `json:"previous_event_hash"`
	DependencyHashes  []string          `json:"dependency_hashes"`
	RetryOfEventHash  string            `json:"retry_of_event_hash,omitempty"`
	Payload           map[string]string `json:"payload"`
	PayloadHash       string            `json:"payload_hash"`
	IdempotencyKey    string            `json:"idempotency_key,omitempty"`
	NonceReference    string            `json:"nonce_reference,omitempty"`
	WorkflowVersion   string            `json:"workflow_version"`
	Signer            string            `json:"signer"`
	CreatedAt         int64             `json:"created_at"` // unix nanoseconds, UTC
	CurrentHash       string            `json:"current_hash"`
	Signature         string            `json:"signature"`
}

// canonicalEvent fixes field order and excludes the hash and signature.
// encoding/json emits struct fields in declaration order with no extra
// whitespace, which makes this a stable canonical JSON form.
type canonicalEvent struct {
	Domain            string            `json:"d"`
	EventID           string            `json:"event_id"`
	PaymentID         string            `json:"payment_id"`
	Seq               int64             `json:"seq"`
	Stage             model.Stage       `json:"stage"`
	Attempt           int               `json:"attempt_number"`
	Status            model.EventStatus `json:"status"`
	PreviousEventHash string            `json:"previous_event_hash"`
	DependencyHashes  []string          `json:"dependency_hashes"`
	RetryOfEventHash  string            `json:"retry_of_event_hash"`
	PayloadHash       string            `json:"payload_hash"`
	IdempotencyKey    string            `json:"idempotency_key"`
	NonceReference    string            `json:"nonce_reference"`
	WorkflowVersion   string            `json:"workflow_version"`
	Signer            string            `json:"signer"`
	CreatedAt         int64             `json:"created_at"`
}

// PayloadHash hashes a payload map. encoding/json sorts map keys, so the
// encoding is deterministic.
func PayloadHash(p map[string]string) string {
	if p == nil {
		p = map[string]string{}
	}
	b, _ := json.Marshal(p)
	sum := sha256.Sum256(b)
	return hex.EncodeToString(sum[:])
}

// CanonicalBytes returns the bytes covered by current_hash.
func (e *Event) CanonicalBytes() []byte {
	deps := slices.Clone(e.DependencyHashes)
	if deps == nil {
		deps = []string{}
	}
	slices.Sort(deps)
	b, _ := json.Marshal(canonicalEvent{
		Domain:            "pstco-event/1",
		EventID:           e.EventID,
		PaymentID:         e.PaymentID,
		Seq:               e.Seq,
		Stage:             e.Stage,
		Attempt:           e.Attempt,
		Status:            e.Status,
		PreviousEventHash: e.PreviousEventHash,
		DependencyHashes:  deps,
		RetryOfEventHash:  e.RetryOfEventHash,
		PayloadHash:       e.PayloadHash,
		IdempotencyKey:    e.IdempotencyKey,
		NonceReference:    e.NonceReference,
		WorkflowVersion:   e.WorkflowVersion,
		Signer:            e.Signer,
		CreatedAt:         e.CreatedAt,
	})
	return b
}

// ComputeHash returns SHA-256 over the canonical event bytes.
func (e *Event) ComputeHash() string {
	sum := sha256.Sum256(e.CanonicalBytes())
	return hex.EncodeToString(sum[:])
}

// Seal fills payload_hash, current_hash and signature.
func (e *Event) Seal(s Signer) error {
	if e.WorkflowVersion == "" {
		e.WorkflowVersion = WorkflowVersion
	}
	if e.Payload == nil {
		e.Payload = map[string]string{}
	}
	slices.Sort(e.DependencyHashes)
	e.Signer = s.ID()
	e.PayloadHash = PayloadHash(e.Payload)
	e.CurrentHash = e.ComputeHash()
	digest, err := hex.DecodeString(e.CurrentHash)
	if err != nil {
		return err
	}
	e.Signature = hex.EncodeToString(s.Sign(append([]byte(sigDomain), digest...)))
	return nil
}

// IntegrityError reports a broken hash, signature or dependency edge.
type IntegrityError struct {
	Code    model.FailureCode
	Seq     int64
	EventID string
	Msg     string
}

func (e *IntegrityError) Error() string {
	return fmt.Sprintf("integrity %s at seq %d (%s): %s", e.Code, e.Seq, e.EventID, e.Msg)
}

func integrity(code model.FailureCode, ev *Event, format string, args ...any) *IntegrityError {
	return &IntegrityError{Code: code, Seq: ev.Seq, EventID: ev.EventID, Msg: fmt.Sprintf(format, args...)}
}

// VerifySelf checks the event's own payload hash, current hash and signature.
func (e *Event) VerifySelf(v Verifier) error {
	if PayloadHash(e.Payload) != e.PayloadHash {
		return integrity(model.FailHashMismatch, e, "payload hash mismatch")
	}
	if e.ComputeHash() != e.CurrentHash {
		return integrity(model.FailHashMismatch, e, "current hash mismatch")
	}
	if !signerAllowed(e.Stage, e.Signer) {
		return integrity(model.FailSignatureMismatch, e, "signer %q not allowed for stage %s", e.Signer, e.Stage)
	}
	digest, err := hex.DecodeString(e.CurrentHash)
	if err != nil {
		return integrity(model.FailHashMismatch, e, "bad hash encoding")
	}
	sig, err := hex.DecodeString(e.Signature)
	if err != nil || !v.Verify(e.Signer, append([]byte(sigDomain), digest...), sig) {
		return integrity(model.FailSignatureMismatch, e, "signature does not verify for %q", e.Signer)
	}
	return nil
}
