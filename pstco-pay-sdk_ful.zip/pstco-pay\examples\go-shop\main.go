// Command go-shop is a complete example of integrating the PSTCO-Pay Go SDK
// into another application: a shop and a customer, each with its own wallet.
//
//  1. both register their device (phone OTP, device key, certificate)
//  2. the customer deposits money and loads an offline balance
//  3. the customer pays the shop OFFLINE by QR code (approval + PIN)
//  4. the shop verifies the payment OFFLINE
//  5. the shop syncs; the server returns a signed receipt; money settles
//
// Run it against a development server started with -dev-otp:
//
//	go run ./examples/go-shop -server https://localhost:8444 -ca certs/ca.pem
package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"time"

	"pstcopay/sdk/client"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/wallet"
)

const pin = "246810" // in a real app the user types this; never hard-code it

func main() {
	server := flag.String("server", "https://localhost:8444", "PSTCO-Pay offline API URL")
	caFile := flag.String("ca", "certs/ca.pem", "server CA certificate (empty for system roots)")
	shopPhone := flag.String("shop-phone", "9876511111", "shop phone number")
	custPhone := flag.String("customer-phone", "9876522222", "customer phone number")
	flag.Parse()

	var hc = client.NewHTTPClient(nil)
	if *caFile != "" {
		pem, err := os.ReadFile(*caFile)
		must(err)
		hc = client.NewHTTPClient(pem)
	}
	api := client.New(*server, hc)
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	work, _ := os.MkdirTemp("", "pstco-example-")
	defer os.RemoveAll(work)

	// ---- 1. Register both devices.
	shop := newWallet(filepath.Join(work, "shop"), api)
	customer := newWallet(filepath.Join(work, "customer"), api)
	register(ctx, shop, *shopPhone, "Example Shop", true)
	register(ctx, customer, *custPhone, "Example Customer", false)

	// ---- 2. Fund the customer. Every money step needs a fresh approval.
	a, err := customer.Approve(wallet.Intent{Op: wallet.OpDeposit, AmountPaise: 1000_00}, pin)
	must(err)
	_, err = customer.Deposit(ctx, 1000_00, a)
	must(err)
	a, err = customer.Approve(wallet.Intent{Op: wallet.OpReserve, AmountPaise: 500_00}, pin)
	must(err)
	_, err = customer.CreateReserve(ctx, 500_00, a)
	must(err)
	fmt.Println("customer loaded Rs 500.00 for offline use")

	// ---- 3. Pay offline. The customer scans the shop's card (here: we read it directly).
	card, err := shop.PayeeQR()
	must(err)
	payee, err := offline.DecodePayeeQR(card)
	must(err)
	amount := int64(149_50)
	payeeID, _ := offline.PayeeIDForPhone(payee.Phone)
	a, err = customer.Approve(wallet.Intent{Op: wallet.OpPay, AmountPaise: amount, PayeeID: payeeID}, pin)
	must(err)
	payment, err := customer.PayCard(card, amount, a)
	must(err)
	fmt.Printf("customer paid Rs %s offline (payment %d); show this QR: %.40s...\n",
		offline.FormatRupees(amount), payment.Counter, payment.QR)

	// ---- 4. The shop verifies it with no network.
	got, err := shop.Accept(payment.QR)
	must(err)
	fmt.Printf("shop verified Rs %s offline\n", offline.FormatRupees(got.AmountPaise))

	// ---- 5. Sync and wait for settlement.
	rep, err := shop.Sync(ctx)
	must(err)
	fmt.Printf("shop synced: %d accepted, %d bad receipts\n", rep.Accepted, rep.BadReceipts)
	_, received, _ := shop.History()
	fmt.Printf("server receipt held as proof: %d bytes\n", len(received[0].Receipt))
	for i := 0; i < 50; i++ {
		w, err := shop.OnlineWallet(ctx)
		must(err)
		if w.SettledInPaise >= amount {
			fmt.Printf("settled: shop balance Rs %s\n", offline.FormatRupees(w.AvailablePaise))
			return
		}
		time.Sleep(200 * time.Millisecond)
	}
	log.Fatal("payment did not settle in time")
}

func newWallet(dir string, api *client.Client) *wallet.Wallet {
	// nil KeyStore: no secure hardware, so the device registers with software
	// trust. On a phone, pass the platform KeyStore (see examples/android, examples/ios).
	el, err := wallet.CreateSealedElement(dir, pin, nil, wallet.ElementOptions{})
	must(err)
	w, err := wallet.New(wallet.Config{Dir: dir, Element: el, Client: api, Model: "example", AppVersion: "1.0"})
	must(err)
	must(w.Unlock(pin))
	return w
}

func register(ctx context.Context, w *wallet.Wallet, phone, name string, listed bool) {
	otp, err := w.StartAccount(ctx, phone, name, listed)
	must(err)
	if otp == "" {
		log.Fatal("server is not in development mode: read the OTP from the user instead")
	}
	must(w.VerifyAccount(ctx, phone, otp))
	must(w.SetDisplayName(name))
	reg, err := w.Register(ctx)
	must(err)
	fmt.Printf("%s registered: device %s, trust %s\n", name, reg.DeviceID, reg.Trust)
}

func must(err error) {
	if err != nil {
		log.Fatal(err)
	}
}
