package engine

import (
	"context"
	"time"

	"pstcopay/internal/model"
)

// RecoverAll runs CSDR or resumes every payment that is unfinished and not
// currently being processed. The server calls it at startup (crash recovery)
// and periodically.
func (e *Engine) RecoverAll(ctx context.Context) int {
	states := []model.State{
		model.StateCreated, model.StateValidated, model.StateRiskPending, model.StateAuthorized,
		model.StateCaptured, model.StateSoftFailure, model.StateUnknownOutcome, model.StateRecoveryPending,
		model.StateDependencyVerification, model.StateRetryOrResume, model.StateAuthorizing,
		model.StateCapturing, model.StateCompensating,
	}
	ps, err := e.store.ListPaymentsByState(ctx, 256, states...)
	if err != nil {
		e.log.Warn("recovery scan", "err", err)
		return 0
	}
	n := 0
	for _, p := range ps {
		if ctx.Err() != nil {
			break
		}
		unlock, ok := e.locks.TryLock(ctx, p.ID)
		if !ok {
			continue // being processed right now
		}
		func() {
			defer unlock()
			c, cancel := context.WithTimeout(ctx, e.cfg.RecoveryDeadline)
			defer cancel()
			fresh, err := e.store.GetPayment(c, p.ID)
			if err != nil || fresh.State.Terminal() {
				return
			}
			if _, err := e.drive(c, fresh); err != nil {
				e.log.Warn("recovery", "payment", p.ID, "err", err)
				return
			}
			n++
		}()
	}
	return n
}

// Start runs the background loops until ctx is cancelled: recovery,
// settlement, reconciliation and anchoring.
func (e *Engine) Start(ctx context.Context) {
	loop := func(name string, every time.Duration, fn func(context.Context)) {
		if every <= 0 {
			return
		}
		e.wg.Add(1)
		go func() {
			defer e.wg.Done()
			t := time.NewTicker(every)
			defer t.Stop()
			for {
				select {
				case <-ctx.Done():
					return
				case <-t.C:
					fn(ctx)
				}
			}
		}()
		e.log.Debug("background loop started", "loop", name, "every", every)
	}
	loop("recovery", e.cfg.RecoveryInterval, func(c context.Context) { e.RecoverAll(c) })
	loop("settlement", e.cfg.SettleInterval, func(c context.Context) {
		if _, err := e.SettleDue(c); err != nil {
			e.log.Warn("settlement loop", "err", err)
		}
	})
	loop("reconciliation", e.cfg.ReconInterval, func(c context.Context) {
		rep, err := e.Reconcile(c)
		if err != nil {
			e.log.Warn("reconciliation", "err", err)
			return
		}
		if len(rep.Discrepancies) > 0 {
			e.log.Warn("reconciliation discrepancies", "run", rep.RunID, "count", len(rep.Discrepancies))
		}
	})
	loop("anchor", e.cfg.AnchorInterval, func(c context.Context) {
		if _, err := e.AnchorOnce(c); err != nil {
			e.log.Warn("anchor", "err", err)
		}
	})
}

// Wait blocks until background loops exit.
func (e *Engine) Wait() { e.wg.Wait() }
