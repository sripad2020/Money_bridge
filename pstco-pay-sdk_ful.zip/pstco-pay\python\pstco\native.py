"""Optional binding to the C network library (native/pstconet) via ctypes.

Build it with scripts/build-native.ps1 (Windows) or ``make -C native/pstconet``
(Linux, macOS), or point PSTCO_NATIVE_LIB at the shared library. Without it
the same functions run in pure asyncio.
"""

from __future__ import annotations

import asyncio
import ctypes
import os
import sys
import time
from pathlib import Path

_lib = None


def _candidates():
    env = os.environ.get("PSTCO_NATIVE_LIB")
    if env:
        yield Path(env)
    name = {"win32": "pstconet.dll", "darwin": "libpstconet.dylib"}.get(sys.platform, "libpstconet.so")
    here = Path(__file__).resolve()
    yield here.parent / name
    yield here.parents[2] / "native" / "pstconet" / "build" / name


def load():
    """Load the C library once; returns None when it is not available."""
    global _lib
    if _lib is not None:
        return _lib or None
    for p in _candidates():
        if p.is_file():
            lib = ctypes.CDLL(str(p))
            lib.pstco_version.restype = ctypes.c_char_p
            lib.pstco_probe_many.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                             ctypes.POINTER(ctypes.c_int64), ctypes.POINTER(ctypes.c_int)]
            lib.pstco_probe_many.restype = ctypes.c_int
            _lib = lib
            return lib
    _lib = False
    return None


def available() -> bool:
    return load() is not None


def version() -> str:
    lib = load()
    return lib.pstco_version().decode() if lib else "pure asyncio"


def probe(host: str, port: int, count: int = 8, timeout_ms: int = 2000) -> list[float | None]:
    """Concurrent TCP handshakes; returns RTT in milliseconds or None per probe."""
    if type(port) is not int or type(count) is not int or not 1 <= count <= 64:
        raise ValueError("port and count must be int; count 1..64")
    lib = load()
    if lib is None:
        return asyncio.run(aprobe(host, port, count, timeout_ms))
    rtts = (ctypes.c_int64 * count)()
    errs = (ctypes.c_int * count)()
    rc = lib.pstco_probe_many(host.encode(), port, count, timeout_ms, rtts, errs)
    if rc < 0:
        raise OSError(f"pstconet error {rc}")
    return [rtts[i] / 1000.0 if errs[i] == 0 else None for i in range(count)]


async def aprobe(host: str, port: int, count: int = 8, timeout_ms: int = 2000) -> list[float | None]:
    """asyncio version: all handshakes in flight at once on the event loop.
    Uses the C library in a worker thread when available."""
    if load() is not None:
        return await asyncio.to_thread(probe, host, port, count, timeout_ms)

    async def one():
        t = time.perf_counter()
        try:
            _, w = await asyncio.wait_for(asyncio.open_connection(host, port), timeout_ms / 1000)
        except (OSError, asyncio.TimeoutError):
            return None
        rtt = (time.perf_counter() - t) * 1000
        w.close()
        return rtt
    return list(await asyncio.gather(*(one() for _ in range(count))))
