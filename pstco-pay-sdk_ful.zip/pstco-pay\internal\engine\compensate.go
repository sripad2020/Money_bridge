package engine

import (
	"context"
	"fmt"

	"pstcopay/internal/acquirer"
	"pstcopay/internal/chain"
	"pstcopay/internal/model"
	"pstcopay/internal/store"
)

// Compensation reverses external financial effects. A database rollback can
// never undo money that moved downstream, so each case issues the matching
// downstream operation:
//   - authorized, not captured: void the authorization
//   - captured, before or after settlement: refund the capture
// Each compensation is a stable idempotent operation, so retries are safe.

// continueCompensation advances a payment in COMPENSATING.
func (e *Engine) continueCompensation(ctx context.Context, p *model.Payment) error {
	events, err := e.store.ListEvents(ctx, p.ID)
	if err != nil {
		return err
	}
	attempts := 0
	for _, ev := range events {
		if (ev.Stage == model.StageVoid || ev.Stage == model.StageRefund) && ev.Status == model.EventPending {
			attempts++
		}
	}
	if attempts >= e.cfg.MaxCompensationAttempts {
		err := e.persist(ctx, func(tx *store.Tx) error {
			p.FailureReason = fmt.Sprintf("compensation failed %d times: %s", attempts, p.FailureReason)
			return e.move(ctx, tx, p, model.StateReconciliationRequired)
		})
		if err == nil {
			e.notify(p)
		}
		return err
	}
	if attempts > 0 {
		backoff := e.ctl.Backoff("compensate", attempts)
		if remaining(ctx) < backoff+e.ctl.Expected("compensate") {
			return nil
		}
		if err := sleep(ctx, backoff); err != nil {
			return nil
		}
	}

	switch {
	case p.CaptureID != "":
		capEv := latestSuccess(events, model.StageCapture)
		attempt, retryOf := nextAttempt(events, model.StageRefund)
		key := p.ID + ":refund"
		postSettlement := p.SettlementID != ""
		return e.runDownstream(ctx, p, dsOp{
			stage: model.StageRefund, op: acquirer.OpRefund, inProgress: model.StateCompensating,
			key: key, attempt: attempt, retryOf: retryOf, deps: hashes(capEv),
			signer: chain.SignerCompensator, keepFail: true,
			call: func(c context.Context) (*acquirer.Result, error) {
				return e.acq.Refund(c, key, p.CaptureID, p.AmountMinor)
			},
			onSuccess: func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
				p.RefundID = r.Ref
				if postSettlement {
					p.FailureReason = "refunded after settlement as a separate adjustment; " + p.FailureReason
				}
				return e.move(ctx, tx, p, model.StateCompensated)
			},
			onDecline: func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
				return e.move(ctx, tx, p, model.StateReconciliationRequired)
			},
		})
	case p.AuthID != "":
		authEv := latestSuccess(events, model.StageAuthorize)
		attempt, retryOf := nextAttempt(events, model.StageVoid)
		key := p.ID + ":void"
		return e.runDownstream(ctx, p, dsOp{
			stage: model.StageVoid, op: acquirer.OpVoid, inProgress: model.StateCompensating,
			key: key, attempt: attempt, retryOf: retryOf, deps: hashes(authEv),
			signer: chain.SignerCompensator, keepFail: true,
			call: func(c context.Context) (*acquirer.Result, error) {
				return e.acq.Void(c, key, p.AuthID)
			},
			onSuccess: func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
				return e.move(ctx, tx, p, model.StateCompensated)
			},
			onDecline: func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
				return e.move(ctx, tx, p, model.StateReconciliationRequired)
			},
		})
	}
	// Nothing moved downstream, so there is nothing to reverse.
	err = e.persist(ctx, func(tx *store.Tx) error { return e.move(ctx, tx, p, model.StateCompensated) })
	if err == nil {
		e.notify(p)
	}
	return err
}

// Refund is a merchant-initiated full refund. Before settlement it cancels the
// pending settlement instruction; after settlement it is a separate
// financial adjustment.
func (e *Engine) Refund(ctx context.Context, paymentID, merchantID, principal, reason string) (*model.Payment, error) {
	if _, ok := ctx.Deadline(); !ok {
		var cancel context.CancelFunc
		ctx, cancel = context.WithTimeout(ctx, e.cfg.RecoveryDeadline)
		defer cancel()
	}
	unlock, err := e.locks.Lock(ctx, paymentID)
	if err != nil {
		return nil, ErrBusy
	}
	defer unlock()
	p, err := e.GetPayment(ctx, paymentID)
	if err != nil {
		return nil, err
	}
	m, err := e.merchant(ctx, merchantID)
	if err != nil || p.MerchantID != merchantID || m.Principal != principal {
		return nil, ErrForbidden
	}
	switch p.State {
	case model.StateCompensated:
		return p, nil
	case model.StateCompensating:
	case model.StateSettled, model.StateSettlementPending, model.StateAuthorized:
		err := e.persist(ctx, func(tx *store.Tx) error {
			if p.State == model.StateSettlementPending {
				ob, err := tx.GetOutboxByPayment(ctx, p.ID)
				if err != nil {
					return err
				}
				ok, err := tx.UpdateOutbox(ctx, ob.ID, store.OutboxPending, store.OutboxCancelled,
					ob.Attempts, ob.NextAttemptAt, "cancelled by refund", e.now())
				if err != nil {
					return err
				}
				if !ok {
					return ErrBusy
				}
			}
			p.FailureReason = "merchant refund: " + reason
			return e.move(ctx, tx, p, model.StateCompensating)
		})
		if err != nil {
			return e.reload(ctx, p), err
		}
		e.notify(p)
	default:
		return p, ErrNotRefundable
	}
	return e.drive(ctx, p)
}
