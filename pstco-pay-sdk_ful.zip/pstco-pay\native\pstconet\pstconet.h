/*
 * pstconet: PSTCO-Pay native network operations in C.
 *
 *   - socket tuning: TCP_NODELAY, keepalive, buffer sizes, congestion
 *     control (Linux: TCP_CONGESTION, e.g. "bbr" or "cubic")
 *   - kernel TCP statistics: Linux TCP_INFO, Windows SIO_TCP_INFO
 *   - asynchronous TCP probing: many non-blocking connects in flight at
 *     once, multiplexed with select(), each handshake timed with a
 *     monotonic clock
 *
 * Used from Go through cgo (sdk/netprobe) and from Python through ctypes
 * (python/pstco/native.py). Builds with gcc, clang, MSVC or zig cc.
 */
#ifndef PSTCONET_H
#define PSTCONET_H

#include <stdint.h>

#ifdef _WIN32
#define PSTCO_API __declspec(dllexport)
#else
#define PSTCO_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* Error codes (negative); 0 means success. */
#define PSTCO_OK 0
#define PSTCO_EINVAL -1
#define PSTCO_EUNSUPPORTED -2
#define PSTCO_ESYS -3
#define PSTCO_ERESOLVE -4
#define PSTCO_ETIMEOUT -5
#define PSTCO_ECONNECT -6

#define PSTCO_MAX_PROBES 64

typedef struct {
    uint32_t rtt_us;        /* smoothed round-trip time */
    uint32_t min_rtt_us;    /* minimum RTT (0 when the OS does not report it) */
    uint32_t rttvar_us;     /* RTT variance (Linux) */
    uint32_t snd_cwnd;      /* congestion window, segments (Linux) or bytes (Windows) */
    uint32_t mss;           /* maximum segment size */
    uint32_t total_retrans; /* retransmitted segments (Linux) or bytes (Windows) */
    uint64_t bytes_in_flight;
} pstco_tcp_stats;

typedef struct {
    int nodelay;           /* 1 to disable Nagle */
    int keepalive_secs;    /* 0 leaves keepalive unchanged */
    int sndbuf;            /* 0 leaves the send buffer unchanged */
    int rcvbuf;            /* 0 leaves the receive buffer unchanged */
    const char *congestion; /* NULL or "" leaves it unchanged; Linux only */
} pstco_tuning;

/* Library version string. */
PSTCO_API const char *pstco_version(void);

/* Initialise sockets (WSAStartup on Windows). Safe to call repeatedly. */
PSTCO_API int pstco_init(void);

/* Apply tuning to a connected TCP socket (fd on POSIX, SOCKET on Windows). */
PSTCO_API int pstco_tune_socket(intptr_t fd, const pstco_tuning *t);

/* Read kernel TCP statistics for a connected socket. */
PSTCO_API int pstco_read_tcp_stats(intptr_t fd, pstco_tcp_stats *out);

/*
 * Probe host:port with `count` concurrent non-blocking TCP connects
 * (count <= PSTCO_MAX_PROBES). For probe i, rtt_us[i] receives the
 * handshake time and err[i] receives PSTCO_OK, PSTCO_ETIMEOUT or
 * PSTCO_ECONNECT. Returns the number of successful probes, or a negative
 * error code when nothing could be attempted.
 */
PSTCO_API int pstco_probe_many(const char *host, int port, int count, int timeout_ms,
                               int64_t *rtt_us, int *err);

#ifdef __cplusplus
}
#endif

#endif /* PSTCONET_H */
