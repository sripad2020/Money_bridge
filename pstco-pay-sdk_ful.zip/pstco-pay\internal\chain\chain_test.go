package chain

import (
	"errors"
	"testing"

	"pstcopay/internal/model"
)

func build(t *testing.T, k *KeyRing) []*Event {
	t.Helper()
	var evs []*Event
	add := func(stage model.Stage, status model.EventStatus, signer string, deps ...*Event) *Event {
		prev := GenesisHash
		if len(evs) > 0 {
			prev = evs[len(evs)-1].CurrentHash
		}
		ev := &Event{EventID: "e" + string(rune('a'+len(evs))), PaymentID: "pay_1", Seq: int64(len(evs) + 1),
			Stage: stage, Attempt: 1, Status: status, PreviousEventHash: prev,
			Payload: map[string]string{"k": "v"}, CreatedAt: int64(len(evs))}
		for _, d := range deps {
			ev.DependencyHashes = append(ev.DependencyHashes, d.CurrentHash)
		}
		if err := ev.Seal(k.Signer(signer)); err != nil {
			t.Fatal(err)
		}
		evs = append(evs, ev)
		return ev
	}
	c := add(model.StageCreate, model.EventSuccess, SignerOrchestrator)
	v := add(model.StageValidate, model.EventSuccess, SignerValidator, c)
	a := add(model.StageAuthenticate, model.EventSuccess, SignerAuthenticator, v)
	r := add(model.StageRisk, model.EventSuccess, SignerRisk, v)
	add(model.StageAuthorize, model.EventSuccess, SignerAuthorizer, a, r)
	return evs
}

func TestGraphVerifiesAndDetectsEachViolation(t *testing.T) {
	k := NewEphemeralKeyRing()
	if err := VerifyGraph(build(t, k), k); err != nil {
		t.Fatalf("valid graph rejected: %v", err)
	}
	cases := map[string]struct {
		mutate func(evs []*Event)
		code   model.FailureCode
	}{
		"payload edit":     {func(e []*Event) { e[1].Payload["k"] = "x" }, model.FailHashMismatch},
		"broken link":      {func(e []*Event) { e[2].PreviousEventHash = GenesisHash }, model.FailHashMismatch},
		"sequence gap":     {func(e []*Event) { e[3].Seq = 9 }, model.FailHashMismatch},
		"wrong signer key": {func(e []*Event) { _ = e[4].Seal(NewEphemeralKeyRing().Signer(SignerAuthorizer)) }, model.FailSignatureMismatch},
		"stage not allowed for signer": {func(e []*Event) {
			e[4].Signer = SignerRisk
			e[4].CurrentHash = e[4].ComputeHash()
		}, model.FailSignatureMismatch},
	}
	for name, tc := range cases {
		evs := build(t, k)
		tc.mutate(evs)
		var ie *IntegrityError
		if err := VerifyGraph(evs, k); !errors.As(err, &ie) || ie.Code != tc.code {
			t.Errorf("%s: got %v, want %s", name, err, tc.code)
		}
	}
	// Missing dependency: authorization re-sealed without the risk edge.
	evs := build(t, k)
	evs[4].DependencyHashes = evs[4].DependencyHashes[:1]
	_ = evs[4].Seal(k.Signer(SignerAuthorizer))
	var ie *IntegrityError
	if err := VerifyGraph(evs, k); !errors.As(err, &ie) || ie.Code != model.FailDependencyInvalid {
		t.Errorf("missing dependency: got %v", err)
	}
}

func TestMerkleRoot(t *testing.T) {
	h := []string{GenesisHash, "11" + GenesisHash[2:], "22" + GenesisHash[2:]}
	if MerkleRoot(h) != MerkleRoot(append([]string(nil), h...)) {
		t.Fatal("not deterministic")
	}
	if MerkleRoot(h) == MerkleRoot(h[:2]) || MerkleRoot(h) == MerkleRoot([]string{h[1], h[0], h[2]}) {
		t.Fatal("root does not commit to membership and order")
	}
}
