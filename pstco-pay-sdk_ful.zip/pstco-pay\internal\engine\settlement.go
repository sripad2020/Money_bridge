package engine

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"time"

	"pstcopay/internal/acquirer"
	"pstcopay/internal/chain"
	"pstcopay/internal/model"
	"pstcopay/internal/store"
)

// SettleDue processes every due settlement outbox item once. The outbox row
// was committed in the same transaction as the capture, so no captured
// payment can be lost between capture and settlement.
func (e *Engine) SettleDue(ctx context.Context) (int, error) {
	items, err := e.store.DueOutbox(ctx, e.now(), 128)
	if err != nil {
		return 0, err
	}
	done := 0
	for _, it := range items {
		if ctx.Err() != nil {
			break
		}
		ok, err := e.settleOne(ctx, it)
		if err != nil {
			e.log.Warn("settlement", "payment", it.PaymentID, "err", err)
			continue
		}
		if ok {
			done++
		}
	}
	return done, nil
}

func (e *Engine) settleOne(ctx context.Context, it *store.OutboxItem) (bool, error) {
	unlock, ok := e.locks.TryLock(ctx, it.PaymentID)
	if !ok {
		return false, nil
	}
	defer unlock()
	p, err := e.store.GetPayment(ctx, it.PaymentID)
	if err != nil {
		return false, err
	}
	switch p.State {
	case model.StateSettlementPending, model.StateSettlementProcessing:
	case model.StateSettled:
		_, err := e.store.UpdateOutbox(ctx, it.ID, "", store.OutboxPublished, it.Attempts, it.NextAttemptAt, "", e.now())
		return false, err
	default:
		_, err := e.store.UpdateOutbox(ctx, it.ID, "", store.OutboxCancelled, it.Attempts, it.NextAttemptAt,
			"payment in "+string(p.State), e.now())
		return false, err
	}

	key := p.ID + ":settle"
	// A payment left in SETTLEMENT_PROCESSING crashed or lost a response:
	// resolve the downstream status before submitting anything.
	if p.State == model.StateSettlementProcessing {
		if res, qerr := e.acq.Query(ctx, key); qerr == nil && res.Approved {
			return true, e.completeSettlement(ctx, p, it, res, true)
		}
	}

	events, err := e.store.ListEvents(ctx, p.ID)
	if err != nil {
		return false, err
	}
	capEv := latestSuccess(events, model.StageCapture)
	attempt, retryOf := nextAttempt(events, model.StageSettle)
	scope := fmt.Sprintf("%s:%s:%d", p.ID, model.StageSettle, attempt)
	nonceValue, nonceRef, err := e.nonces.Issue(ctx, scope)
	if err != nil {
		return false, err
	}

	var pending *chain.Event
	err = e.persist(ctx, func(tx *store.Tx) error {
		if p.State != model.StateSettlementProcessing {
			if err := e.move(ctx, tx, p, model.StateSettlementProcessing); err != nil {
				return err
			}
		}
		if _, err := tx.UpdateOutbox(ctx, it.ID, "", store.OutboxProcessing, it.Attempts+1, it.NextAttemptAt, it.LastError, e.now()); err != nil {
			return err
		}
		if err := tx.PutIdempotency(ctx, &store.IdemRecord{OpKey: key, PaymentID: p.ID,
			Operation: string(acquirer.OpSettle), Status: store.IdemStarted}, e.now()); err != nil {
			return err
		}
		pending, err = e.appendEvent(ctx, tx, p.ID, evSpec{
			stage: model.StageSettle, attempt: attempt, status: model.EventPending, deps: hashes(capEv),
			retryOf: retryOf, idemKey: key, nonceRef: nonceRef, signer: chain.SignerSettlement,
			payload: map[string]string{"operation": "settle", "outbox_id": strconv.FormatInt(it.ID, 10)},
		})
		return err
	})
	if err != nil {
		return false, err
	}
	it.Attempts++
	e.notify(p)

	var res *acquirer.Result
	var callErr error
	if err := e.nonces.Consume(ctx, nonceValue, scope); err != nil {
		callErr = err
	} else {
		cctx, cancel := context.WithTimeout(ctx, max(e.ctl.StageTimeout("settle", time.Time{}), time.Second))
		start := time.Now()
		res, callErr = e.acq.Settle(cctx, key, p.CaptureID)
		cancel()
		e.ctl.Observe("settle", time.Since(start), callErr != nil)
	}
	if errors.Is(callErr, acquirer.ErrTimeout) {
		if q, qerr := e.acq.Query(ctx, key); qerr == nil && q.Approved {
			res, callErr = q, nil
		}
	}
	if callErr == nil {
		return true, e.completeSettlementAfter(ctx, p, it, res, pending)
	}

	_, code := classify(callErr)
	exhausted := it.Attempts >= e.cfg.MaxSettleAttempts
	err = e.persist(ctx, func(tx *store.Tx) error {
		if _, err := e.appendEvent(ctx, tx, p.ID, evSpec{
			stage: model.StageSettle, attempt: attempt, status: model.EventSoftFail,
			deps: append(hashes(capEv), pending.CurrentHash), retryOf: retryOf, idemKey: key,
			nonceRef: nonceRef, signer: chain.SignerSettlement,
			payload: map[string]string{"failure_code": string(code), "reason": callErr.Error()},
		}); err != nil {
			return err
		}
		status := store.IdemFailedNoEffect
		if code == model.FailResponseTimeout {
			status = store.IdemUnknown
		}
		if err := tx.PutIdempotency(ctx, &store.IdemRecord{OpKey: key, PaymentID: p.ID,
			Operation: string(acquirer.OpSettle), Status: status}, e.now()); err != nil {
			return err
		}
		if exhausted {
			if _, err := tx.UpdateOutbox(ctx, it.ID, "", store.OutboxFailed, it.Attempts, it.NextAttemptAt, callErr.Error(), e.now()); err != nil {
				return err
			}
			p.FailureCode, p.FailureReason = model.FailRetriesExhausted, "settlement: "+callErr.Error()
			return e.move(ctx, tx, p, model.StateReconciliationRequired)
		}
		next := e.now().Add(e.ctl.Backoff("settle", it.Attempts))
		if _, err := tx.UpdateOutbox(ctx, it.ID, "", store.OutboxPending, it.Attempts, next, callErr.Error(), e.now()); err != nil {
			return err
		}
		return e.move(ctx, tx, p, model.StateSettlementPending)
	})
	e.metrics.Settlement("retry")
	if err == nil {
		e.notify(p)
	}
	return false, err
}

func (e *Engine) completeSettlementAfter(ctx context.Context, p *model.Payment, it *store.OutboxItem,
	res *acquirer.Result, pending *chain.Event) error {
	return e.finishSettlement(ctx, p, it, res, pending, false)
}

func (e *Engine) completeSettlement(ctx context.Context, p *model.Payment, it *store.OutboxItem,
	res *acquirer.Result, reconciled bool) error {
	return e.finishSettlement(ctx, p, it, res, nil, reconciled)
}

func (e *Engine) finishSettlement(ctx context.Context, p *model.Payment, it *store.OutboxItem,
	res *acquirer.Result, pending *chain.Event, reconciled bool) error {
	events, err := e.store.ListEvents(ctx, p.ID)
	if err != nil {
		return err
	}
	capEv := latestSuccess(events, model.StageCapture)
	attempt, retryOf := nextAttempt(events, model.StageSettle)
	if pending != nil {
		attempt, retryOf = pending.Attempt, pending.RetryOfEventHash
	} else if attempt > 1 {
		attempt-- // the reconciled result belongs to the outstanding attempt
	}
	key := p.ID + ":settle"
	err = e.persist(ctx, func(tx *store.Tx) error {
		payload := map[string]string{"settlement_id": res.Ref}
		deps := hashes(capEv)
		if pending != nil {
			deps = append(deps, pending.CurrentHash)
		}
		if reconciled {
			payload["reconciled"] = "true"
		}
		if _, err := e.appendEvent(ctx, tx, p.ID, evSpec{
			stage: model.StageSettle, attempt: attempt, status: model.EventSuccess, deps: deps,
			retryOf: retryOf, idemKey: key, signer: chain.SignerSettlement, payload: payload,
		}); err != nil {
			return err
		}
		if err := tx.PutIdempotency(ctx, &store.IdemRecord{OpKey: key, PaymentID: p.ID,
			Operation: string(acquirer.OpSettle), Status: store.IdemCompleted, DownstreamRef: res.Ref}, e.now()); err != nil {
			return err
		}
		if err := tx.InsertSettlement(ctx, &store.SettlementRecord{PaymentID: p.ID, SettlementID: res.Ref,
			CaptureID: p.CaptureID, AmountMinor: res.AmountMinor, Currency: res.Currency, SettledAt: res.At}); err != nil &&
			!errors.Is(err, store.ErrDuplicate) {
			return err
		}
		if _, err := tx.UpdateOutbox(ctx, it.ID, "", store.OutboxPublished, it.Attempts, it.NextAttemptAt, "", e.now()); err != nil {
			return err
		}
		p.SettlementID, p.SettledAt = res.Ref, res.At.UTC()
		return e.move(ctx, tx, p, model.StateSettled)
	})
	if err == nil {
		e.metrics.Settlement("settled")
		e.notify(p)
	}
	return err
}
