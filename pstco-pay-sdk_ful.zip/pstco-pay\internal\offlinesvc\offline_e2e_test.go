package offlinesvc_test

import (
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"pstcopay/internal/bank"
	"pstcopay/internal/chain"
	"pstcopay/internal/offlinesvc"
	"pstcopay/internal/store"
	"pstcopay/sdk/attest"
	"pstcopay/sdk/client"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/offline/api"
	"pstcopay/sdk/rasp"
	"pstcopay/sdk/wallet"
	"pstcopay/sdk/wallet/emulator"
)

const pin = "123456"

var appID = "TEAMID1234.com.example.pstco"

type capSMS struct {
	mu  sync.Mutex
	msg []string
}

func (c *capSMS) Send(_ context.Context, to, text string) error {
	c.mu.Lock()
	c.msg = append(c.msg, to+" "+text)
	c.mu.Unlock()
	return nil
}

func (c *capSMS) find(sub string) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	for _, m := range c.msg {
		if strings.Contains(m, sub) {
			return true
		}
	}
	return false
}

type env struct {
	t                       *testing.T
	svc                     *offlinesvc.Service
	st                      *store.Store
	bank                    *bank.Bank
	sms                     *capSMS
	srv                     *httptest.Server
	android, apple, simRoot *emulator.Root
	gateway                 []byte
	now                     time.Time
	mu                      sync.Mutex
}

func newEnv(t *testing.T) *env {
	t.Helper()
	st, err := store.Open(filepath.Join(t.TempDir(), "pstco.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { st.Close() })
	e := &env{t: t, st: st, bank: bank.New(), sms: &capSMS{}, gateway: []byte("gateway-secret"), now: time.Now()}
	e.android, _ = emulator.NewRoot("Test Android Attestation Root")
	e.apple, _ = emulator.NewRoot("Test Apple App Attest Root")
	e.simRoot, _ = emulator.NewRoot("Test SIM CA")
	reg := attest.NewRegistry(&attest.Android{Roots: e.android.Pool()},
		&attest.Apple{Roots: e.apple.Pool(), AppIDs: []string{appID}},
		&attest.SIM{Roots: e.simRoot.Pool()})
	e.svc = offlinesvc.New(offlinesvc.Config{Attest: reg, DevOTP: true, GatewaySecret: e.gateway},
		offlinesvc.Deps{Store: st, Keys: chain.NewEphemeralKeyRing(), Bank: e.bank, SMS: e.sms,
			Logger: slog.New(slog.NewTextHandler(io.Discard, nil))})
	e.svc.SetClock(e.clock)
	e.srv = httptest.NewServer(e.svc.Handler())
	t.Cleanup(e.srv.Close)
	return e
}

func (e *env) clock() time.Time {
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.now
}

func (e *env) advance(d time.Duration) {
	e.mu.Lock()
	e.now = e.now.Add(d)
	e.mu.Unlock()
}

func (e *env) client() *client.Client {
	c := client.New(e.srv.URL, e.srv.Client())
	c.SetClock(e.clock)
	return c
}

func softElement(t *testing.T, dir string) wallet.Element {
	el, err := wallet.CreateSealedElement(dir, pin, nil, wallet.ElementOptions{KDF: wallet.TestKDF})
	if err != nil {
		t.Fatal(err)
	}
	return el
}

func hwElement(t *testing.T, dir string, ks wallet.KeyStore) wallet.Element {
	el, err := wallet.CreateSealedElement(dir, pin, ks, wallet.ElementOptions{KDF: wallet.TestKDF})
	if err != nil {
		t.Fatal(err)
	}
	return el
}

func (e *env) openWallet(dir string, el wallet.Element) *wallet.Wallet {
	e.t.Helper()
	w, err := wallet.New(wallet.Config{Dir: dir, Element: el, Client: e.client(), Guard: rasp.Static{},
		KDF: wallet.TestKDF, Now: e.clock, ServerShortCode: "+919000000000"})
	if err != nil {
		e.t.Fatal(err)
	}
	if err := w.Unlock(pin); err != nil {
		e.t.Fatal(err)
	}
	return w
}

// onboard runs the full registration flow and returns the wallet and response.
func (e *env) onboard(phone, name string, listed bool, el wallet.Element, dir string) (*wallet.Wallet, *api.RegisterResponse) {
	e.t.Helper()
	ctx := context.Background()
	w := e.openWallet(dir, el)
	otp, err := w.StartAccount(ctx, phone, name, listed)
	if err != nil {
		e.t.Fatal(err)
	}
	if err := w.VerifyAccount(ctx, phone, otp); err != nil {
		e.t.Fatal(err)
	}
	_ = w.SetDisplayName(name)
	resp, err := w.Register(ctx)
	if err != nil {
		e.t.Fatalf("register %s: %v", name, err)
	}
	return w, resp
}

func (e *env) fund(w *wallet.Wallet, deposit, reserve int64) {
	e.t.Helper()
	ctx := context.Background()
	if _, err := w.Deposit(ctx, deposit, approveOp(e.t, w, wallet.OpDeposit, deposit)); err != nil {
		e.t.Fatal(err)
	}
	if _, err := w.CreateReserve(ctx, reserve, approveOp(e.t, w, wallet.OpReserve, reserve)); err != nil {
		e.t.Fatalf("reserve: %v", err)
	}
}

func accountOf(t *testing.T, e *env, phone string) *store.Account {
	p, _ := offline.NormalizePhone(phone)
	a, err := e.st.GetAccountByPhone(context.Background(), p)
	if err != nil {
		t.Fatal(err)
	}
	return a
}

// ------------------------------------------------------------------ tests

func TestOfflinePaymentEndToEnd(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	ks, _ := emulator.NewAndroidKeyStore(e.android, attest.AndroidStrongBox)
	payerDir, shopDir := t.TempDir(), t.TempDir()
	payer, preg := e.onboard("9876500001", "Asha", false, hwElement(t, payerDir, ks), payerDir)
	shop, _ := e.onboard("9876500002", "Lakshmi Stores", true, softElement(t, shopDir), shopDir)
	if preg.Trust != "hardware-key" {
		t.Fatalf("StrongBox payer trust = %s (%s)", preg.Trust, preg.TrustNote)
	}
	e.fund(payer, 1000_00, 500_00)
	if _, err := shop.Sync(ctx); err != nil { // shop picks up the directory
		t.Fatal(err)
	}

	// Payer looks up the shop offline and pays by QR, then by SMS.
	q, err := payer.QuotePhone("98765 00002")
	if err != nil || !q.Listed || q.Name != "Lakshmi Stores" {
		t.Fatalf("quote: %+v %v", q, err)
	}
	p1, err := payer.Pay(q, 123_45, wallet.DeliverQR, approvePay(t, payer, q.PayeeID, 123_45))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := shop.Accept(p1.QR); err != nil {
		t.Fatalf("shop rejected a valid payment offline: %v", err)
	}
	if _, err := shop.Accept(p1.QR); err == nil {
		t.Fatal("shop accepted the same payment twice")
	}
	p2, err := payer.Pay(q, 50_00, wallet.DeliverSMS, approvePay(t, payer, q.PayeeID, 50_00))
	if err != nil {
		t.Fatal(err)
	}
	pending := payer.PendingSMS()
	if len(pending) != 1 || pending[0].To != "+919876500002" {
		t.Fatalf("SMS queue: %+v", pending)
	}
	if _, err := shop.AcceptBytes(pending[0].Payload); err != nil { // the SMS arrives
		t.Fatal(err)
	}
	_ = payer.MarkSMSSent(pending[0].ID, true)
	if b, _ := payer.Balance(); b.OfflinePaise != 500_00-173_45 || b.UnsyncedSent != 2 {
		t.Fatalf("payer balance after paying offline: %+v", b)
	}

	// Shop syncs first; the payer's later sync finds duplicates.
	rep, err := shop.Sync(ctx)
	if err != nil || rep.Accepted != 2 {
		t.Fatalf("shop sync: %+v %v", rep, err)
	}
	rep, err = payer.Sync(ctx)
	if err != nil || rep.Duplicate != 2 {
		t.Fatalf("payer sync: %+v %v", rep, err)
	}
	if n := e.svc.SettleDue(ctx); n != 2 {
		t.Fatalf("settled %d", n)
	}
	payerAcct, shopAcct := accountOf(t, e, "9876500001"), accountOf(t, e, "9876500002")
	if avail, held := e.bank.Balance(ctx, payerAcct.ID); avail != 500_00 || held != 500_00-173_45 {
		t.Fatalf("payer bank: available %d held %d", avail, held)
	}
	if avail, _ := e.bank.Balance(ctx, shopAcct.ID); avail != 173_45 {
		t.Fatalf("shop bank: %d", avail)
	}
	if !e.sms.find("received Rs 123.45") || !e.sms.find("is settled") {
		t.Fatal("settlement confirmations not sent")
	}
	dev, _ := offline.ParseID(preg.DeviceID)
	if err := e.svc.VerifyPaymentGraph(ctx, dev, p2.Counter); err != nil {
		t.Fatalf("server event chain: %v", err)
	}
	pay, err := e.client().WithDevice(dev, payerElement(t, payer)).Payment(ctx, dev, p1.Counter)
	if err != nil || pay.Status != "SETTLED" || !pay.Verified || len(pay.Events) != 3 {
		t.Fatalf("payment view: %+v %v", pay, err)
	}
	if d, err := e.svc.Reconcile(ctx); err != nil || len(d) != 0 {
		t.Fatalf("reconciliation: %v %v", d, err)
	}
}

// payerElement returns the wallet's element as an API request signer.
func payerElement(t *testing.T, w *wallet.Wallet) client.Signer {
	t.Helper()
	return w.Element()
}

func itoa(v int64) string { return strconv.FormatInt(v, 10) }

func b64(b []byte) string { return base64.StdEncoding.EncodeToString(b) }

func TestRegistrationCapturesTrustWithOrWithoutHardware(t *testing.T) {
	e := newEnv(t)
	strong, _ := emulator.NewAndroidKeyStore(e.android, attest.AndroidStrongBox)
	tee, _ := emulator.NewAndroidKeyStore(e.android, attest.AndroidTEE)
	apple, _ := emulator.NewAppleKeyStore(e.apple, appID)
	sim, _ := emulator.NewSIMApplet(e.simRoot, pin)
	cases := []struct {
		name  string
		el    func(dir string) wallet.Element
		trust string
		kind  string
	}{
		{"no secure hardware", func(d string) wallet.Element { return softElement(t, d) }, "software", "software"},
		{"android strongbox", func(d string) wallet.Element { return hwElement(t, d, strong) }, "hardware-key", "android-strongbox"},
		{"android tee", func(d string) wallet.Element { return hwElement(t, d, tee) }, "hardware-key", "android-tee"},
		{"ios secure enclave", func(d string) wallet.Element { return hwElement(t, d, apple) }, "hardware-key", "ios-secure-enclave"},
		{"sim applet", func(string) wallet.Element { return sim }, "secure-applet", "sim-applet"},
		{"hardware claimed, no attestation", func(d string) wallet.Element { return hwElement(t, d, noAttest{strong2(t, e)}) }, "software", ""},
	}
	for i, c := range cases {
		dir := t.TempDir()
		_, resp := e.onboard("98765100"+string(rune('0'+i/10))+string(rune('0'+i%10)), c.name, false, c.el(dir), dir)
		if resp.Trust != c.trust {
			t.Errorf("%s: trust %s, want %s (%s)", c.name, resp.Trust, c.trust, resp.TrustNote)
		}
		dev, _ := offline.ParseID(resp.DeviceID)
		d, _ := e.st.GetDevice(context.Background(), dev)
		if c.kind != "" && d.ElementKind != c.kind {
			t.Errorf("%s: kind %s, want %s", c.name, d.ElementKind, c.kind)
		}
		want := offlinesvc.DefaultPolicy().Software
		if c.trust != "software" {
			want = offlinesvc.DefaultPolicy().HardwareKey
		}
		if resp.Limits.PerPaymentPaise != want.PerPaymentPaise {
			t.Errorf("%s: limits %+v", c.name, resp.Limits)
		}
		if c.name == "hardware claimed, no attestation" && !strings.Contains(resp.TrustNote, "sent no attestation") {
			t.Errorf("downgrade not explained: %q", resp.TrustNote)
		}
	}
}

func strong2(t *testing.T, e *env) *emulator.AndroidKeyStore {
	ks, err := emulator.NewAndroidKeyStore(e.android, attest.AndroidStrongBox)
	if err != nil {
		t.Fatal(err)
	}
	return ks
}

// noAttest is a hardware key store that sends no attestation.
type noAttest struct{ *emulator.AndroidKeyStore }

func (noAttest) Attest([]byte) (api.Attestation, error) { return api.Attestation{Format: "none"}, nil }

// badChallenge attests a different challenge (a replayed attestation).
type badChallenge struct{ *emulator.AndroidKeyStore }

func (b badChallenge) Attest([]byte) (api.Attestation, error) {
	return b.AndroidKeyStore.Attest([]byte("an old challenge"))
}

func TestInvalidAttestationIsRejectedNotDowngraded(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	rogueRoot, _ := emulator.NewRoot("Not trusted")
	rogue, _ := emulator.NewAndroidKeyStore(rogueRoot, attest.AndroidStrongBox)
	for name, ks := range map[string]wallet.KeyStore{"stale challenge": badChallenge{strong2(t, e)}, "untrusted root": rogue} {
		dir := t.TempDir()
		w := e.openWallet(dir, hwElement(t, dir, ks))
		phone := "98765200" + map[string]string{"stale challenge": "01", "untrusted root": "02"}[name]
		otp, _ := w.StartAccount(ctx, phone, name, false)
		_ = w.VerifyAccount(ctx, phone, otp)
		if _, err := w.Register(ctx); !client.IsCode(err, "attestation_invalid") {
			t.Errorf("%s: want attestation_invalid, got %v", name, err)
		}
	}
}

func TestSoftwareLimitsAreEnforcedOnDeviceAndServer(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	dir := t.TempDir()
	w, _ := e.onboard("9876530001", "Ravi", false, softElement(t, dir), dir)
	if _, err := w.Deposit(ctx, 2000_00, approveOp(t, w, wallet.OpDeposit, 2000_00)); err != nil {
		t.Fatal(err)
	}
	if _, err := w.CreateReserve(ctx, 1000_00, approveOp(t, w, wallet.OpReserve, 1000_00)); !client.IsCode(err, "over_limit") {
		t.Fatalf("software reserve above ₹500: %v", err)
	}
	if _, err := w.CreateReserve(ctx, 500_00, approveOp(t, w, wallet.OpReserve, 500_00)); err != nil {
		t.Fatal(err)
	}
	if _, err := w.PayPhone("9876530002", 300_00, wallet.DeliverQR, approvePhone(t, w, "9876530002", 300_00)); !errors.Is(err, wallet.ErrOverLimit) {
		t.Fatalf("software payment above ₹200: %v", err)
	}
	if _, err := w.PayPhone("9876530002", 200_00, wallet.DeliverQR, approvePhone(t, w, "9876530002", 200_00)); err != nil {
		t.Fatal(err)
	}
}

func TestRollbackDoubleSpendIsCaughtAndFreezesDevice(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	dir := t.TempDir()
	w, reg := e.onboard("9876540001", "Mallory", false, softElement(t, dir), dir)
	shopADir, shopBDir := t.TempDir(), t.TempDir()
	shopA, _ := e.onboard("9876540002", "Shop A", true, softElement(t, shopADir), shopADir)
	shopB, _ := e.onboard("9876540003", "Shop B", true, softElement(t, shopBDir), shopBDir)
	e.fund(w, 500_00, 200_00)

	backup := t.TempDir()
	copyDir(t, dir, backup)
	pA, err := w.PayPhone("9876540002", 150_00, wallet.DeliverQR, approvePhone(t, w, "9876540002", 150_00))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := shopA.Accept(pA.QR); err != nil {
		t.Fatal(err)
	}
	w.Lock()

	// The attacker restores the old wallet files and spends the same money again.
	copyDir(t, backup, dir)
	el, err := wallet.OpenSealedElement(dir, nil, wallet.ElementOptions{KDF: wallet.TestKDF})
	if err != nil {
		t.Fatal(err)
	}
	w2 := e.openWallet(dir, el)
	pB, err := w2.PayPhone("9876540003", 150_00, wallet.DeliverQR, approvePhone(t, w2, "9876540003", 150_00))
	if err != nil {
		t.Fatal(err)
	}
	if pB.Counter != pA.Counter {
		t.Fatalf("rollback did not reuse the counter: %d vs %d", pB.Counter, pA.Counter)
	}
	if _, err := shopB.Accept(pB.QR); err != nil { // shop B cannot tell offline
		t.Fatal(err)
	}
	if r, err := shopA.Sync(ctx); err != nil || r.Accepted != 1 {
		t.Fatalf("shop A sync: %+v %v", r, err)
	}
	r, err := shopB.Sync(ctx)
	if err != nil || r.Rejected != 1 || r.Results[0].Reason != offlinesvc.ConflictDoubleSpend {
		t.Fatalf("shop B sync: %+v %v", r, err)
	}
	dev, _ := offline.ParseID(reg.DeviceID)
	d, _ := e.st.GetDevice(ctx, dev)
	if d.Status != store.DeviceFrozen {
		t.Fatalf("device status %s", d.Status)
	}
	if _, err := w2.Deposit(ctx, 100, approveOp(t, w2, wallet.OpDeposit, 100)); !client.IsCode(err, "device_frozen") {
		t.Fatalf("frozen device deposit: %v", err)
	}
	e.svc.SettleDue(ctx)
	shopAAcct, shopBAcct := accountOf(t, e, "9876540002"), accountOf(t, e, "9876540003")
	a, _ := e.bank.Balance(ctx, shopAAcct.ID)
	b, _ := e.bank.Balance(ctx, shopBAcct.ID)
	if a != 150_00 || b != 0 {
		t.Fatalf("shop A %d, shop B %d: the loss must not exceed the reserve", a, b)
	}
}

func copyDir(t *testing.T, from, to string) {
	t.Helper()
	ents, _ := os.ReadDir(from)
	for _, en := range ents {
		if en.IsDir() {
			continue
		}
		b, err := os.ReadFile(filepath.Join(from, en.Name()))
		if err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(to, en.Name()), b, 0o600); err != nil {
			t.Fatal(err)
		}
	}
}

func TestTamperedPaymentRejectedOfflineAndOnline(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	dir, sdir := t.TempDir(), t.TempDir()
	w, _ := e.onboard("9876550001", "Payer", false, softElement(t, dir), dir)
	shop, _ := e.onboard("9876550002", "Shop", true, softElement(t, sdir), sdir)
	e.fund(w, 500_00, 300_00)
	p, _ := w.PayPhone("9876550002", 10_00, wallet.DeliverQR, approvePhone(t, w, "9876550002", 10_00))
	rec, cert, _ := offline.DecodePaymentQR(p.QR)
	bad := bytes.Clone(rec)
	bad[17] = 0xFF // raise the amount
	if _, err := shop.Accept(offline.EncodePaymentQR(bad, cert)); err == nil {
		t.Fatal("shop accepted a tampered amount")
	}
	res := e.svc.Sync(ctx, nil, [][]byte{bad}, "internet", nil)
	if res[0].Status != api.StatusRejected || res[0].Reason != "bad_signature" {
		t.Fatalf("server: %+v", res[0])
	}
}

func TestSMSGatewaySync(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	dir, sdir := t.TempDir(), t.TempDir()
	w, _ := e.onboard("9876560001", "Payer", false, softElement(t, dir), dir)
	_, _ = e.onboard("9876560002", "Shop", true, softElement(t, sdir), sdir)
	e.fund(w, 500_00, 300_00)
	if _, err := w.PayPhone("9876560002", 25_00, wallet.DeliverQR, approvePhone(t, w, "9876560002", 25_00)); err != nil {
		t.Fatal(err)
	}
	n, err := w.QueueServerSMS()
	if err != nil || n != 1 {
		t.Fatalf("queue server SMS: %d %v", n, err)
	}
	msg := w.PendingSMS()[0]
	if len(msg.Payload) != offline.RecordSize || msg.To != "+919000000000" {
		t.Fatalf("server SMS %d bytes to %s", len(msg.Payload), msg.To)
	}
	post := func(secret []byte) (*http.Response, api.SyncResponse) {
		body, _ := json.Marshal(api.SMSInbound{From: "+919876560001", Payload: msg.Payload})
		req, _ := http.NewRequest(http.MethodPost, e.srv.URL+api.PathSMSInbound, bytes.NewReader(body))
		ts := e.clock().Unix()
		req.Header.Set(api.HeaderGatewayTime, strconv.FormatInt(ts, 10))
		req.Header.Set(api.HeaderGatewaySig, offlinesvc.GatewaySignature(secret, ts, body))
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		var out api.SyncResponse
		_ = json.NewDecoder(resp.Body).Decode(&out)
		return resp, out
	}
	if resp, _ := post([]byte("wrong")); resp.StatusCode != 401 {
		t.Fatalf("forged gateway call: %d", resp.StatusCode)
	}
	if resp, out := post(e.gateway); resp.StatusCode != 200 || out.Results[0].Status != api.StatusAccepted {
		t.Fatalf("gateway: %d %+v", resp.StatusCode, out)
	}
	if _, out := post(e.gateway); out.Results[0].Status != api.StatusDuplicate {
		t.Fatalf("repeated SMS: %+v", out)
	}
	if !e.sms.find("1 of 1 payments received") {
		t.Fatal("no SMS acknowledgement")
	}
	if e.svc.SettleDue(ctx) != 1 {
		t.Fatal("SMS-synced payment not settled")
	}
}

func TestPaymentToUnregisteredNumberSettlesWhenTheyJoin(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	dir := t.TempDir()
	w, _ := e.onboard("9876570001", "Payer", false, softElement(t, dir), dir)
	e.fund(w, 500_00, 300_00)
	q, _ := w.QuotePhone("9876570099")
	if q.Listed {
		t.Fatal("unknown number reported as listed")
	}
	if _, err := w.Pay(q, 40_00, wallet.DeliverSMS, approvePay(t, w, q.PayeeID, 40_00)); err != nil {
		t.Fatal(err)
	}
	if r, err := w.Sync(ctx); err != nil || r.Accepted != 1 {
		t.Fatalf("sync: %+v %v", r, err)
	}
	if e.svc.SettleDue(ctx) != 0 {
		t.Fatal("settled to a payee who does not exist yet")
	}
	ndir := t.TempDir()
	_, _ = e.onboard("9876570099", "New User", false, softElement(t, ndir), ndir)
	if e.svc.SettleDue(ctx) != 1 {
		t.Fatal("waiting payment not settled after the payee registered")
	}
	acct := accountOf(t, e, "9876570099")
	if avail, _ := e.bank.Balance(ctx, acct.ID); avail != 40_00 {
		t.Fatalf("new user balance %d", avail)
	}
}

func TestTopUpRequiresSyncAndCarriesBalance(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	ks, _ := emulator.NewAndroidKeyStore(e.android, attest.AndroidStrongBox)
	dir := t.TempDir()
	w, reg := e.onboard("9876580001", "Payer", false, hwElement(t, dir, ks), dir)
	e.fund(w, 2000_00, 600_00)
	if _, err := w.PayPhone("9876580002", 100_00, wallet.DeliverQR, approvePhone(t, w, "9876580002", 100_00)); err != nil {
		t.Fatal(err)
	}
	// A top-up from a device that has not uploaded its payment is refused.
	dev, _ := offline.ParseID(reg.DeviceID)
	stale := e.client().WithDevice(dev, payerElement(t, w))
	if _, err := stale.CreateReserve(ctx, api.ReserveRequest{AmountPaise: 100_00, NextCounter: 1,
		ChainHead: make([]byte, 16)}, client.NewIdempotencyKey()); !client.IsCode(err, "sync_required") {
		t.Fatalf("unsynced top-up: %v", err)
	}
	// The wallet syncs automatically, then carries 500 and adds 300.
	resp, err := w.CreateReserve(ctx, 300_00, approveOp(t, w, wallet.OpReserve, 300_00))
	if err != nil {
		t.Fatal(err)
	}
	if resp.CarriedOver != 500_00 || resp.Reserve.AmountPaise != 800_00 {
		t.Fatalf("top-up: %+v", resp)
	}
	if b, _ := w.Balance(); b.OfflinePaise != 800_00 {
		t.Fatalf("element balance %d", b.OfflinePaise)
	}
	acct := accountOf(t, e, "9876580001")
	if avail, held := e.bank.Balance(ctx, acct.ID); avail != 1100_00 || held != 900_00 {
		t.Fatalf("bank available %d held %d", avail, held)
	}
	// The old reserve's payment still settles from its own hold (after the payee joins).
	pdir := t.TempDir()
	_, _ = e.onboard("9876580002", "Shop", true, softElement(t, pdir), pdir)
	if e.svc.SettleDue(ctx) != 1 {
		t.Fatal("old reserve payment not settled")
	}
}

func TestReserveExpiryReleasesUnspentMoney(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	dir := t.TempDir()
	w, _ := e.onboard("9876590001", "Payer", false, softElement(t, dir), dir)
	e.fund(w, 500_00, 400_00)
	p, _ := w.PayPhone("9876590002", 100_00, wallet.DeliverQR, approvePhone(t, w, "9876590002", 100_00))
	e.advance(7*24*time.Hour + offlinesvc.DefaultPolicy().SettlementGrace + time.Hour)
	if res := e.svc.Sync(ctx, nil, [][]byte{p.Record}, "internet", nil); res[0].Reason != "expired" {
		t.Fatalf("late record: %+v", res[0])
	}
	if n := e.svc.ExpireReserves(ctx); n != 1 {
		t.Fatalf("expired %d", n)
	}
	acct := accountOf(t, e, "9876590001")
	if avail, held := e.bank.Balance(ctx, acct.ID); avail != 500_00 || held != 0 {
		t.Fatalf("after expiry: available %d held %d", avail, held)
	}
}

func TestNewDeviceRevokesOldButOldPaymentsStillSettle(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	d1, sdir := t.TempDir(), t.TempDir()
	old, oreg := e.onboard("9876600001", "Asha", false, softElement(t, d1), d1)
	shop, _ := e.onboard("9876600002", "Shop", true, softElement(t, sdir), sdir)
	e.fund(old, 500_00, 300_00)
	p, _ := old.PayPhone("9876600002", 30_00, wallet.DeliverQR, approvePhone(t, old, "9876600002", 30_00))
	if _, err := shop.Accept(p.QR); err != nil {
		t.Fatal(err)
	}
	d2 := t.TempDir()
	_, nreg := e.onboard("9876600001", "Asha", false, softElement(t, d2), d2)
	if nreg.RevokedDeviceID != oreg.DeviceID {
		t.Fatalf("old device not revoked: %+v", nreg)
	}
	if _, err := old.Deposit(ctx, 100, approveOp(t, old, wallet.OpDeposit, 100)); !client.IsCode(err, "device_revoked") {
		t.Fatalf("revoked device deposit: %v", err)
	}
	if r, err := shop.Sync(ctx); err != nil || r.Accepted != 1 {
		t.Fatalf("payment from the revoked device's reserve: %+v %v", r, err)
	}
	dir, _ := e.svc.Directory(ctx)
	sd := &offline.SignedDirectory{Payload: dir.Payload, Signature: dir.Signature}
	opened, err := sd.Open(e.svc.CAPublicKey())
	oldID, _ := offline.ParseID(oreg.DeviceID)
	if err != nil || !opened.IsRevoked(oldID) {
		t.Fatal("revoked device missing from the signed revocation list")
	}
}

func TestRequestReplayAndClockSkewAreRejected(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	dir := t.TempDir()
	w, reg := e.onboard("9876610001", "Asha", false, softElement(t, dir), dir)
	dev, _ := offline.ParseID(reg.DeviceID)
	signer := payerElement(t, w)
	ts := e.clock().Unix()
	msg := api.RequestMessage("GET", api.PathWallet, ts, "0123456789abcdef0123", nil)
	sig, err := signer.SignAuth(msg)
	if err != nil {
		t.Fatal(err)
	}
	send := func() int {
		req, _ := http.NewRequest("GET", e.srv.URL+api.PathWallet, nil)
		req.Header.Set(api.HeaderDevice, offline.FormatID(dev))
		req.Header.Set(api.HeaderTimestamp, itoa(ts))
		req.Header.Set(api.HeaderNonce, "0123456789abcdef0123")
		req.Header.Set(api.HeaderSignature, b64(sig))
		resp, err := http.DefaultClient.Do(req)
		if err != nil {
			t.Fatal(err)
		}
		resp.Body.Close()
		return resp.StatusCode
	}
	if s := send(); s != 200 {
		t.Fatalf("first request %d", s)
	}
	if s := send(); s != 401 {
		t.Fatalf("replayed request %d", s)
	}
	skewed := e.client().WithDevice(dev, signer)
	skewed.SetClock(func() time.Time { return e.clock().Add(-time.Hour) })
	if _, err := skewed.Wallet(ctx); !client.IsCode(err, "clock_skew") {
		t.Fatalf("skewed request: %v", err)
	}
}

func TestRASPBlocksWalletAndRegistration(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	rooted := rasp.Static{Findings: []api.RASPFinding{{Check: "root", Severity: rasp.Critical, Detail: "su found"}}}
	dir := t.TempDir()
	w, _ := wallet.New(wallet.Config{Dir: dir, Element: softElement(t, dir), Client: e.client(), Guard: rooted, KDF: wallet.TestKDF})
	if err := w.Unlock(pin); !errors.Is(err, wallet.ErrCompromised) {
		t.Fatalf("rooted unlock: %v", err)
	}
	// Even if an app ignores the local block, the server refuses to register it.
	w2, _ := wallet.New(wallet.Config{Dir: dir, Element: softElement(t, t.TempDir()), Client: e.client(), Guard: rooted,
		AllowCompromised: true, KDF: wallet.TestKDF})
	_ = w2.Unlock(pin)
	otp, _ := w2.StartAccount(ctx, "9876620001", "Rooted", false)
	_ = w2.VerifyAccount(ctx, "9876620001", otp)
	if _, err := w2.Register(ctx); !client.IsCode(err, "rasp_blocked") {
		t.Fatalf("rooted registration: %v", err)
	}
}

func TestBankFaultsDuringSettlementNeverPayTwice(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	dir, sdir := t.TempDir(), t.TempDir()
	w, _ := e.onboard("9876630001", "Payer", false, softElement(t, dir), dir)
	_, _ = e.onboard("9876630002", "Shop", true, softElement(t, sdir), sdir)
	e.fund(w, 500_00, 300_00)
	_, _ = w.PayPhone("9876630002", 60_00, wallet.DeliverQR, approvePhone(t, w, "9876630002", 60_00))
	_, _ = w.Sync(ctx)
	e.bank.PushFault("transfer", bank.FaultUnavailable, bank.FaultLostResponse)
	if e.svc.SettleDue(ctx) != 1 {
		t.Fatal("settlement did not recover from an unavailable bank and a lost response")
	}
	if e.bank.Effects("transfer") != 1 {
		t.Fatalf("bank executed %d transfers", e.bank.Effects("transfer"))
	}
	if d, _ := e.svc.Reconcile(ctx); len(d) != 0 {
		t.Fatalf("reconciliation: %v", d)
	}
}

func TestSIMAppletWalletPays(t *testing.T) {
	e := newEnv(t)
	ctx := context.Background()
	sim, _ := emulator.NewSIMApplet(e.simRoot, pin)
	dir, sdir := t.TempDir(), t.TempDir()
	w, reg := e.onboard("9876640001", "Feature Phone", false, sim, dir)
	shop, _ := e.onboard("9876640002", "Shop", true, softElement(t, sdir), sdir)
	if reg.Trust != "secure-applet" {
		t.Fatalf("trust %s", reg.Trust)
	}
	e.fund(w, 3000_00, 2000_00)
	p, err := w.PayPhone("9876640002", 500_00, wallet.DeliverQR, approvePhone(t, w, "9876640002", 500_00))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := shop.Accept(p.QR); err != nil {
		t.Fatal(err)
	}
	if r, _ := shop.Sync(ctx); r.Accepted != 1 {
		t.Fatalf("sync %+v", r)
	}
}

func approvePay(t *testing.T, w *wallet.Wallet, payee uint64, amount int64) *wallet.Approval {
	t.Helper()
	a, err := w.Approve(wallet.Intent{Op: wallet.OpPay, AmountPaise: amount, PayeeID: payee}, pin)
	if err != nil {
		t.Fatalf("approve payment: %v", err)
	}
	return a
}

func approvePhone(t *testing.T, w *wallet.Wallet, phone string, amount int64) *wallet.Approval {
	t.Helper()
	payee, err := offline.PayeeIDForPhone(phone)
	if err != nil {
		t.Fatal(err)
	}
	return approvePay(t, w, payee, amount)
}

func approveOp(t *testing.T, w *wallet.Wallet, op string, amount int64) *wallet.Approval {
	t.Helper()
	a, err := w.Approve(wallet.Intent{Op: op, AmountPaise: amount}, pin)
	if err != nil {
		t.Fatalf("approve %s: %v", op, err)
	}
	return a
}
