// Command devredis runs a Redis-protocol server for local development on
// machines without Redis (for example Windows without Docker). It is backed
// by miniredis: in-memory and single-process. PSTCO-Pay keeps no durable
// state in Redis, so restarting it loses no payment data. Use real Redis
// (see deploy/docker-compose.yml) in production.
package main

import (
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"github.com/alicebob/miniredis/v2"
)

func main() {
	addr := flag.String("addr", "127.0.0.1:6379", "listen address")
	flag.Parse()
	s := miniredis.NewMiniRedis()
	if err := s.StartAddr(*addr); err != nil {
		fmt.Fprintln(os.Stderr, "devredis:", err)
		os.Exit(1)
	}
	defer s.Close()
	fmt.Printf("devredis listening on redis://%s/0 (development only, in-memory)\n", s.Addr())
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt, syscall.SIGTERM)
	<-sig
}
