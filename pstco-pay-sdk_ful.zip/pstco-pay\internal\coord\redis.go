// Package coord is PSTCO-Pay's Redis layer for temporary coordination and
// caching. Redis never holds financial execution state: that stays in the
// durable store. Redis holds only
//   - single-use, scoped, expiring execution-authorization nonces,
//   - distributed per-payment locks, so several server instances can share
//     one database without processing the same payment concurrently,
//   - a short-lived merchant cache in front of the database.
//
// Losing Redis loses no payment data: nonces are re-issued per attempt, locks
// expire, and the cache refills from the database.
package coord

import (
	"context"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"

	"pstcopay/internal/model"
	"pstcopay/internal/nonce"
)

// Options tunes the Redis layer.
type Options struct {
	Prefix   string        // key namespace, default "pstco"
	NonceTTL time.Duration // default 2m
	LockTTL  time.Duration // default 15s, renewed while held
	CacheTTL time.Duration // default 30s
	// CacheKey (32 bytes) encrypts cached merchant records with AES-256-GCM,
	// so a Redis compromise alone does not expose merchant secrets.
	CacheKey []byte
}

// Redis implements engine.NonceStore, engine.Locker and engine.MerchantCache.
type Redis struct {
	c    redis.UniversalClient
	opts Options
}

// Dial connects using a redis:// or rediss:// (TLS) URL and pings the server.
func Dial(ctx context.Context, url string, o Options) (*Redis, error) {
	ro, err := redis.ParseURL(url)
	if err != nil {
		return nil, fmt.Errorf("coord: redis url: %w", err)
	}
	ro.PoolSize = 64
	ro.ReadTimeout = 500 * time.Millisecond
	ro.WriteTimeout = 500 * time.Millisecond
	r := New(redis.NewClient(ro), o)
	if err := r.Ping(ctx); err != nil {
		r.Close()
		return nil, err
	}
	return r, nil
}

// New wraps an existing client.
func New(c redis.UniversalClient, o Options) *Redis {
	if o.Prefix == "" {
		o.Prefix = "pstco"
	}
	if o.NonceTTL == 0 {
		o.NonceTTL = 2 * time.Minute
	}
	if o.LockTTL == 0 {
		o.LockTTL = 15 * time.Second
	}
	if o.CacheTTL == 0 {
		o.CacheTTL = 30 * time.Second
	}
	return &Redis{c: c, opts: o}
}

// Ping checks connectivity.
func (r *Redis) Ping(ctx context.Context) error {
	if err := r.c.Ping(ctx).Err(); err != nil {
		return fmt.Errorf("coord: redis ping: %w", err)
	}
	return nil
}

// Close closes the client.
func (r *Redis) Close() error { return r.c.Close() }

func (r *Redis) key(kind, id string) string { return r.opts.Prefix + ":" + kind + ":" + id }

// ------------------------------------------------------------------ nonces

// consumeScript atomically checks and marks a nonce used, keeping its TTL so
// a replay inside the window is reported as "used" rather than "unknown".
// Returns 1 ok, 0 unknown or expired, 2 already used, 3 scope mismatch.
var consumeScript = redis.NewScript(`
local v = redis.call('GET', KEYS[1])
if not v then return 0 end
if string.sub(v, 1, 5) == 'USED:' then return 2 end
if v ~= ARGV[1] then return 3 end
local ttl = redis.call('PTTL', KEYS[1])
if ttl > 0 then
  redis.call('SET', KEYS[1], 'USED:' .. v, 'PX', ttl)
else
  redis.call('SET', KEYS[1], 'USED:' .. v)
end
return 1
`)

// Issue creates a nonce bound to scope.
func (r *Redis) Issue(ctx context.Context, scope string) (string, string, error) {
	n := nonce.New16()
	ok, err := r.c.SetNX(ctx, r.key("nonce", n), scope, r.opts.NonceTTL).Result()
	if err != nil {
		return "", "", fmt.Errorf("coord: issue nonce: %w", err)
	}
	if !ok {
		return "", "", errors.New("coord: nonce collision")
	}
	return n, nonce.Ref(n), nil
}

// Consume marks the nonce used. Errors match package nonce.
func (r *Redis) Consume(ctx context.Context, n, scope string) error {
	res, err := consumeScript.Run(ctx, r.c, []string{r.key("nonce", n)}, scope).Int()
	if err != nil {
		return fmt.Errorf("coord: consume nonce: %w", err)
	}
	switch res {
	case 1:
		return nil
	case 2:
		return nonce.ErrUsed
	case 3:
		return nonce.ErrScopeMismatch
	}
	return nonce.ErrUnknown // unknown, or expired and evicted by Redis
}

// ------------------------------------------------------------------- locks

var unlockScript = redis.NewScript(`
if redis.call('GET', KEYS[1]) == ARGV[1] then return redis.call('DEL', KEYS[1]) end
return 0
`)

var renewScript = redis.NewScript(`
if redis.call('GET', KEYS[1]) == ARGV[1] then return redis.call('PEXPIRE', KEYS[1], ARGV[2]) end
return 0
`)

// TryLock acquires the payment lock without waiting. The lock carries a
// random token (only the holder can release it) and a TTL that a watchdog
// renews while it is held, so a crashed holder releases it automatically.
func (r *Redis) TryLock(ctx context.Context, id string) (func(), bool) {
	token := nonce.New16()
	k := r.key("lock", id)
	ok, err := r.c.SetNX(ctx, k, token, r.opts.LockTTL).Result()
	if err != nil || !ok {
		return nil, false
	}
	stop := make(chan struct{})
	done := make(chan struct{})
	go func() {
		defer close(done)
		t := time.NewTicker(r.opts.LockTTL / 3)
		defer t.Stop()
		for {
			select {
			case <-stop:
				return
			case <-t.C:
				c, cancel := context.WithTimeout(context.Background(), r.opts.LockTTL/3)
				_ = renewScript.Run(c, r.c, []string{k}, token, r.opts.LockTTL.Milliseconds()).Err()
				cancel()
			}
		}
	}()
	return func() {
		close(stop)
		<-done
		c, cancel := context.WithTimeout(context.Background(), time.Second)
		defer cancel()
		_ = unlockScript.Run(c, r.c, []string{k}, token).Err()
	}, true
}

// Lock waits for the payment lock until ctx ends.
func (r *Redis) Lock(ctx context.Context, id string) (func(), error) {
	wait := time.Millisecond
	for {
		if unlock, ok := r.TryLock(ctx, id); ok {
			return unlock, nil
		}
		t := time.NewTimer(wait)
		select {
		case <-ctx.Done():
			t.Stop()
			return nil, ctx.Err()
		case <-t.C:
		}
		wait = min(wait*2, 25*time.Millisecond)
	}
}

// ---------------------------------------------------------- merchant cache

// Get returns a cached merchant. The record includes the request-signing
// secret, so production Redis must use ACLs and TLS (rediss://).
func (r *Redis) Get(ctx context.Context, id string) (*model.Merchant, bool) {
	b, err := r.c.Get(ctx, r.key("merchant", id)).Bytes()
	if err != nil {
		return nil, false
	}
	if b, err = r.unseal(b, id); err != nil {
		return nil, false
	}
	var m model.Merchant
	if json.Unmarshal(b, &m) != nil {
		return nil, false
	}
	return &m, true
}

// Put caches a merchant for CacheTTL. Errors are ignored: the cache is optional.
func (r *Redis) Put(ctx context.Context, m *model.Merchant) {
	b, _ := json.Marshal(m)
	sealed, err := r.seal(b, m.ID)
	if err != nil {
		return
	}
	_ = r.c.Set(ctx, r.key("merchant", m.ID), sealed, r.opts.CacheTTL).Err()
}

func (r *Redis) gcm() (cipher.AEAD, error) {
	if len(r.opts.CacheKey) == 0 {
		return nil, nil
	}
	block, err := aes.NewCipher(r.opts.CacheKey)
	if err != nil {
		return nil, err
	}
	return cipher.NewGCM(block)
}

func (r *Redis) seal(plain []byte, id string) ([]byte, error) {
	g, err := r.gcm()
	if err != nil || g == nil {
		return plain, err
	}
	nonce := make([]byte, g.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return nil, err
	}
	return g.Seal(nonce, nonce, plain, []byte("merchant:"+id)), nil
}

func (r *Redis) unseal(b []byte, id string) ([]byte, error) {
	g, err := r.gcm()
	if err != nil || g == nil {
		return b, err
	}
	if len(b) < g.NonceSize() {
		return nil, errors.New("coord: cache entry too short")
	}
	return g.Open(nil, b[:g.NonceSize()], b[g.NonceSize():], []byte("merchant:"+id))
}

// Invalidate drops a cached merchant, after the merchant record changes.
func (r *Redis) Invalidate(ctx context.Context, id string) error {
	return r.c.Del(ctx, r.key("merchant", id)).Err()
}
