"""Offline formats and type checkpoints, no server needed."""

import json
import time
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature

from pstco import checks, formats as F
from pstco.amount import MAX_PAISE, decode_amount, encode_amount, format_rupees, parse_inr, to_paise
from pstco.checks import CheckError

GOLDEN = Path(__file__).resolve().parents[2] / "sdk" / "offline" / "testdata" / "golden.json"


def test_matches_go_golden_vectors():
    g = json.loads(GOLDEN.read_text())
    for a in g["amounts"]:
        assert parse_inr(a["input"]) == a["paise"]
        assert encode_amount(a["paise"]).hex() == a["hex"]
    for p in g["payee_ids"]:
        assert f"{F.payee_id_for_phone(p['phone']):016x}" == p["id"]
    for v in g["records"]:
        r = F.Record(v["device_id"], v["counter"], v["amount_paise"], v["payee_id"], v["timestamp"], v["expiry"],
                     bytes.fromhex(v["prev_hash"]))
        assert r.signed_bytes().hex() == v["signed_hex"]
        assert F.record_hash(r.to_bytes()).hex() == v["hash_zero_sig"]
        assert F.Record.from_bytes(r.to_bytes()) == r


@pytest.mark.parametrize("bad", [True, 1.0, "1", None, 2**64])
def test_integer_checkpoint_rejects_non_integers(bad):
    with pytest.raises(CheckError):
        checks.integer("n", bad, 0, 2**63)


@pytest.mark.parametrize("bad", [1, True, "1.5", None, float("nan"), float("inf")])
def test_float_checkpoint_rejects_non_floats(bad):
    with pytest.raises(CheckError):
        checks.floating("x", bad)


def test_strict_checkpoints_accept_exact_types():
    assert checks.integer("n", 5, 0, 10) == 5
    assert checks.floating("x", 0.5, 0.0, 1.0) == 0.5
    assert checks.boolean("b", False) is False
    with pytest.raises(CheckError):
        checks.boolean("b", 0)
    with pytest.raises(CheckError):
        checks.text("t", "a\x00b")
    with pytest.raises(CheckError):
        checks.binary("b", bytearray(b"x"))
    with pytest.raises(CheckError):
        checks.json_types("doc", {"amount_paise": 1.5}, {"amount_paise": int})
    with pytest.raises(CheckError):
        checks.json_types("doc", {"amount_paise": 1, "extra": 2}, {"amount_paise": int})


def test_money_is_never_a_float():
    with pytest.raises(CheckError, match="floats"):
        to_paise(123.45)
    assert to_paise("123.45") == 12345 and to_paise(12345) == 12345
    for bad in ["", "0", "-1", "1,000", "1.234", "01", " 1", "1e3", "10995116277.76"]:
        with pytest.raises(CheckError):
            parse_inr(bad)
    assert parse_inr("10995116277.75") == MAX_PAISE
    assert format_rupees(12345) == "123.45"
    with pytest.raises(CheckError):
        decode_amount(bytes(5))


def _cert(ca, pub, alg, now):
    c = F.DeviceCert(device_id=7, owner_payee=1, alg=alg, trust=2, per_payment_limit=50000, max_reserve=200000,
                     issued_at=int(now) - 10, expires_at=int(now) + 3600, public_key=pub)
    c.signature = ca.sign(F.CERT_TAG + c.body())
    return c.to_bytes()


@pytest.mark.parametrize("alg", [F.ALG_ED25519, F.ALG_P256])
def test_sign_verify_and_tamper_both_algorithms(alg):
    now = time.time()
    ca = ed25519.Ed25519PrivateKey.generate()
    ca_pub = ca.public_key().public_bytes_raw()
    if alg == F.ALG_ED25519:
        key = ed25519.Ed25519PrivateKey.generate()
        pub = key.public_key().public_bytes_raw()
        sign = key.sign
    else:
        key = ec.generate_private_key(ec.SECP256R1())
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
        pub = key.public_key().public_bytes(Encoding.X962, PublicFormat.UncompressedPoint)

        def sign(m):
            r, s = decode_dss_signature(key.sign(m, ec.ECDSA(hashes.SHA256())))
            return r.to_bytes(32, "big") + s.to_bytes(32, "big")
    cert = _cert(ca, pub, alg, now)
    payee = F.payee_id_for_phone("9876543210")
    rec = F.Record(7, 1, 12345, payee, int(now), int(now) + 600)
    rec.signature = sign(F.signing_message(rec.signed_bytes()))
    raw = rec.to_bytes()
    record, c2 = F.decode_payment_qr(F.encode_payment_qr(raw, cert))
    r, c = F.verify_payment(record, c2, ca_pub, payee, now)
    assert r.amount_paise == 12345 and c.trust_name == "hardware-key"
    for i in range(F.SIGNED_SIZE):
        bad = bytearray(raw)
        bad[i] ^= 1
        with pytest.raises((F.PaymentRejected, CheckError)):
            F.verify_payment(bytes(bad), cert, ca_pub, payee, now)
    with pytest.raises(F.PaymentRejected):
        F.verify_payment(raw, cert, ca_pub, payee + 1, now)
    with pytest.raises(F.PaymentRejected):
        F.verify_payment(raw, cert, ed25519.Ed25519PrivateKey.generate().public_key().public_bytes_raw(), payee, now)
