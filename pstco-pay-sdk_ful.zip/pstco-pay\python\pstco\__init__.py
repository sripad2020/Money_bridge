"""PSTCO-Pay Python SDK: offline payment formats, strict type checkpoints,
blocking and asyncio API clients, a software wallet with approval
guardrails, and an optional C network library binding."""

from .amount import MAX_PAISE, format_rupees, parse_inr, to_paise
from .checks import CheckError
from .client import APIError, AsyncClient, Client
from .formats import PaymentRejected, payee_id_for_phone, verify_payment
from .wallet import Approval, AsyncSoftwareWallet, SoftwareWallet, WalletError

__version__ = "1.0.0"
__all__ = ["MAX_PAISE", "format_rupees", "parse_inr", "to_paise", "CheckError", "APIError", "AsyncClient", "Client",
           "PaymentRejected", "payee_id_for_phone", "verify_payment", "Approval", "AsyncSoftwareWallet",
           "SoftwareWallet", "WalletError"]
