"""Starts a real pstco-server (with -dev-otp) for the end-to-end tests."""

import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
EXE = ".exe" if sys.platform == "win32" else ""
BIN = ROOT / "bin"


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def ensure_binaries():
    if not (BIN / f"pstco-server{EXE}").exists() or not (BIN / f"pstco-wallet{EXE}").exists():
        subprocess.run(["go", "build", "-o", str(BIN) + os.sep, "./cmd/..."], cwd=ROOT, check=True)


@pytest.fixture(scope="session")
def server(tmp_path_factory):
    ensure_binaries()
    work = tmp_path_factory.mktemp("pstco")
    certs = work / "certs"
    subprocess.run([str(BIN / f"certgen{EXE}"), "-out", str(certs)], check=True, capture_output=True)
    port, gport = free_port(), free_port()
    log = open(work / "server.log", "w")
    proc = subprocess.Popen([str(BIN / f"pstco-server{EXE}"), "-data", str(work / "data"), "-certs", str(certs),
                             "-listen", f"127.0.0.1:{gport}", "-offline-listen", f"127.0.0.1:{port}", "-metrics", "-",
                             "-dev-otp", "-public-rate-limit", "-1"], stdout=log, stderr=log)
    deadline = time.time() + 20
    while time.time() < deadline:
        try:
            socket.create_connection(("127.0.0.1", port), 0.5).close()
            break
        except OSError:
            time.sleep(0.1)
    else:
        proc.kill()
        raise RuntimeError("server did not start: " + (work / "server.log").read_text())
    yield {"url": f"https://localhost:{port}", "ca": str(certs / "ca.pem"), "port": port, "work": work,
           "certs": str(certs), "wallet_cli": str(BIN / f"pstco-wallet{EXE}")}
    proc.terminate()
    try:
        proc.wait(10)
    except subprocess.TimeoutExpired:
        proc.kill()
    log.close()


_phone = [9876800000]


@pytest.fixture
def phone():
    def next_phone() -> str:
        _phone[0] += 1
        return str(_phone[0])
    return next_phone
