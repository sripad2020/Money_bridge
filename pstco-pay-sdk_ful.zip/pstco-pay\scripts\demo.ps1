# End-to-end PSTCO-Pay demo on Windows:
# builds, generates certificates, starts the server with fault injection,
# makes a payment, prints its verified execution graph, refunds a second
# payment, runs a short load test, then reconciles and verifies anchors.
#
#   powershell -ExecutionPolicy Bypass -File scripts\demo.ps1
param([string]$WorkDir = (Join-Path $env:TEMP "pstco-demo"))
$ErrorActionPreference = "Stop"
# Development secret shared by the server and the demo clients. Never use it in production.
if (-not $env:PSTCO_MERCHANT_SECRET) { $env:PSTCO_MERCHANT_SECRET = "demo-merchant-secret" }
$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
$srv = $null
try {
    go build -o bin\ ./cmd/...
    New-Item -ItemType Directory -Force $WorkDir | Out-Null
    $certs = Join-Path $WorkDir "certs"
    $data = Join-Path $WorkDir "data"
    if (-not (Test-Path (Join-Path $certs "ca.pem"))) { & .\bin\certgen.exe -out $certs }

    # Use a real Redis if one is already listening on 6379, otherwise start the dev server.
    $redisUp = (Test-NetConnection 127.0.0.1 -Port 6379 -WarningAction SilentlyContinue).TcpTestSucceeded
    if (-not $redisUp) {
        $script:redis = Start-Process -FilePath (Resolve-Path .\bin\devredis.exe) -PassThru -WindowStyle Hidden `
            -RedirectStandardOutput (Join-Path $WorkDir "redis.out") -RedirectStandardError (Join-Path $WorkDir "redis.log")
        Start-Sleep -Seconds 1
    }
    $srv = Start-Process -FilePath (Resolve-Path .\bin\pstco-server.exe) -PassThru -WindowStyle Hidden `
        -ArgumentList "-data `"$data`" -certs `"$certs`" -faults flaky -redis redis://127.0.0.1:6379/0" `
        -RedirectStandardError (Join-Path $WorkDir "server.log") -RedirectStandardOutput (Join-Path $WorkDir "server.out")
    Start-Sleep -Seconds 2
    Get-Content (Join-Path $WorkDir "server.log") | Select-String "listening" | Write-Host

    Write-Host "`n=== 1. Payment of Rs 1,234 over one persistent TLS 1.3 mTLS connection"
    $pay = & .\bin\pstco-cli.exe pay -certs $certs -amount 1234.00
    $pay | Write-Host
    $id = (($pay -join "`n") | Select-String '"payment_id": "([^"]+)"').Matches[0].Groups[1].Value

    Start-Sleep -Milliseconds 800
    Write-Host "`n=== 2. Execution graph (hash-linked, signed, verified)"
    & .\bin\pstco-cli.exe graph -certs $certs -id $id

    Write-Host "`n=== 3. Second payment, then a merchant refund"
    $p2 = & .\bin\pstco-cli.exe pay -certs $certs -amount 499.00
    $id2 = (($p2 -join "`n") | Select-String '"payment_id": "([^"]+)"').Matches[0].Groups[1].Value
    & .\bin\pstco-cli.exe refund -certs $certs -id $id2 -reason "demo refund" | Select-String '"state"|"refund_id"'

    Write-Host "`n=== 4. Load: 1000 payments, 32 concurrent streams, 1 TCP connection, 5% unavailable + 3% lost responses"
    & .\bin\pstco-loadgen.exe -certs $certs -n 1000 -c 32 -conns 1 -out (Join-Path $WorkDir "loadgen.csv")

    Start-Sleep -Seconds 1
    Write-Host "`n=== 5. Reconciliation and anchor verification (admin certificate)"
    & .\bin\pstco-cli.exe reconcile -certs $certs | Select-String 'payments_checked|external_lines|"kind"'
    & .\bin\pstco-cli.exe anchors -certs $certs | Select-String '"anchors"|events_covered|problems'

    Write-Host "`nTransport view:"
    & .\bin\pstco-cli.exe transport -certs $certs | Select-String 'active_conns|inflight|congestion|mean_ms'
    Write-Host "`nWork dir: $WorkDir"
} finally {
    if ($srv) { Stop-Process -Id $srv.Id -Force -ErrorAction SilentlyContinue }
    if ($script:redis) { Stop-Process -Id $script:redis.Id -Force -ErrorAction SilentlyContinue }
    Pop-Location
}
