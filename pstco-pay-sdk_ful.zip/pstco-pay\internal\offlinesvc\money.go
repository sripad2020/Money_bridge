package offlinesvc

import (
	"bytes"
	"context"
	"errors"
	"strconv"
	"time"

	"pstcopay/internal/bank"
	"pstcopay/internal/store"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/offline/api"
)

func summary(r *store.Reserve) *api.ReserveSummary {
	return &api.ReserveSummary{ReserveID: offline.FormatID(r.ID), AmountPaise: r.Amount, SpentPaise: r.Spent,
		CounterStart: r.CounterStart, ExpiresAt: int64(r.Expiry), Status: r.Status}
}

func activeOnly(d *store.Device) error {
	if d.Status != store.DeviceActive {
		return apiErr(403, "device_"+lower(d.Status), "device is %s: %s", lower(d.Status), d.StatusReason)
	}
	return nil
}

func lower(s string) string { return string(bytes.ToLower([]byte(s))) }

// Deposit funds the device owner's online wallet.
func (s *Service) Deposit(ctx context.Context, d *store.Device, amount int64, idem string) (*api.WalletResponse, error) {
	if err := activeOnly(d); err != nil {
		return nil, err
	}
	if idem == "" {
		return nil, apiErr(400, "idempotency_key_required", "send an Idempotency-Key header")
	}
	if amount <= 0 || amount > s.cfg.Policy.MaxDepositPaise {
		return nil, apiErr(400, "invalid_amount", "deposit must be between 1 paisa and %s rupees", offline.FormatRupees(s.cfg.Policy.MaxDepositPaise))
	}
	key := "dep:" + d.AccountID + ":" + idem
	if _, err := s.bankDo(ctx, key, func(c context.Context) (*bank.Result, error) {
		return s.bank.Deposit(c, key, d.AccountID, amount)
	}); err != nil {
		s.log.Error("bank deposit", "err", err)
		return nil, apiErr(502, "bank_error", "the bank did not complete the deposit; retry with the same Idempotency-Key")
	}
	return s.Wallet(ctx, d)
}

// Wallet returns the account's balances and the device's offline state.
func (s *Service) Wallet(ctx context.Context, d *store.Device) (*api.WalletResponse, error) {
	acct, err := s.st.GetAccount(ctx, d.AccountID)
	if err != nil {
		return nil, err
	}
	avail, held := s.bank.Balance(ctx, acct.ID)
	pending, settled, err := s.st.IncomingTotals(ctx, acct.PayeeID)
	if err != nil {
		return nil, err
	}
	maxC, _ := s.st.MaxCounter(ctx, d.ID)
	w := &api.WalletResponse{AccountID: acct.ID, PayeeID: offline.FormatID(acct.PayeeID), AvailablePaise: avail,
		ReservedPaise: held, DeviceStatus: d.Status, PendingInPaise: pending, SettledInPaise: settled, LastSyncedCount: maxC}
	if r, err := s.st.ActiveReserve(ctx, d.ID); err == nil {
		w.ActiveReserve = summary(r)
	}
	return w, nil
}

// CreateReserve locks money at the bank as a new offline balance. It carries
// any unspent amount from the previous reserve, and requires the device to
// have synced every record it signed, proven by its next counter and chain head.
func (s *Service) CreateReserve(ctx context.Context, d *store.Device, req api.ReserveRequest, idem string) (*api.ReserveResponse, error) {
	if idem == "" {
		return nil, apiErr(400, "idempotency_key_required", "send an Idempotency-Key header")
	}
	unlock, err := s.lockDevice(ctx, d.ID)
	if err != nil {
		return nil, err
	}
	defer unlock()
	idemKey := offline.FormatID(d.ID) + ":" + idem
	if prev, err := s.st.GetReserveByIdem(ctx, idemKey); err == nil {
		return &api.ReserveResponse{Instruction: prev.Instruction, Reserve: *summary(prev), CarriedOver: prev.Carried}, nil
	}
	if err := activeOnly(d); err != nil {
		return nil, err
	}
	if req.AmountPaise < 0 {
		return nil, apiErr(400, "invalid_amount", "amount cannot be negative")
	}
	trust := offline.Trust(d.Trust)
	lim := s.cfg.Policy.limits(trust)
	now := s.now()

	maxC, err := s.st.MaxCounter(ctx, d.ID)
	if err != nil {
		return nil, err
	}
	old, err := s.st.ActiveReserve(ctx, d.ID)
	hasOld := err == nil
	if err != nil && !errors.Is(err, store.ErrNotFound) {
		return nil, err
	}
	// The device must have uploaded every record: its next counter follows the
	// last record we hold, and its chain head is that record's hash (or the
	// genesis of a reserve it has not spent from).
	expectNext := maxC + 1
	var expectHead []byte
	switch {
	case hasOld && maxC < old.CounterStart:
		expectNext, expectHead = old.CounterStart, old.Genesis
	case maxC > 0:
		last, err := s.st.GetRecord(ctx, d.ID, maxC)
		if err != nil {
			return nil, err
		}
		expectHead = last.RecordHash
	default:
		expectHead = make([]byte, offline.HashSize)
	}
	if req.NextCounter != expectNext || !bytes.Equal(req.ChainHead, expectHead) {
		return nil, apiErr(409, "sync_required", "server holds records up to counter %d; sync every payment before topping up", maxC)
	}
	if maxC > 0 {
		if n, _ := s.st.CountRecordsInRange(ctx, d.ID, 1, maxC); n != int(maxC) {
			return nil, apiErr(409, "sync_required", "some earlier payments have not reached the server yet")
		}
		// Walk the whole chain: each record must link to its predecessor, or
		// to its reserve's genesis when it is the first under that reserve.
		if err := s.verifyDeviceChain(ctx, d.ID); err != nil {
			return nil, err
		}
	}
	var carry int64
	if hasOld {
		carry = old.Amount - old.Spent
	}
	total := carry + req.AmountPaise
	if total <= 0 {
		return nil, apiErr(400, "invalid_amount", "reserve must be positive")
	}
	if total > lim.MaxReservePaise {
		return nil, apiErr(400, "over_limit", "offline balance would be %s, above the %s limit for %s devices",
			offline.FormatRupees(total), offline.FormatRupees(lim.MaxReservePaise), trust)
	}
	id := randomID63()
	hold := "hold_" + offline.FormatID(id)
	if req.AmountPaise > 0 {
		key := "hold:" + offline.FormatID(id)
		if _, err := s.bankDo(ctx, key, func(c context.Context) (*bank.Result, error) {
			return s.bank.Hold(c, key, d.AccountID, hold, req.AmountPaise)
		}); err != nil {
			if errors.Is(err, bank.ErrInsufficient) {
				return nil, apiErr(402, "insufficient_funds", "online wallet balance is too low")
			}
			s.log.Error("bank hold", "err", err)
			return nil, apiErr(502, "bank_error", "the bank did not lock the reserve; retry with the same Idempotency-Key")
		}
	}
	if carry > 0 {
		key := "move:" + offline.FormatID(old.ID) + ":" + offline.FormatID(id)
		if _, err := s.bankDo(ctx, key, func(c context.Context) (*bank.Result, error) {
			return s.bank.MoveHold(c, key, old.HoldID, hold, carry)
		}); err != nil {
			s.log.Error("bank move hold", "err", err)
			return nil, apiErr(502, "bank_error", "carrying the old balance failed; retry with the same Idempotency-Key")
		}
	}
	instr := &offline.Reserve{Version: offline.ReserveV1, ReserveID: id, DeviceID: d.ID, AmountPaise: total,
		CounterStart: expectNext, PerPaymentLimit: lim.PerPaymentPaise,
		Expiry: uint32(now.Add(time.Duration(lim.ReserveDays) * 24 * time.Hour).Unix()), IssuedAt: uint32(now.Unix())}
	if err := instr.Sign(s.caSign); err != nil {
		return nil, err
	}
	raw, _ := instr.Marshal()
	g := offline.ReserveGenesis(raw)
	rec := &store.Reserve{ID: id, DeviceID: d.ID, AccountID: d.AccountID, IdemKey: idemKey, Amount: total, Carried: carry,
		CounterStart: expectNext, PerPaymentLimit: lim.PerPaymentPaise, Expiry: instr.Expiry, Instruction: raw,
		Genesis: g[:], HoldID: hold, Status: store.ReserveActive, CreatedAt: now}
	err = s.st.WithTx(ctx, func(tx *store.Tx) error {
		if hasOld {
			// The old reserve's spent part stays in its hold to settle its
			// records; shrinking it to that amount makes any later record
			// against it an overspend.
			if err := tx.CloseReserve(ctx, old.ID, store.ReserveClosed, now); err != nil {
				return err
			}
			if err := tx.ShrinkReserveToSpent(ctx, old.ID); err != nil {
				return err
			}
		}
		return tx.InsertReserve(ctx, rec)
	})
	if err != nil {
		return nil, err
	}
	return &api.ReserveResponse{Instruction: raw, Reserve: *summary(rec), CarriedOver: carry}, nil
}

// verifyDeviceChain checks every hash link of a device's records. A break
// means the device produced a forked history: it is frozen.
func (s *Service) verifyDeviceChain(ctx context.Context, device uint64) error {
	links, err := s.st.DeviceChain(ctx, device)
	if err != nil {
		return err
	}
	reserves := map[uint64]*store.Reserve{}
	for i, l := range links {
		rsv, ok := reserves[l.ReserveID]
		if !ok {
			if rsv, err = s.st.GetReserve(ctx, l.ReserveID); err != nil {
				return err
			}
			reserves[l.ReserveID] = rsv
		}
		var want []byte
		switch {
		case l.Counter == rsv.CounterStart:
			want = rsv.Genesis
		case i > 0 && links[i-1].Counter == l.Counter-1:
			want = links[i-1].RecordHash
		default:
			continue
		}
		if !bytes.Equal(l.PrevHash, want) {
			now := s.now()
			detail := "record " + strconv.FormatUint(uint64(l.Counter), 10) + " does not link to its predecessor"
			_ = s.st.InsertConflict(ctx, device, l.Counter, []byte{}, ConflictFork, detail, now)
			_ = s.st.SetDeviceStatus(ctx, device, store.DeviceFrozen, ConflictFork+": "+detail, now)
			s.securityEvent(ctx, EventDeviceFrozen, "device:"+offline.FormatID(device), detail)
			return apiErr(409, "chain_broken", "the payment chain is broken; the device is frozen")
		}
	}
	return nil
}
