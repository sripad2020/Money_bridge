package engine

import (
	"context"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"pstcopay/internal/acquirer"
	"pstcopay/internal/chain"
	"pstcopay/internal/controller"
	"pstcopay/internal/model"
	"pstcopay/internal/nonce"
	"pstcopay/internal/risk"
	"pstcopay/internal/store"
)

const (
	testMerchant  = "merchant_1"
	testSecret    = "test-secret"
	testPrincipal = "merchant-demo"
)

type harness struct {
	t      *testing.T
	dir    string
	e      *Engine
	st     *store.Store
	keys   *chain.KeyRing
	acq    *acquirer.Acquirer
	faults *acquirer.ScriptedFaults
}

type faultFunc func(op acquirer.Op, key string) acquirer.Fault

func (f faultFunc) Fault(op acquirer.Op, key string) acquirer.Fault { return f(op, key) }

func newHarness(t *testing.T, opts ...func(*Config, *acquirer.Config)) *harness {
	t.Helper()
	dir := t.TempDir()
	st, err := store.Open(filepath.Join(dir, "pstco.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { st.Close() })
	faults := acquirer.NewScriptedFaults()
	cfg := DefaultConfig()
	cfg.AnchorFile = filepath.Join(dir, "anchors.jsonl")
	acfg := acquirer.Config{Faults: faults}
	for _, o := range opts {
		o(&cfg, &acfg)
	}
	acq := acquirer.New(acfg)
	ccfg := controller.DefaultConfig()
	ccfg.BaseBackoff = time.Millisecond
	ccfg.MaxBackoff = 5 * time.Millisecond
	keys := chain.NewEphemeralKeyRing()
	nonces := nonce.New(time.Minute)
	t.Cleanup(nonces.Close)
	h := &harness{t: t, dir: dir, st: st, keys: keys, acq: acq, faults: faults}
	h.e = New(cfg, Deps{Store: st, Keys: keys, Nonces: nonces, Acquirer: acq,
		Risk: risk.New(risk.DefaultConfig()), Controller: controller.New(ccfg),
		Logger: slog.New(slog.NewTextHandler(io.Discard, nil))})
	if err := st.UpsertMerchant(context.Background(), &model.Merchant{ID: testMerchant, Secret: testSecret,
		Principal: testPrincipal, Active: true, MaxAmountMinor: 1_00_00_000_00, AllowReauth: true}); err != nil {
		t.Fatal(err)
	}
	return h
}

func (h *harness) request(key string, amount int64, token string) *model.PaymentRequest {
	now := time.Now()
	r := &model.PaymentRequest{MerchantID: testMerchant, CustomerID: "cust_42", IdempotencyKey: key,
		AmountMinor: amount, Currency: "INR", CardToken: token, ClientTime: now, ExpiresAt: now.Add(time.Hour)}
	r.Signature = model.SignRequest(r, testSecret)
	return r
}

func (h *harness) pay(key string, amount int64, token string) *model.Payment {
	h.t.Helper()
	p, err := h.e.Process(context.Background(), h.request(key, amount, token), testPrincipal)
	if err != nil {
		h.t.Fatalf("process: %v", err)
	}
	return p
}

func (h *harness) mustState(p *model.Payment, want model.State) {
	h.t.Helper()
	if p.State != want {
		h.t.Fatalf("state = %s (%s: %s), want %s", p.State, p.FailureCode, p.FailureReason, want)
	}
}

func (h *harness) verify(id string) []*chain.Event {
	h.t.Helper()
	evs, err := h.st.ListEvents(context.Background(), id)
	if err != nil {
		h.t.Fatal(err)
	}
	if err := chain.VerifyGraph(evs, h.keys); err != nil {
		h.t.Fatalf("graph verification failed: %v", err)
	}
	return evs
}

func decisions(evs []*chain.Event) []string {
	var out []string
	for _, ev := range evs {
		if ev.Stage == model.StageRecovery {
			out = append(out, ev.Payload["decision"])
		}
	}
	return out
}

func eqInt(t *testing.T, name string, got, want int) {
	t.Helper()
	if got != want {
		t.Fatalf("%s = %d, want %d", name, got, want)
	}
}

// ------------------------------------------------------------------ tests

func TestHappyPathSettlesReconcilesAndAnchors(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	p := h.pay("order-1", 1234_00, "tok_visa_ok")
	h.mustState(p, model.StateSettlementPending)

	n, err := h.e.SettleDue(ctx)
	if err != nil || n != 1 {
		t.Fatalf("settle: n=%d err=%v", n, err)
	}
	p, _ = h.e.GetPayment(ctx, p.ID)
	h.mustState(p, model.StateSettled)

	evs := h.verify(p.ID)
	var stages []string
	for _, ev := range evs {
		stages = append(stages, string(ev.Stage)+":"+string(ev.Status))
	}
	want := []string{"CREATE:SUCCESS", "VALIDATE:SUCCESS", "AUTHENTICATE:SUCCESS", "RISK:SUCCESS",
		"AUTHORIZE:PENDING", "AUTHORIZE:SUCCESS", "CAPTURE:PENDING", "CAPTURE:SUCCESS",
		"SETTLE:PENDING", "SETTLE:SUCCESS"}
	if fmt.Sprint(stages) != fmt.Sprint(want) {
		t.Fatalf("stages\n got %v\nwant %v", stages, want)
	}

	rep, err := h.e.Reconcile(ctx)
	if err != nil || len(rep.Discrepancies) != 0 {
		t.Fatalf("reconcile: %v %+v", err, rep)
	}
	if a, err := h.e.AnchorOnce(ctx); err != nil || a == nil || a.Count != len(evs) {
		t.Fatalf("anchor: %+v %v", a, err)
	}
	ar, err := h.e.VerifyAnchors(ctx)
	if err != nil || len(ar.Problems) != 0 || ar.Events != len(evs) {
		t.Fatalf("verify anchors: %+v %v", ar, err)
	}
}

func TestIdempotentReplayAndConflict(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	req := h.request("order-dup", 500_00, "tok_visa_ok")
	p1, err := h.e.Process(ctx, req, testPrincipal)
	if err != nil {
		t.Fatal(err)
	}
	p2, err := h.e.Process(ctx, req, testPrincipal)
	if err != nil {
		t.Fatal(err)
	}
	if p1.ID != p2.ID {
		t.Fatalf("replay created a second payment")
	}
	eqInt(t, "authorize effects", h.acq.Effects(acquirer.OpAuthorize), 1)

	other := h.request("order-dup", 999_00, "tok_visa_ok")
	if _, err := h.e.Process(ctx, other, testPrincipal); !errors.Is(err, ErrIdempotencyConflict) {
		t.Fatalf("want ErrIdempotencyConflict, got %v", err)
	}
}

func TestConcurrentSameKeyExecutesOnce(t *testing.T) {
	h := newHarness(t)
	req := h.request("order-race", 700_00, "tok_visa_ok")
	var wg sync.WaitGroup
	ids := make([]string, 16)
	for i := range ids {
		wg.Add(1)
		go func() {
			defer wg.Done()
			p, err := h.e.Process(context.Background(), req, testPrincipal)
			if err != nil {
				t.Errorf("process: %v", err)
				return
			}
			ids[i] = p.ID
		}()
	}
	wg.Wait()
	for _, id := range ids {
		if id != ids[0] {
			t.Fatalf("different payment ids for the same key: %v", ids)
		}
	}
	eqInt(t, "authorize effects", h.acq.Effects(acquirer.OpAuthorize), 1)
	eqInt(t, "capture effects", h.acq.Effects(acquirer.OpCapture), 1)
}

func TestCaptureLostResponseIsReconciledNotRepeated(t *testing.T) {
	h := newHarness(t)
	h.faults.Push(acquirer.OpCapture, acquirer.FaultLostResponse)
	p := h.pay("order-lost", 1234_00, "tok_visa_ok")
	h.mustState(p, model.StateSettlementPending)

	eqInt(t, "capture calls", h.acq.Calls(acquirer.OpCapture), 1)
	eqInt(t, "capture effects", h.acq.Effects(acquirer.OpCapture), 1)
	evs := h.verify(p.ID)
	if d := decisions(evs); len(d) != 1 || d[0] != "reconciled_existing" {
		t.Fatalf("recovery decisions = %v", d)
	}
	last := latestSuccess(evs, model.StageCapture)
	if last.Payload["reconciled"] != "true" || last.RetryOfEventHash == "" || last.Signer != chain.SignerCSDR {
		t.Fatalf("capture success not reconciled by CSDR: %+v", last)
	}
}

func TestCaptureUnavailableRetriesWithLinkedAttempts(t *testing.T) {
	h := newHarness(t)
	h.faults.Push(acquirer.OpCapture, acquirer.FaultUnavailable, acquirer.FaultUnavailable)
	p := h.pay("order-flaky", 250_00, "tok_visa_ok")
	h.mustState(p, model.StateSettlementPending)

	eqInt(t, "capture calls", h.acq.Calls(acquirer.OpCapture), 3)
	eqInt(t, "capture effects", h.acq.Effects(acquirer.OpCapture), 1)
	evs := h.verify(p.ID)
	ok := latestSuccess(evs, model.StageCapture)
	eqInt(t, "successful capture attempt", ok.Attempt, 3)
	if ok.RetryOfEventHash == "" {
		t.Fatal("retry attempt is not linked to the failed attempt")
	}
	if got := decisions(evs); fmt.Sprint(got) != "[retry retry]" {
		t.Fatalf("decisions = %v", got)
	}
	// Earlier stages were not repeated.
	for _, s := range []model.Stage{model.StageValidate, model.StageAuthenticate, model.StageAuthorize} {
		n := 0
		for _, ev := range evs {
			if ev.Stage == s && ev.Status == model.EventSuccess {
				n++
			}
		}
		eqInt(t, string(s)+" successes", n, 1)
	}
}

func TestIssuerDeclineIsNotRetried(t *testing.T) {
	h := newHarness(t)
	p := h.pay("order-decline", 100_00, "tok_decline_card")
	h.mustState(p, model.StateDeclined)
	if p.FailureCode != model.FailBusinessRejection {
		t.Fatalf("failure code %s", p.FailureCode)
	}
	eqInt(t, "authorize calls", h.acq.Calls(acquirer.OpAuthorize), 1)
	h.verify(p.ID)
}

func TestRiskDeclineStopsBeforeAuthorization(t *testing.T) {
	h := newHarness(t)
	p := h.pay("order-fraud", 100_00, "tok_fraud_card")
	h.mustState(p, model.StateDeclined)
	if p.FailureCode != model.FailRiskDeclined {
		t.Fatalf("failure code %s", p.FailureCode)
	}
	eqInt(t, "authorize calls", h.acq.Calls(acquirer.OpAuthorize), 0)
}

func TestAuthenticationRejectsWrongIdentityAndBadSignature(t *testing.T) {
	h := newHarness(t)
	p, err := h.e.Process(context.Background(), h.request("order-imposter", 100_00, "tok_visa_ok"), "someone-else")
	if err != nil {
		t.Fatal(err)
	}
	h.mustState(p, model.StateDeclined)
	if p.FailureCode != model.FailAuthentication {
		t.Fatalf("failure code %s", p.FailureCode)
	}

	req := h.request("order-forged", 100_00, "tok_visa_ok")
	req.Signature = model.SignRequest(req, "wrong-secret")
	p, err = h.e.Process(context.Background(), req, testPrincipal)
	if err != nil {
		t.Fatal(err)
	}
	h.mustState(p, model.StateDeclined)
	eqInt(t, "authorize calls", h.acq.Calls(acquirer.OpAuthorize), 0)
}

func TestValidationRejectsBeforeFinancialExecution(t *testing.T) {
	h := newHarness(t)
	p := h.pay("order-zero", 0, "tok_visa_ok")
	h.mustState(p, model.StateDeclined)
	if p.FailureCode != model.FailValidation {
		t.Fatalf("failure code %s", p.FailureCode)
	}
	req := h.request("order-pan", 100_00, "4111111111111111")
	p, _ = h.e.Process(context.Background(), req, testPrincipal)
	h.mustState(p, model.StateDeclined)
	eqInt(t, "authorize calls", h.acq.Calls(acquirer.OpAuthorize), 0)
}

func TestAuthorizeRetriesExhaustedFails(t *testing.T) {
	h := newHarness(t)
	h.faults.Push(acquirer.OpAuthorize, acquirer.FaultUnavailable, acquirer.FaultUnavailable,
		acquirer.FaultUnavailable, acquirer.FaultUnavailable)
	p := h.pay("order-down", 100_00, "tok_visa_ok")
	h.mustState(p, model.StateFailed)
	if p.FailureCode != model.FailRetriesExhausted {
		t.Fatalf("failure code %s", p.FailureCode)
	}
	eqInt(t, "authorize calls", h.acq.Calls(acquirer.OpAuthorize), 4)
	eqInt(t, "authorize effects", h.acq.Effects(acquirer.OpAuthorize), 0)
	h.verify(p.ID)
}

func TestCaptureExhaustedCompensatesWithVoid(t *testing.T) {
	h := newHarness(t)
	h.faults.Push(acquirer.OpCapture, acquirer.FaultUnavailable, acquirer.FaultUnavailable,
		acquirer.FaultUnavailable, acquirer.FaultUnavailable)
	p := h.pay("order-nocap", 100_00, "tok_visa_ok")
	h.mustState(p, model.StateCompensated)
	eqInt(t, "void effects", h.acq.Effects(acquirer.OpVoid), 1)
	eqInt(t, "capture effects", h.acq.Effects(acquirer.OpCapture), 0)
	h.verify(p.ID)
}

func TestCrashMidCaptureIsRecoveredOnRestart(t *testing.T) {
	h := newHarness(t)
	var crashed atomic.Bool
	h.e.crashHook = func(s model.Stage) bool { return s == model.StageCapture && crashed.CompareAndSwap(false, true) }
	_, err := h.e.Process(context.Background(), h.request("order-crash", 900_00, "tok_visa_ok"), testPrincipal)
	if !errors.Is(err, errSimulatedCrash) {
		t.Fatalf("want simulated crash, got %v", err)
	}
	p, _ := h.e.GetPaymentByIdempotency(context.Background(), testMerchant, "order-crash")
	h.mustState(p, model.StateCapturing)

	// "Restart": a fresh engine over the same durable store and processor.
	ccfg := controller.DefaultConfig()
	ccfg.BaseBackoff = time.Millisecond
	restarted := New(h.e.cfg, Deps{Store: h.st, Keys: h.keys, Nonces: nonce.New(time.Minute), Acquirer: h.acq,
		Risk: risk.New(risk.DefaultConfig()), Controller: controller.New(ccfg),
		Logger: slog.New(slog.NewTextHandler(io.Discard, nil))})
	if n := restarted.RecoverAll(context.Background()); n != 1 {
		t.Fatalf("recovered %d payments", n)
	}
	p, _ = restarted.GetPayment(context.Background(), p.ID)
	h.mustState(p, model.StateSettlementPending)
	eqInt(t, "capture calls", h.acq.Calls(acquirer.OpCapture), 1)
	eqInt(t, "capture effects", h.acq.Effects(acquirer.OpCapture), 1)
	if d := decisions(h.verify(p.ID)); fmt.Sprint(d) != "[reconciled_existing]" {
		t.Fatalf("decisions %v", d)
	}
}

func TestExpiredAuthorizationIsReauthorized(t *testing.T) {
	var offset atomic.Int64
	h := newHarness(t, func(c *Config, a *acquirer.Config) {
		a.AuthValidity = time.Hour
		a.Now = func() time.Time { return time.Now().Add(time.Duration(offset.Load())) }
		a.Faults = faultFunc(func(op acquirer.Op, _ string) acquirer.Fault {
			if op == acquirer.OpCapture {
				offset.Store(int64(2 * time.Hour)) // capture arrives after the hold expired
			}
			return acquirer.FaultNone
		})
	})
	p := h.pay("order-slow", 300_00, "tok_visa_ok")
	h.mustState(p, model.StateSettlementPending)
	eqInt(t, "authorize effects", h.acq.Effects(acquirer.OpAuthorize), 2)
	eqInt(t, "capture effects", h.acq.Effects(acquirer.OpCapture), 1)
	evs := h.verify(p.ID)
	if d := decisions(evs); fmt.Sprint(d) != "[reauthorize]" {
		t.Fatalf("decisions %v", d)
	}
}

func TestRefundAfterSettlement(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	p := h.pay("order-refund", 400_00, "tok_visa_ok")
	if _, err := h.e.SettleDue(ctx); err != nil {
		t.Fatal(err)
	}
	p, err := h.e.Refund(ctx, p.ID, testMerchant, testPrincipal, "customer returned item")
	if err != nil {
		t.Fatal(err)
	}
	h.mustState(p, model.StateCompensated)
	eqInt(t, "refund effects", h.acq.Effects(acquirer.OpRefund), 1)
	h.verify(p.ID)

	if _, err := h.e.Refund(ctx, p.ID, testMerchant, "intruder", "x"); !errors.Is(err, ErrForbidden) {
		t.Fatalf("want forbidden, got %v", err)
	}
}

func TestRefundBeforeSettlementCancelsOutbox(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	p := h.pay("order-early-refund", 400_00, "tok_visa_ok")
	p, err := h.e.Refund(ctx, p.ID, testMerchant, testPrincipal, "cancelled order")
	if err != nil {
		t.Fatal(err)
	}
	h.mustState(p, model.StateCompensated)
	ob, _ := h.st.GetOutboxByPayment(ctx, p.ID)
	if ob.Status != store.OutboxCancelled {
		t.Fatalf("outbox status %s", ob.Status)
	}
	if n, _ := h.e.SettleDue(ctx); n != 0 {
		t.Fatalf("settled %d after refund", n)
	}
	eqInt(t, "settle effects", h.acq.Effects(acquirer.OpSettle), 0)
}

func TestSettlementLostResponseAndRetry(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	h.faults.Push(acquirer.OpSettle, acquirer.FaultLostResponse)
	p := h.pay("order-settle-lost", 100_00, "tok_visa_ok")
	if n, _ := h.e.SettleDue(ctx); n != 1 {
		t.Fatalf("settled %d", n)
	}
	p, _ = h.e.GetPayment(ctx, p.ID)
	h.mustState(p, model.StateSettled)
	eqInt(t, "settle effects", h.acq.Effects(acquirer.OpSettle), 1)

	h.faults.Push(acquirer.OpSettle, acquirer.FaultUnavailable)
	q := h.pay("order-settle-retry", 100_00, "tok_visa_ok")
	if n, _ := h.e.SettleDue(ctx); n != 0 {
		t.Fatalf("settled %d on unavailable", n)
	}
	q, _ = h.e.GetPayment(ctx, q.ID)
	h.mustState(q, model.StateSettlementPending)
	time.Sleep(30 * time.Millisecond)
	if n, _ := h.e.SettleDue(ctx); n != 1 {
		t.Fatalf("settled %d on retry", n)
	}
	q, _ = h.e.GetPayment(ctx, q.ID)
	h.mustState(q, model.StateSettled)
	h.verify(q.ID)
}

func TestTamperingIsDetectedAndStopsRecovery(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	p := h.pay("order-tamper", 1234_00, "tok_visa_ok")
	if _, err := h.e.AnchorOnce(ctx); err != nil {
		t.Fatal(err)
	}
	db := h.st.DB()
	// A privileged attacker bypasses the append-only trigger and edits history.
	if _, err := db.Exec(`DROP TRIGGER events_append_only_update`); err != nil {
		t.Fatal(err)
	}
	if _, err := db.Exec(`UPDATE payment_stage_events SET payload='{"amount_minor":"1"}' WHERE payment_id=? AND stage='CREATE'`, p.ID); err != nil {
		t.Fatal(err)
	}
	var ie *chain.IntegrityError
	if err := h.e.VerifyPayment(ctx, p.ID); !errors.As(err, &ie) || ie.Code != model.FailHashMismatch {
		t.Fatalf("want hash mismatch, got %v", err)
	}
	// Force the payment into recovery: CSDR must refuse to continue.
	if _, err := db.Exec(`UPDATE payments SET state='UNKNOWN_OUTCOME' WHERE id=?`, p.ID); err != nil {
		t.Fatal(err)
	}
	p, err := h.e.Recover(ctx, p.ID)
	if err != nil {
		t.Fatal(err)
	}
	h.mustState(p, model.StateReconciliationRequired)
	if p.FailureCode != model.FailHashMismatch {
		t.Fatalf("failure code %s", p.FailureCode)
	}
	// The external anchor still detects the rewrite even if hashes were recomputed.
	if _, err := db.Exec(`UPDATE payment_stage_events SET current_hash=? WHERE payment_id=? AND stage='CREATE'`,
		chain.GenesisHash, p.ID); err != nil {
		t.Fatal(err)
	}
	ar, err := h.e.VerifyAnchors(ctx)
	if err != nil || len(ar.Problems) == 0 {
		t.Fatalf("anchor verification missed tampering: %+v %v", ar, err)
	}
}

func TestForgedSignatureIsDetected(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	p := h.pay("order-forge", 100_00, "tok_visa_ok")
	db := h.st.DB()
	if _, err := db.Exec(`DROP TRIGGER events_append_only_update`); err != nil {
		t.Fatal(err)
	}
	// Replace the authorizer's signature with a signature from a key the system does not trust.
	forger := chain.NewEphemeralKeyRing().Signer(chain.SignerAuthorizer)
	evs, _ := h.st.ListEvents(ctx, p.ID)
	target := latestSuccess(evs, model.StageAuthorize)
	forged := *target
	if err := forged.Seal(forger); err != nil {
		t.Fatal(err)
	}
	if _, err := db.Exec(`UPDATE payment_stage_events SET signature=? WHERE event_id=?`, forged.Signature, target.EventID); err != nil {
		t.Fatal(err)
	}
	var ie *chain.IntegrityError
	if err := h.e.VerifyPayment(ctx, p.ID); !errors.As(err, &ie) || ie.Code != model.FailSignatureMismatch {
		t.Fatalf("want signature mismatch, got %v", err)
	}
}

func TestReconciliationFindsDuplicateSettlement(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	p := h.pay("order-recon", 100_00, "tok_visa_ok")
	if _, err := h.e.SettleDue(ctx); err != nil {
		t.Fatal(err)
	}
	p, _ = h.e.GetPayment(ctx, p.ID)
	h.acq.InjectSettlementLine(acquirer.SettlementLine{SettlementID: "stl_dup", CaptureID: p.CaptureID,
		AmountMinor: 100_00, Currency: "INR", At: time.Now()})
	rep, err := h.e.Reconcile(ctx)
	if err != nil {
		t.Fatal(err)
	}
	kinds := map[string]bool{}
	for _, d := range rep.Discrepancies {
		kinds[d.Kind] = true
	}
	if !kinds[ReconDuplicateSettlement] {
		t.Fatalf("duplicate not found: %+v", rep.Discrepancies)
	}
	stored, _ := h.st.ListRecon(ctx, rep.RunID)
	if len(stored) != len(rep.Discrepancies) {
		t.Fatalf("stored %d of %d discrepancies", len(stored), len(rep.Discrepancies))
	}
}

func TestIllegalTransitionIsRejectedByStore(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	p := h.pay("order-fsm", 100_00, "tok_visa_ok")
	prev := p.State
	p.State = model.StateCreated
	err := h.st.WithTx(ctx, func(tx *store.Tx) error { return tx.SavePayment(ctx, p, prev, time.Now()) })
	if err == nil {
		t.Fatal("store accepted SETTLEMENT_PENDING -> CREATED")
	}
}

func TestEventsAreAppendOnly(t *testing.T) {
	h := newHarness(t)
	p := h.pay("order-append", 100_00, "tok_visa_ok")
	if _, err := h.st.DB().Exec(`DELETE FROM payment_stage_events WHERE payment_id=?`, p.ID); err == nil {
		t.Fatal("delete of execution events succeeded")
	}
}
