package engine

import (
	"context"
	"testing"

	"pstcopay/internal/chain"
	"pstcopay/internal/model"
	"pstcopay/internal/store"
)

func TestOfflineEventsAreMerkleAnchored(t *testing.T) {
	h := newHarness(t)
	ctx := context.Background()
	// One online payment and one offline event chain.
	h.pay("order-anchor", 100_00, "tok_visa_ok")
	for i, stage := range []model.Stage{model.StageOfflineReceive, model.StageOfflineVerify} {
		err := h.st.WithTx(ctx, func(tx *store.Tx) error {
			evs, _ := tx.ListOfflineEvents(ctx, "off_test")
			var deps []string
			if i > 0 {
				deps = []string{evs[0].CurrentHash}
			}
			_, err := tx.AppendOfflineEvent(ctx, "off_test", func(prev string, seq int64) (*chain.Event, error) {
				ev := &chain.Event{EventID: "oev" + string(rune('a'+i)), PaymentID: "off_test", Seq: seq, Stage: stage,
					Attempt: 1, Status: model.EventSuccess, PreviousEventHash: prev, DependencyHashes: deps,
					WorkflowVersion: chain.WorkflowVersion, CreatedAt: int64(i + 1)}
				return ev, ev.Seal(h.keys.Signer(chain.SignerOffline))
			})
			return err
		})
		if err != nil {
			t.Fatal(err)
		}
	}
	as, err := h.e.AnchorAll(ctx)
	if err != nil || len(as) != 2 || as[1].Log != store.LogOffline || as[1].Count != 2 {
		t.Fatalf("anchors %+v %v", as, err)
	}
	if rep, _ := h.e.VerifyAnchors(ctx); len(rep.Problems) != 0 {
		t.Fatalf("clean anchors reported problems: %v", rep.Problems)
	}
	// Rewriting an offline event is caught by the external anchor.
	if _, err := h.st.DB().Exec(`DROP TRIGGER offline_events_append_only_update`); err != nil {
		t.Fatal(err)
	}
	if _, err := h.st.DB().Exec(`UPDATE offline_events SET current_hash=? WHERE event_id='oeva'`, chain.GenesisHash); err != nil {
		t.Fatal(err)
	}
	rep, _ := h.e.VerifyAnchors(ctx)
	if len(rep.Problems) == 0 {
		t.Fatal("tampered offline event not detected by its anchor")
	}
}
