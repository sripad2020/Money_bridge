package chain

import (
	"slices"

	"pstcopay/internal/model"
)

// RequiredDeps lists, per stage, the stages whose SUCCESS events an event of
// that stage must reference in dependency_hashes.
var RequiredDeps = map[model.Stage][]model.Stage{
	model.StageCreate:       nil,
	model.StageValidate:     {model.StageCreate},
	model.StageAuthenticate: {model.StageValidate},
	model.StageRisk:         {model.StageValidate},
	model.StageAuthorize:    {model.StageAuthenticate, model.StageRisk},
	model.StageCapture:      {model.StageAuthorize},
	model.StageSettle:       {model.StageCapture},
	model.StageVoid:         {model.StageAuthorize},
	model.StageRefund:       {model.StageCapture},
	model.StageRecovery:     nil,

	model.StageOfflineReceive: nil,
	model.StageOfflineVerify:  {model.StageOfflineReceive},
	model.StageOfflineSettle:  {model.StageOfflineVerify},
}

// allowedSigners binds each stage to the services permitted to sign it.
var allowedSigners = map[model.Stage][]string{
	model.StageCreate:       {SignerOrchestrator},
	model.StageValidate:     {SignerValidator},
	model.StageAuthenticate: {SignerAuthenticator},
	model.StageRisk:         {SignerRisk},
	model.StageAuthorize:    {SignerAuthorizer, SignerCSDR},
	model.StageCapture:      {SignerCapturer, SignerCSDR},
	model.StageSettle:       {SignerSettlement},
	model.StageVoid:         {SignerCompensator, SignerCSDR},
	model.StageRefund:       {SignerCompensator, SignerCSDR},
	model.StageRecovery:     {SignerCSDR},

	model.StageOfflineReceive: {SignerOffline},
	model.StageOfflineVerify:  {SignerOffline},
	model.StageOfflineSettle:  {SignerOffline},
}

var supportedWorkflows = map[string]bool{WorkflowVersion: true}

func signerAllowed(stage model.Stage, signer string) bool {
	return slices.Contains(allowedSigners[stage], signer)
}

// VerifyGraph verifies a payment's complete execution graph: contiguous
// sequence, previous-hash links, per-event hashes and signatures, workflow
// version, dependency edges and retry edges. Events must be ordered by Seq.
func VerifyGraph(events []*Event, v Verifier) error {
	byHash := make(map[string]*Event, len(events))
	for i, ev := range events {
		if ev.Seq != int64(i+1) {
			return integrity(model.FailHashMismatch, ev, "sequence gap: expected %d", i+1)
		}
		wantPrev := GenesisHash
		if i > 0 {
			wantPrev = events[i-1].CurrentHash
		}
		if ev.PreviousEventHash != wantPrev {
			return integrity(model.FailHashMismatch, ev, "previous_event_hash does not link to seq %d", i)
		}
		if !supportedWorkflows[ev.WorkflowVersion] {
			return integrity(model.FailDependencyInvalid, ev, "unsupported workflow %q", ev.WorkflowVersion)
		}
		if err := ev.VerifySelf(v); err != nil {
			return err
		}
		for _, d := range ev.DependencyHashes {
			if _, ok := byHash[d]; !ok {
				return integrity(model.FailDependencyInvalid, ev, "dependency %s is not an earlier event", short(d))
			}
		}
		for _, need := range RequiredDeps[ev.Stage] {
			found := false
			for _, d := range ev.DependencyHashes {
				if dep := byHash[d]; dep.Stage == need && dep.Status == model.EventSuccess {
					found = true
					break
				}
			}
			if !found {
				return integrity(model.FailDependencyInvalid, ev, "missing successful %s dependency", need)
			}
		}
		if ev.Stage == model.StageRecovery && len(ev.DependencyHashes) == 0 {
			return integrity(model.FailDependencyInvalid, ev, "recovery event must reference the failed event")
		}
		if ev.RetryOfEventHash != "" {
			orig, ok := byHash[ev.RetryOfEventHash]
			if !ok {
				return integrity(model.FailDependencyInvalid, ev, "retry_of is not an earlier event")
			}
			if orig.Stage != ev.Stage || orig.Status == model.EventSuccess {
				return integrity(model.FailDependencyInvalid, ev, "retry_of must reference an unsuccessful %s event", ev.Stage)
			}
		}
		byHash[ev.CurrentHash] = ev
	}
	return nil
}

func short(h string) string {
	if len(h) > 12 {
		return h[:12]
	}
	return h
}
