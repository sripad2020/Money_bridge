package engine

import (
	"context"
	"errors"
	"fmt"
	"regexp"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	"pstcopay/internal/acquirer"
	"pstcopay/internal/chain"
	"pstcopay/internal/model"
	"pstcopay/internal/risk"
	"pstcopay/internal/store"
)

var (
	idPattern    = regexp.MustCompile(`^[A-Za-z0-9_.:-]{1,128}$`)
	tokenPattern = regexp.MustCompile(`^tok_[A-Za-z0-9_]{3,64}$`)
	sigPattern   = regexp.MustCompile(`^[0-9a-f]{64}$`)
)

// Process runs a new payment through the synchronous fast path:
// validation, parallel authentication and risk, authorization and capture.
// Settlement continues asynchronously from the durable outbox.
//
// Process is idempotent on (merchant, idempotency key): a repeated request
// returns the existing payment, resuming it through CSDR if it is unfinished.
func (e *Engine) Process(ctx context.Context, req *model.PaymentRequest, principal string) (*model.Payment, error) {
	if !idPattern.MatchString(req.MerchantID) || !idPattern.MatchString(req.IdempotencyKey) {
		return nil, fmt.Errorf("%w: merchant_id and idempotency_key are required", ErrInvalidRequest)
	}
	if p, err := e.store.GetPaymentByIdempotency(ctx, req.MerchantID, req.IdempotencyKey); err == nil {
		return e.replay(ctx, p, req)
	} else if !errors.Is(err, store.ErrNotFound) {
		return nil, err
	}

	budget := e.cfg.DefaultDeadline
	if req.DeadlineMS > 0 {
		budget = min(time.Duration(req.DeadlineMS)*time.Millisecond, e.cfg.MaxDeadline)
	}
	deadline := time.Now().Add(budget)
	release, err := e.ctl.Admit(deadline)
	if err != nil {
		e.metrics.Admission("rejected")
		return nil, err
	}
	defer release()
	e.metrics.Admission("admitted")
	ctx, cancel := context.WithDeadline(ctx, deadline)
	defer cancel()

	now := e.now()
	p := &model.Payment{
		ID: newID("pay"), MerchantID: req.MerchantID, CustomerID: req.CustomerID,
		IdempotencyKey: req.IdempotencyKey, RequestHash: req.Fingerprint(),
		AmountMinor: req.AmountMinor, Currency: strings.ToUpper(req.Currency), CardToken: req.CardToken,
		ClientTime: req.ClientTime.UTC(), ExpiresAt: req.ExpiresAt.UTC(), DeadlineMS: budget.Milliseconds(),
		Signature: req.Signature, Principal: principal, State: model.StateCreated,
		CreatedAt: now, UpdatedAt: now,
	}
	unlock, err := e.locks.Lock(ctx, p.ID)
	if err != nil {
		return nil, err
	}
	defer unlock()

	// Creation and validation commit together: validation is pure, so one
	// durable commit records both the CREATE and VALIDATE events.
	valStart := time.Now()
	problems := e.validationErrors(p)
	err = e.persist(ctx, func(tx *store.Tx) error {
		if err := tx.InsertPayment(ctx, p); err != nil {
			return err
		}
		created, err := e.appendEvent(ctx, tx, p.ID, evSpec{
			stage: model.StageCreate, status: model.EventSuccess, signer: chain.SignerOrchestrator,
			payload: map[string]string{
				"merchant_id": p.MerchantID, "customer_id": p.CustomerID,
				"amount_minor": strconv.FormatInt(p.AmountMinor, 10), "currency": p.Currency,
				"request_hash": p.RequestHash, "principal": principal,
				"deadline_ms": strconv.FormatInt(p.DeadlineMS, 10),
			},
		})
		if err != nil {
			return err
		}
		return e.validateTx(ctx, tx, p, created, 1, "", problems)
	})
	if err == nil {
		e.metrics.StageObserved(string(model.StageValidate), statusLabel(len(problems) == 0), time.Since(valStart))
	}
	if errors.Is(err, store.ErrDuplicate) {
		existing, gerr := e.store.GetPaymentByIdempotency(ctx, req.MerchantID, req.IdempotencyKey)
		if gerr != nil {
			return nil, gerr
		}
		return e.replay(ctx, existing, req)
	}
	if err != nil {
		return nil, err
	}
	e.notify(p)

	start := time.Now()
	p, err = e.drive(ctx, p)
	e.metrics.PaymentFinished(string(p.State), time.Since(start))
	return p, err
}

// replay answers a repeated request with the existing payment.
func (e *Engine) replay(ctx context.Context, p *model.Payment, req *model.PaymentRequest) (*model.Payment, error) {
	if p.RequestHash != req.Fingerprint() {
		return nil, ErrIdempotencyConflict
	}
	if p.State.Terminal() {
		return p, nil
	}
	return e.Recover(ctx, p.ID)
}

// drive advances a payment through the state machine until it reaches a
// terminal state, hands off to settlement, or cannot make progress now.
// The caller must hold the payment lock.
func (e *Engine) drive(ctx context.Context, p *model.Payment) (*model.Payment, error) {
	for range 64 {
		if ctx.Err() != nil {
			return p, nil // deadline spent: background recovery resumes the payment
		}
		prev, prevVersion := p.State, p.Version
		var err error
		switch p.State {
		case model.StateCreated:
			err = e.validate(ctx, p)
		case model.StateValidated:
			err = e.authenticateAndAssess(ctx, p)
		case model.StateRiskPending:
			err = e.authorize(ctx, p, chain.SignerAuthorizer)
		case model.StateAuthorized:
			err = e.capture(ctx, p, chain.SignerCapturer)
		case model.StateCaptured:
			err = e.enqueueSettlement(ctx, p)
		case model.StateCompensating:
			err = e.continueCompensation(ctx, p)
		default:
			if p.State.NeedsRecovery() {
				err = e.recoverLocked(ctx, p)
			} else {
				return p, nil
			}
		}
		if errors.Is(err, errDeferred) {
			return e.reload(ctx, p), nil
		}
		if err != nil {
			return e.reload(ctx, p), err
		}
		if p.State == prev && p.Version == prevVersion {
			return p, nil // no progress possible right now
		}
		if p.State == prev && p.State == model.StateCompensating {
			return p, nil // compensation attempt failed softly; retry later with backoff
		}
	}
	return p, nil
}

// ---------------------------------------------------------------- validate

func (e *Engine) validationErrors(p *model.Payment) []string {
	var errs []string
	now := e.now()
	if p.AmountMinor <= 0 {
		errs = append(errs, "amount must be positive")
	}
	if p.AmountMinor > e.cfg.MaxAmountMinor {
		errs = append(errs, "amount exceeds system maximum")
	}
	if !slices.Contains(e.cfg.SupportedCurrencies, p.Currency) {
		errs = append(errs, "unsupported currency "+p.Currency)
	}
	if !idPattern.MatchString(p.CustomerID) {
		errs = append(errs, "invalid customer_id")
	}
	if !tokenPattern.MatchString(p.CardToken) {
		errs = append(errs, "card must be a token (tok_...), raw card numbers are not accepted")
	}
	if p.ClientTime.IsZero() || p.ClientTime.Sub(now).Abs() > e.cfg.ClockSkew {
		errs = append(errs, "client timestamp outside allowed clock skew")
	}
	if !p.ExpiresAt.After(now) {
		errs = append(errs, "payment request already expired")
	}
	if p.ExpiresAt.Sub(p.ClientTime) > e.cfg.MaxPaymentTTL {
		errs = append(errs, "payment expiry too far in the future")
	}
	if !sigPattern.MatchString(p.Signature) {
		errs = append(errs, "missing or malformed request signature")
	}
	return errs
}

// validateTx records the validation outcome inside the caller's transaction.
func (e *Engine) validateTx(ctx context.Context, tx *store.Tx, p *model.Payment, created *chain.Event,
	attempt int, retryOf string, problems []string) error {
	if err := e.move(ctx, tx, p, model.StateValidating); err != nil {
		return err
	}
	spec := evSpec{stage: model.StageValidate, attempt: attempt, retryOf: retryOf,
		deps: hashes(created), signer: chain.SignerValidator, status: model.EventSuccess,
		payload: map[string]string{"checks": "amount,currency,identifiers,token,timestamp,expiry,signature_format"}}
	if len(problems) > 0 {
		spec.status = model.EventHardFail
		spec.payload["failure_code"] = string(model.FailValidation)
		spec.payload["reason"] = strings.Join(problems, "; ")
	}
	if _, err := e.appendEvent(ctx, tx, p.ID, spec); err != nil {
		return err
	}
	if len(problems) > 0 {
		p.FailureCode, p.FailureReason = model.FailValidation, strings.Join(problems, "; ")
		return e.move(ctx, tx, p, model.StateDeclined)
	}
	return e.move(ctx, tx, p, model.StateValidated)
}

// validate handles a payment found in CREATED (only reachable if a future
// change splits creation from validation).
func (e *Engine) validate(ctx context.Context, p *model.Payment) error {
	start := time.Now()
	problems := e.validationErrors(p)
	err := e.persist(ctx, func(tx *store.Tx) error {
		events, err := tx.ListEvents(ctx, p.ID)
		if err != nil {
			return err
		}
		attempt, retryOf := nextAttempt(events, model.StageValidate)
		return e.validateTx(ctx, tx, p, latestSuccess(events, model.StageCreate), attempt, retryOf, problems)
	})
	e.metrics.StageObserved(string(model.StageValidate), statusLabel(len(problems) == 0), time.Since(start))
	if err == nil {
		e.notify(p)
	}
	return err
}

// ------------------------------------------------- authenticate + risk

type authResult struct {
	ok     bool
	soft   bool
	code   model.FailureCode
	reason string
}

func (e *Engine) authenticate(ctx context.Context, p *model.Payment) authResult {
	m, err := e.merchant(ctx, p.MerchantID)
	switch {
	case errors.Is(err, store.ErrNotFound):
		return authResult{code: model.FailAuthentication, reason: "unknown merchant"}
	case err != nil:
		return authResult{soft: true, code: model.FailInternal, reason: "merchant lookup: " + err.Error()}
	case !m.Active:
		return authResult{code: model.FailMerchantDisabled, reason: "merchant disabled"}
	case p.Principal != m.Principal:
		return authResult{code: model.FailAuthentication,
			reason: fmt.Sprintf("mTLS identity %q is not allowed to act for merchant %s", p.Principal, m.ID)}
	case !model.VerifyRequestSignature(p.Request(), m.Secret):
		return authResult{code: model.FailAuthentication, reason: "request signature invalid"}
	case p.AmountMinor > m.MaxAmountMinor:
		return authResult{code: model.FailAuthentication, reason: "amount exceeds merchant limit"}
	}
	return authResult{ok: true}
}

// authenticateAndAssess runs authentication and risk assessment in parallel:
// both depend only on validation, and authorization waits for both.
func (e *Engine) authenticateAndAssess(ctx context.Context, p *model.Payment) error {
	events, err := e.store.ListEvents(ctx, p.ID)
	if err != nil {
		return err
	}
	validated := latestSuccess(events, model.StageValidate)

	var (
		wg               sync.WaitGroup
		auth             authResult
		assessment       risk.Assessment
		authDur, riskDur time.Duration
	)
	wg.Add(2)
	go func() {
		defer wg.Done()
		t := time.Now()
		auth = e.authenticate(ctx, p)
		authDur = time.Since(t)
	}()
	go func() {
		defer wg.Done()
		t := time.Now()
		assessment = e.risk.Assess(p)
		riskDur = time.Since(t)
	}()
	wg.Wait()
	e.metrics.StageObserved(string(model.StageAuthenticate), statusLabel(auth.ok), authDur)
	e.metrics.StageObserved(string(model.StageRisk), string(assessment.Decision), riskDur)

	err = e.persist(ctx, func(tx *store.Tx) error {
		if err := e.move(ctx, tx, p, model.StateAuthenticating); err != nil {
			return err
		}
		aAttempt, aRetry := nextAttempt(events, model.StageAuthenticate)
		aSpec := evSpec{stage: model.StageAuthenticate, attempt: aAttempt, retryOf: aRetry,
			deps: hashes(validated), signer: chain.SignerAuthenticator, status: model.EventSuccess,
			payload: map[string]string{"principal": p.Principal, "method": "mtls+hmac-sha256"}}
		switch {
		case auth.soft:
			aSpec.status = model.EventSoftFail
		case !auth.ok:
			aSpec.status = model.EventHardFail
		}
		if !auth.ok {
			aSpec.payload["failure_code"], aSpec.payload["reason"] = string(auth.code), auth.reason
		}
		if _, err := e.appendEvent(ctx, tx, p.ID, aSpec); err != nil {
			return err
		}

		rAttempt, rRetry := nextAttempt(events, model.StageRisk)
		rSpec := evSpec{stage: model.StageRisk, attempt: rAttempt, retryOf: rRetry,
			deps: hashes(validated), signer: chain.SignerRisk, status: model.EventSuccess,
			payload: map[string]string{
				"score": strconv.FormatFloat(assessment.Score, 'f', 3, 64), "decision": string(assessment.Decision),
				"reasons":     strings.Join(assessment.Reasons, "; "),
				"valid_until": assessment.At.Add(e.risk.Validity()).Format(time.RFC3339Nano),
			}}
		if assessment.Decision == risk.Decline {
			rSpec.status = model.EventHardFail
			rSpec.payload["failure_code"] = string(model.FailRiskDeclined)
		}
		if _, err := e.appendEvent(ctx, tx, p.ID, rSpec); err != nil {
			return err
		}
		p.RiskScore, p.RiskDecision = assessment.Score, string(assessment.Decision)
		if assessment.Decision != risk.Decline {
			p.RiskApprovedAt = assessment.At.UTC()
		}

		switch {
		case auth.soft:
			p.FailureCode, p.FailureReason = auth.code, auth.reason
			return e.move(ctx, tx, p, model.StateSoftFailure)
		case !auth.ok:
			p.FailureCode, p.FailureReason = auth.code, auth.reason
			return e.move(ctx, tx, p, model.StateDeclined)
		}
		if err := e.move(ctx, tx, p, model.StateAuthenticated); err != nil {
			return err
		}
		if err := e.move(ctx, tx, p, model.StateRiskPending); err != nil {
			return err
		}
		if assessment.Decision == risk.Decline {
			p.FailureCode, p.FailureReason = model.FailRiskDeclined, strings.Join(assessment.Reasons, "; ")
			return e.move(ctx, tx, p, model.StateDeclined)
		}
		return nil
	})
	if err == nil {
		e.notify(p)
	}
	return err
}

// --------------------------------------------------------- downstream ops

// dsOp describes one downstream financial operation attempt.
type dsOp struct {
	stage      model.Stage
	op         acquirer.Op
	inProgress model.State // state while the call is outstanding
	softState  model.State // state after a no-effect failure ("" = stay)
	unknown    model.State // state after an unknown outcome ("" = stay)
	key        string      // stable idempotency key of the logical operation
	attempt    int
	retryOf    string
	deps       []string
	signer     string
	keepFail   bool // compensation keeps the failure that caused it
	prepare    func(p *model.Payment)
	call       func(ctx context.Context) (*acquirer.Result, error)
	onSuccess  func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error
	onDecline  func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error
}

// classify maps a downstream error to an event status and failure code.
func classify(err error) (model.EventStatus, model.FailureCode) {
	var dec *acquirer.DeclineError
	switch {
	case err == nil:
		return model.EventSuccess, model.FailNone
	case errors.As(err, &dec):
		return model.EventHardFail, model.FailBusinessRejection
	case errors.Is(err, acquirer.ErrTimeout), errors.Is(err, context.DeadlineExceeded):
		return model.EventSoftFail, model.FailResponseTimeout
	case errors.Is(err, acquirer.ErrUnavailable):
		return model.EventSoftFail, model.FailServiceUnavailable
	case errors.Is(err, acquirer.ErrAuthExpired):
		return model.EventSoftFail, model.FailAuthExpired
	}
	return model.EventSoftFail, model.FailInternal
}

// runDownstream executes one attempt: it durably records the intent (PENDING
// event, idempotency record, nonce reference) before calling downstream, then
// records the outcome. A crash between the two leaves a PENDING event that
// CSDR resolves by querying the processor with the same idempotency key.
func (e *Engine) runDownstream(ctx context.Context, p *model.Payment, op dsOp) error {
	scope := fmt.Sprintf("%s:%s:%d", p.ID, op.stage, op.attempt)
	nonceValue, nonceRef, err := e.nonces.Issue(ctx, scope)
	if err != nil {
		return fmt.Errorf("issue execution nonce: %w", err) // nothing recorded or executed yet
	}
	timeout := e.ctl.StageTimeout(string(op.op), deadlineOf(ctx))

	var pending *chain.Event
	err = e.persist(ctx, func(tx *store.Tx) error {
		if p.State != op.inProgress {
			if err := e.move(ctx, tx, p, op.inProgress); err != nil {
				return err
			}
		}
		if op.prepare != nil {
			op.prepare(p)
			if err := tx.SavePayment(ctx, p, p.State, e.now()); err != nil {
				return err
			}
		}
		if err := tx.PutIdempotency(ctx, &store.IdemRecord{OpKey: op.key, PaymentID: p.ID,
			Operation: string(op.op), Status: store.IdemStarted}, e.now()); err != nil {
			return err
		}
		var err error
		pending, err = e.appendEvent(ctx, tx, p.ID, evSpec{
			stage: op.stage, attempt: op.attempt, status: model.EventPending, deps: op.deps,
			retryOf: op.retryOf, idemKey: op.key, nonceRef: nonceRef, signer: op.signer,
			payload: map[string]string{"operation": string(op.op), "timeout_ms": strconv.FormatInt(timeout.Milliseconds(), 10)},
		})
		return err
	})
	if err != nil {
		return err
	}
	e.notify(p)

	var res *acquirer.Result
	var callErr error
	start := time.Now()
	if err := e.nonces.Consume(ctx, nonceValue, scope); err != nil {
		callErr = fmt.Errorf("execution authorization rejected: %w", err)
	} else {
		cctx, cancel := context.WithTimeout(ctx, timeout)
		res, callErr = op.call(cctx)
		cancel()
	}
	d := time.Since(start)
	if e.crashHook != nil && e.crashHook(op.stage) {
		return errSimulatedCrash
	}
	status, code := classify(callErr)
	e.ctl.Observe(string(op.op), d, status == model.EventSoftFail)
	e.ctl.ObserveRTT(d)
	e.metrics.StageObserved(string(op.stage), string(status), d)

	err = e.persist(ctx, func(tx *store.Tx) error {
		payload := map[string]string{
			"operation": string(op.op), "latency_us": strconv.FormatInt(d.Microseconds(), 10),
			"completes": pending.CurrentHash,
		}
		if res != nil {
			payload["downstream_ref"] = res.Ref
		}
		if callErr != nil {
			payload["failure_code"], payload["reason"] = string(code), callErr.Error()
		}
		if _, err := e.appendEvent(ctx, tx, p.ID, evSpec{
			stage: op.stage, attempt: op.attempt, status: status,
			deps: append(slices.Clone(op.deps), pending.CurrentHash), retryOf: op.retryOf,
			idemKey: op.key, nonceRef: nonceRef, signer: op.signer, payload: payload,
		}); err != nil {
			return err
		}
		rec := &store.IdemRecord{OpKey: op.key, PaymentID: p.ID, Operation: string(op.op)}
		switch {
		case status == model.EventSuccess:
			rec.Status, rec.DownstreamRef = store.IdemCompleted, res.Ref
		case status == model.EventHardFail:
			rec.Status = store.IdemDeclined
		case code == model.FailResponseTimeout:
			rec.Status = store.IdemUnknown
		default:
			rec.Status = store.IdemFailedNoEffect
		}
		if err := tx.PutIdempotency(ctx, rec, e.now()); err != nil {
			return err
		}

		setFailure := func(c model.FailureCode, reason string) {
			if !op.keepFail {
				p.FailureCode, p.FailureReason = c, reason
			}
		}
		switch {
		case status == model.EventSuccess:
			setFailure(model.FailNone, "")
			return op.onSuccess(ctx, tx, p, res)
		case status == model.EventHardFail:
			setFailure(code, callErr.Error())
			return op.onDecline(ctx, tx, p, res)
		}
		setFailure(code, callErr.Error())
		next := op.softState
		if code == model.FailResponseTimeout {
			next = op.unknown
		}
		if next == "" || next == p.State {
			return tx.SavePayment(ctx, p, p.State, e.now())
		}
		return e.move(ctx, tx, p, next)
	})
	if err == nil {
		e.notify(p)
	}
	return err
}

// authorize runs an authorization attempt. A new authorization key is used
// only for re-authorization after expiry; retries reuse the same key.
func (e *Engine) authorize(ctx context.Context, p *model.Payment, signer string) error {
	return e.authorizeWithKey(ctx, p, signer, "")
}

func (e *Engine) authorizeWithKey(ctx context.Context, p *model.Payment, signer, newKey string) error {
	events, err := e.store.ListEvents(ctx, p.ID)
	if err != nil {
		return err
	}
	authn, rk := latestSuccess(events, model.StageAuthenticate), latestSuccess(events, model.StageRisk)
	attempt, retryOf := nextAttempt(events, model.StageAuthorize)
	key := p.AuthKey
	if newKey != "" {
		key = newKey
	}
	if key == "" {
		key = p.ID + ":authorize"
	}
	return e.runDownstream(ctx, p, dsOp{
		stage: model.StageAuthorize, op: acquirer.OpAuthorize, inProgress: model.StateAuthorizing,
		softState: model.StateSoftFailure, unknown: model.StateUnknownOutcome,
		key: key, attempt: attempt, retryOf: retryOf, deps: hashes(authn, rk), signer: signer,
		prepare: func(p *model.Payment) { p.AuthKey = key },
		call: func(c context.Context) (*acquirer.Result, error) {
			return e.acq.Authorize(c, key, p.CardToken, p.AmountMinor, p.Currency)
		},
		onSuccess: func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
			p.AuthID, p.AuthorizedAt = r.Ref, r.At.UTC()
			return e.move(ctx, tx, p, model.StateAuthorized)
		},
		onDecline: func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
			if r != nil {
				p.FailureReason = fmt.Sprintf("issuer declined %s: %s", r.DeclineCode, r.Reason)
			}
			return e.move(ctx, tx, p, model.StateDeclined)
		},
	})
}

// capture runs a capture attempt and, on success, commits the settlement
// outbox entry in the same transaction as the CAPTURED state.
func (e *Engine) capture(ctx context.Context, p *model.Payment, signer string) error {
	events, err := e.store.ListEvents(ctx, p.ID)
	if err != nil {
		return err
	}
	auth := latestSuccess(events, model.StageAuthorize)
	attempt, retryOf := nextAttempt(events, model.StageCapture)
	key := p.ID + ":capture"
	return e.runDownstream(ctx, p, dsOp{
		stage: model.StageCapture, op: acquirer.OpCapture, inProgress: model.StateCapturing,
		softState: model.StateSoftFailure, unknown: model.StateUnknownOutcome,
		key: key, attempt: attempt, retryOf: retryOf, deps: hashes(auth), signer: signer,
		call: func(c context.Context) (*acquirer.Result, error) {
			return e.acq.Capture(c, key, p.AuthID, p.AmountMinor)
		},
		onSuccess: func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
			return e.applyCaptured(ctx, tx, p, r)
		},
		onDecline: func(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
			if r != nil {
				p.FailureReason = fmt.Sprintf("capture declined %s: %s", r.DeclineCode, r.Reason)
			}
			return e.move(ctx, tx, p, model.StateCompensating)
		},
	})
}

// applyCaptured moves a payment to CAPTURED and SETTLEMENT_PENDING and writes
// the settlement outbox row, all inside the caller's transaction.
func (e *Engine) applyCaptured(ctx context.Context, tx *store.Tx, p *model.Payment, r *acquirer.Result) error {
	p.CaptureID, p.CapturedAt = r.Ref, r.At.UTC()
	if err := e.move(ctx, tx, p, model.StateCaptured); err != nil {
		return err
	}
	if err := tx.InsertOutbox(ctx, &store.OutboxItem{PaymentID: p.ID, CaptureID: p.CaptureID,
		AmountMinor: p.AmountMinor, Currency: p.Currency}, e.now()); err != nil && !errors.Is(err, store.ErrDuplicate) {
		return err
	}
	return e.move(ctx, tx, p, model.StateSettlementPending)
}

// enqueueSettlement handles a payment found in CAPTURED (not normally
// reachable, since capture commits straight to SETTLEMENT_PENDING).
func (e *Engine) enqueueSettlement(ctx context.Context, p *model.Payment) error {
	err := e.persist(ctx, func(tx *store.Tx) error {
		if err := tx.InsertOutbox(ctx, &store.OutboxItem{PaymentID: p.ID, CaptureID: p.CaptureID,
			AmountMinor: p.AmountMinor, Currency: p.Currency}, e.now()); err != nil && !errors.Is(err, store.ErrDuplicate) {
			return err
		}
		return e.move(ctx, tx, p, model.StateSettlementPending)
	})
	if err == nil {
		e.notify(p)
	}
	return err
}

func statusLabel(ok bool) string {
	if ok {
		return string(model.EventSuccess)
	}
	return string(model.EventHardFail)
}
