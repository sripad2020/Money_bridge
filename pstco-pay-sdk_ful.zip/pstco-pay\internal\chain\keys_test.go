package chain

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
)

func TestKeyFileEncryptedAtRest(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "service-keys.json")

	// A plaintext key file is migrated to sealed on first use with a passphrase.
	plain, err := LoadOrCreateKeyRing(path)
	if err != nil {
		t.Fatal(err)
	}
	k, err := LoadOrCreateKeyRingWith(path, "correct horse battery staple")
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(k.PublicKey(SignerOfflineCA), plain.PublicKey(SignerOfflineCA)) {
		t.Fatal("keys changed during migration")
	}
	raw, _ := os.ReadFile(path)
	if !bytes.Contains(raw, []byte(`"sealed":true`)) || bytes.Contains(raw, []byte(SignerOfflineCA)) {
		t.Fatalf("key file is not sealed: %.80s", raw)
	}
	if _, err := LoadOrCreateKeyRingWith(path, "wrong"); err == nil {
		t.Fatal("wrong passphrase accepted")
	}
	if _, err := LoadOrCreateKeyRing(path); err == nil {
		t.Fatal("sealed file opened without a passphrase")
	}
	again, err := LoadOrCreateKeyRingWith(path, "correct horse battery staple")
	if err != nil || !bytes.Equal(again.PublicKey(SignerAnchor), k.PublicKey(SignerAnchor)) {
		t.Fatalf("reload: %v", err)
	}
	if !bytes.Equal(again.DeriveKey("x"), k.DeriveKey("x")) || bytes.Equal(k.DeriveKey("x"), k.DeriveKey("y")) {
		t.Fatal("derived keys are not deterministic per purpose")
	}
}
