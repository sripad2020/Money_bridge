package transport

import (
	"context"
	"log/slog"
	"net"
	"sync"
	"time"

	"pstcopay/internal/controller"
)

// TCPStats is one kernel TCP_INFO sample.
type TCPStats struct {
	RTT          time.Duration
	RTTVar       time.Duration
	TotalRetrans uint32
	CongWindow   uint32
}

// Listener accepts persistent TCP connections, applies the configured
// congestion-control algorithm and low-latency socket options, and tracks
// live connections so the sampler can feed transport state to the controller.
type Listener struct {
	net.Listener
	cc  string
	ctl *controller.Controller
	log *slog.Logger

	mu       sync.Mutex
	conns    map[*trackedConn]struct{}
	ccWarned bool
}

// Listen opens a TCP listener. cc is "bbr", "cubic" or "" for the OS default.
func Listen(addr, cc string, ctl *controller.Controller, log *slog.Logger) (*Listener, error) {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return nil, err
	}
	return &Listener{Listener: ln, cc: cc, ctl: ctl, log: log, conns: map[*trackedConn]struct{}{}}, nil
}

type trackedConn struct {
	*net.TCPConn
	l       *Listener
	once    sync.Once
	retrans uint32
}

func (c *trackedConn) Close() error {
	c.once.Do(func() {
		c.l.mu.Lock()
		delete(c.l.conns, c)
		c.l.mu.Unlock()
		c.l.ctl.ConnClosed()
	})
	return c.TCPConn.Close()
}

// Accept implements net.Listener.
func (l *Listener) Accept() (net.Conn, error) {
	c, err := l.Listener.Accept()
	if err != nil {
		return nil, err
	}
	tc, ok := c.(*net.TCPConn)
	if !ok {
		return c, nil
	}
	_ = tc.SetNoDelay(true)
	_ = tc.SetKeepAlive(true)
	_ = tc.SetKeepAlivePeriod(30 * time.Second)
	if l.cc != "" {
		if err := SetCongestion(tc, l.cc); err != nil {
			l.mu.Lock()
			if !l.ccWarned {
				l.ccWarned = true
				l.log.Warn("congestion control not applied", "algorithm", l.cc, "err", err)
			}
			l.mu.Unlock()
		}
	}
	t := &trackedConn{TCPConn: tc, l: l}
	l.mu.Lock()
	l.conns[t] = struct{}{}
	l.mu.Unlock()
	l.ctl.ConnOpened()
	return t, nil
}

// Sample reads TCP_INFO from every live connection and feeds the controller.
func (l *Listener) Sample() {
	l.mu.Lock()
	conns := make([]*trackedConn, 0, len(l.conns))
	for c := range l.conns {
		conns = append(conns, c)
	}
	l.mu.Unlock()

	s := controller.TransportSample{ActiveConns: len(conns), Congestion: l.cc}
	if s.Congestion == "" || !TCPInfoSupported {
		s.Congestion = "os-default" // selecting BBR/CUBIC is a Linux kernel feature
	}
	var rttSum, varSum time.Duration
	var n int
	for _, c := range conns {
		st, err := ReadTCPInfo(c.TCPConn)
		if err != nil {
			continue
		}
		n++
		rttSum += st.RTT
		varSum += st.RTTVar
		if st.TotalRetrans > c.retrans {
			s.Retransmits += st.TotalRetrans - c.retrans
		}
		c.retrans = st.TotalRetrans
		s.CongWindow = max(s.CongWindow, st.CongWindow)
		if cc, err := GetCongestion(c.TCPConn); err == nil {
			s.Congestion = cc
		}
	}
	if n == 0 {
		s.Unsupported = true // no kernel sample this round (no conns, or not Linux)
	} else {
		s.RTT, s.RTTVar = rttSum/time.Duration(n), varSum/time.Duration(n)
	}
	l.ctl.UpdateTransport(s)
}

// RunSampler samples transport telemetry until ctx ends.
func (l *Listener) RunSampler(ctx context.Context, every time.Duration) {
	t := time.NewTicker(every)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			l.Sample()
		}
	}
}

// Dialer returns a dialer that applies the congestion-control algorithm and
// low-latency options to outbound connections.
func Dialer(cc string) func(ctx context.Context, addr string) (net.Conn, error) {
	return func(ctx context.Context, addr string) (net.Conn, error) {
		d := net.Dialer{KeepAlive: 30 * time.Second, Control: DialControl(cc)}
		c, err := d.DialContext(ctx, "tcp", addr)
		if err != nil {
			return nil, err
		}
		if tc, ok := c.(*net.TCPConn); ok {
			_ = tc.SetNoDelay(true)
		}
		return c, nil
	}
}
