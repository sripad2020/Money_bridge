// Package fsm is the payment state machine. Every state change in the store
// goes through Check, so an illegal jump is impossible to persist.
package fsm

import (
	"fmt"

	"pstcopay/internal/model"
)

var transitions = map[model.State][]model.State{
	model.StateCreated:    {model.StateValidating},
	model.StateValidating: {model.StateValidated, model.StateDeclined, model.StateFailed},
	model.StateValidated:  {model.StateAuthenticating},
	model.StateAuthenticating: {
		model.StateAuthenticated, model.StateDeclined, model.StateSoftFailure,
	},
	model.StateAuthenticated: {model.StateRiskPending},
	model.StateRiskPending: {
		model.StateAuthorizing, model.StateDeclined, model.StateSoftFailure,
	},
	model.StateAuthorizing: {
		model.StateAuthorized, model.StateDeclined, model.StateSoftFailure,
		model.StateUnknownOutcome, model.StateRecoveryPending,
	},
	model.StateAuthorized: {model.StateCapturing, model.StateCompensating},
	model.StateCapturing: {
		model.StateCaptured, model.StateSoftFailure, model.StateUnknownOutcome,
		model.StateCompensating, model.StateRecoveryPending,
	},
	model.StateCaptured: {model.StateSettlementPending},
	model.StateSettlementPending: {
		model.StateSettlementProcessing, model.StateCompensating, model.StateReconciliationRequired,
	},
	model.StateSettlementProcessing: {
		model.StateSettled, model.StateSettlementPending, model.StateReconciliationRequired,
	},
	model.StateSettled: {model.StateCompensating, model.StateReconciliationRequired},

	model.StateSoftFailure:     {model.StateRecoveryPending},
	model.StateUnknownOutcome:  {model.StateRecoveryPending},
	model.StateRecoveryPending: {model.StateDependencyVerification},
	model.StateDependencyVerification: {
		model.StateRetryOrResume, model.StateFailed, model.StateDeclined,
		model.StateCompensating, model.StateReconciliationRequired,
		model.StateUnknownOutcome, model.StateSoftFailure,
	},
	model.StateRetryOrResume: {
		model.StateRecoveryPending, // a crash after the decision re-enters verification
		model.StateValidated, model.StateRiskPending, model.StateAuthorizing,
		model.StateAuthorized, model.StateCapturing, model.StateCaptured,
		model.StateCompensating, model.StateFailed, model.StateDeclined,
	},
	model.StateCompensating: {model.StateCompensated, model.StateReconciliationRequired},
	model.StateReconciliationRequired: {
		model.StateSettled, model.StateCompensating, model.StateFailed,
	},
}

// CanTransition reports whether from -> to is a legal move.
func CanTransition(from, to model.State) bool {
	for _, s := range transitions[from] {
		if s == to {
			return true
		}
	}
	return false
}

// Check returns an error for an illegal transition.
func Check(from, to model.State) error {
	if !CanTransition(from, to) {
		return fmt.Errorf("fsm: illegal transition %s -> %s", from, to)
	}
	return nil
}

// States returns every state that appears in the transition table.
func States() []model.State {
	seen := map[model.State]bool{}
	var out []model.State
	add := func(s model.State) {
		if !seen[s] {
			seen[s] = true
			out = append(out, s)
		}
	}
	for from, tos := range transitions {
		add(from)
		for _, t := range tos {
			add(t)
		}
	}
	return out
}
