// Package metrics exposes PSTCO-Pay telemetry in Prometheus format.
package metrics

import (
	"net/http"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/collectors"
	"github.com/prometheus/client_golang/prometheus/promhttp"

	"pstcopay/internal/controller"
)

// Metrics implements engine.Metrics.
type Metrics struct {
	reg        *prometheus.Registry
	stage      *prometheus.HistogramVec
	payment    *prometheus.HistogramVec
	recovery   *prometheus.CounterVec
	recon      *prometheus.CounterVec
	admission  *prometheus.CounterVec
	settlement *prometheus.CounterVec
	rpc        *prometheus.HistogramVec
}

var latencyBuckets = []float64{.0005, .001, .0025, .005, .01, .025, .05, .1, .25, .5, 1, 2.5, 5}

// New registers all collectors, including live transport gauges read from the controller.
func New(ctl *controller.Controller) *Metrics {
	reg := prometheus.NewRegistry()
	m := &Metrics{
		reg: reg,
		stage: prometheus.NewHistogramVec(prometheus.HistogramOpts{
			Name: "pstco_stage_duration_seconds", Help: "Payment stage latency.", Buckets: latencyBuckets,
		}, []string{"stage", "status"}),
		payment: prometheus.NewHistogramVec(prometheus.HistogramOpts{
			Name: "pstco_payment_fast_path_seconds", Help: "Synchronous fast-path latency by resulting state.",
			Buckets: latencyBuckets,
		}, []string{"state"}),
		recovery: prometheus.NewCounterVec(prometheus.CounterOpts{
			Name: "pstco_csdr_decisions_total", Help: "CSDR recovery decisions.",
		}, []string{"decision"}),
		recon: prometheus.NewCounterVec(prometheus.CounterOpts{
			Name: "pstco_reconciliation_discrepancies_total", Help: "Reconciliation discrepancies found.",
		}, []string{"kind"}),
		admission: prometheus.NewCounterVec(prometheus.CounterOpts{
			Name: "pstco_admission_total", Help: "Admission control outcomes.",
		}, []string{"result"}),
		settlement: prometheus.NewCounterVec(prometheus.CounterOpts{
			Name: "pstco_settlement_total", Help: "Settlement worker outcomes.",
		}, []string{"result"}),
		rpc: prometheus.NewHistogramVec(prometheus.HistogramOpts{
			Name: "pstco_rpc_duration_seconds", Help: "gRPC handler latency.", Buckets: latencyBuckets,
		}, []string{"method", "code"}),
	}
	gauge := func(name, help string, f func() float64) prometheus.Collector {
		return prometheus.NewGaugeFunc(prometheus.GaugeOpts{Name: name, Help: help}, f)
	}
	reg.MustRegister(m.stage, m.payment, m.recovery, m.recon, m.admission, m.settlement, m.rpc,
		collectors.NewGoCollector(), collectors.NewProcessCollector(collectors.ProcessCollectorOpts{}),
		gauge("pstco_inflight_payments", "Admitted, unfinished payments.", func() float64 { return float64(ctl.Inflight()) }),
		gauge("pstco_active_rpc_streams", "Active HTTP/2 RPC streams.", func() float64 { return float64(ctl.Transport().ActiveStreams) }),
		gauge("pstco_tcp_connections", "Live client TCP connections.", func() float64 { return float64(ctl.Transport().ActiveConns) }),
		gauge("pstco_transport_rtt_seconds", "Smoothed transport RTT.", func() float64 { return ctl.Transport().RTTMillis / 1000 }),
		gauge("pstco_transport_retransmits", "Smoothed TCP retransmissions per sample.", func() float64 { return ctl.Transport().RetransRate }),
		gauge("pstco_congestion_factor", "PSTCO congestion factor applied to timeouts and backoff.", ctl.CongestionFactor),
	)
	return m
}

func (m *Metrics) StageObserved(stage, status string, d time.Duration) {
	m.stage.WithLabelValues(stage, status).Observe(d.Seconds())
}
func (m *Metrics) PaymentFinished(state string, d time.Duration) {
	m.payment.WithLabelValues(state).Observe(d.Seconds())
}
func (m *Metrics) Recovery(decision string)   { m.recovery.WithLabelValues(decision).Inc() }
func (m *Metrics) Reconciliation(kind string) { m.recon.WithLabelValues(kind).Inc() }
func (m *Metrics) Admission(result string)    { m.admission.WithLabelValues(result).Inc() }
func (m *Metrics) Settlement(result string)   { m.settlement.WithLabelValues(result).Inc() }

// ObserveRPC records one RPC.
func (m *Metrics) ObserveRPC(method, code string, d time.Duration) {
	m.rpc.WithLabelValues(method, code).Observe(d.Seconds())
}

// Handler serves /metrics.
func (m *Metrics) Handler() http.Handler {
	return promhttp.HandlerFor(m.reg, promhttp.HandlerOpts{})
}
