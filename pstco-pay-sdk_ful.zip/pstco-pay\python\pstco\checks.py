"""Type and value checkpoints.

Python's bool is a subclass of int and int converts silently to float, so
loose isinstance() checks let wrong types through. These checks compare the
exact type: an integer field accepts only int (never bool, float or str), a
float field accepts only float (never int, bool or str), and so on.
"""

from __future__ import annotations

import math
from typing import Any, Iterable


class CheckError(ValueError):
    """A value failed a checkpoint. ``field`` names the offending argument."""

    def __init__(self, field: str, expected: str, got: Any = None):
        self.field, self.expected = field, expected
        self.got = None if got is None else type(got).__name__
        msg = f"{field}: expected {expected}"
        if got is not None:
            msg += f", got {self.got} {got!r}"
        super().__init__(msg)


def integer(field: str, v: Any, lo: int | None = None, hi: int | None = None) -> int:
    if type(v) is not int:  # exact: rejects bool, float, str, Decimal
        raise CheckError(field, "int", v)
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        raise CheckError(field, f"int from {lo} to {hi}", v)
    return v


def floating(field: str, v: Any, lo: float | None = None, hi: float | None = None) -> float:
    if type(v) is not float:  # exact: rejects int, bool, str
        raise CheckError(field, "float", v)
    if math.isnan(v) or math.isinf(v):
        raise CheckError(field, "finite float", v)
    if (lo is not None and v < lo) or (hi is not None and v > hi):
        raise CheckError(field, f"float from {lo} to {hi}", v)
    return v


def boolean(field: str, v: Any) -> bool:
    if type(v) is not bool:
        raise CheckError(field, "bool", v)
    return v


def text(field: str, v: Any, min_len: int = 0, max_len: int = 1 << 16) -> str:
    if type(v) is not str:
        raise CheckError(field, "str", v)
    if not min_len <= len(v) <= max_len:
        raise CheckError(field, f"text of {min_len} to {max_len} characters", v)
    if any(ord(c) < 0x20 or ord(c) == 0x7F for c in v):
        raise CheckError(field, "text without control characters")
    return v


def binary(field: str, v: Any, min_len: int = 0, max_len: int = 1 << 20) -> bytes:
    if type(v) is not bytes:
        raise CheckError(field, "bytes", v)
    if not min_len <= len(v) <= max_len:
        raise CheckError(field, f"{min_len} to {max_len} bytes", f"{len(v)} bytes")
    return v


def one_of(field: str, v: Any, allowed: Iterable[str]) -> str:
    allowed = tuple(allowed)
    text(field, v)
    if v not in allowed:
        raise CheckError(field, "one of " + ", ".join(allowed), v)
    return v


def digits(field: str, v: Any, n_min: int, n_max: int) -> str:
    text(field, v, n_min, n_max)
    if not v.isascii() or not v.isdigit():
        raise CheckError(field, "digits only", v)
    return v


def json_types(field: str, doc: Any, schema: dict[str, type | tuple]) -> dict:
    """Check a decoded JSON object against {key: type}. int means a JSON
    integer, float a JSON number, and unknown keys are rejected."""
    if type(doc) is not dict:
        raise CheckError(field, "JSON object", doc)
    for k in doc:
        if k not in schema:
            raise CheckError(f"{field}.{k}", "a known field")
    for k, want in schema.items():
        if k not in doc:
            continue
        v = doc[k]
        if want is float:
            if type(v) not in (int, float) or type(v) is bool:
                raise CheckError(f"{field}.{k}", "number", v)
        elif want is int:
            integer(f"{field}.{k}", v)
        elif type(v) is not want:
            raise CheckError(f"{field}.{k}", getattr(want, "__name__", str(want)), v)
    return doc
