package engine

import (
	"context"
	"fmt"

	"pstcopay/internal/chain"
	"pstcopay/internal/store"
)

// AnchorOnce anchors every append-only event log (online payments and
// offline payments) and returns the online anchor, if one was written.
func (e *Engine) AnchorOnce(ctx context.Context) (*chain.Anchor, error) {
	as, err := e.AnchorAll(ctx)
	for _, a := range as {
		if a.Log == store.LogOnline {
			return a, err
		}
	}
	return nil, err
}

// AnchorAll computes a signed Merkle root over the events written to each
// log since its previous anchor, appends it to the external anchor log
// first, then records it in the database.
func (e *Engine) AnchorAll(ctx context.Context) ([]*chain.Anchor, error) {
	if e.cfg.AnchorFile == "" {
		return nil, nil
	}
	var out []*chain.Anchor
	for _, log := range []string{store.LogOnline, store.LogOffline} {
		last, err := e.store.LastAnchoredRowIDFor(ctx, log)
		if err != nil {
			return out, err
		}
		top, err := e.store.MaxEventRowIDIn(ctx, log)
		if err != nil {
			return out, err
		}
		if top <= last {
			continue
		}
		_, hs, err := e.store.EventHashesIn(ctx, log, last, top)
		if err != nil {
			return out, err
		}
		a := &chain.Anchor{FromRowID: last, ToRowID: top, Count: len(hs), Root: chain.MerkleRoot(hs),
			CreatedAt: e.now().UnixNano(), Log: log}
		chain.SignAnchor(a, e.keys.Signer(chain.SignerAnchor))
		if err := chain.AppendAnchor(e.cfg.AnchorFile, a); err != nil {
			return out, err
		}
		if err := e.store.WithTx(ctx, func(tx *store.Tx) error { return tx.InsertAnchor(ctx, a) }); err != nil {
			return out, err
		}
		out = append(out, a)
	}
	return out, nil
}

// AnchorReport is the result of verifying the anchor log against the database.
type AnchorReport struct {
	Anchors  int      `json:"anchors"`
	Events   int      `json:"events_covered"`
	Problems []string `json:"problems"`
}

// VerifyAnchors recomputes every anchored Merkle root from the database and
// checks each anchor's signature.
func (e *Engine) VerifyAnchors(ctx context.Context) (*AnchorReport, error) {
	anchors, err := chain.ReadAnchors(e.cfg.AnchorFile)
	if err != nil {
		return nil, err
	}
	rep := &AnchorReport{Anchors: len(anchors), Problems: []string{}}
	for i, a := range anchors {
		if !chain.VerifyAnchorSignature(a, e.keys) {
			rep.Problems = append(rep.Problems, fmt.Sprintf("anchor %d: bad signature", i+1))
			continue
		}
		log := a.Log
		if log == "" {
			log = store.LogOnline
		}
		_, hs, err := e.store.EventHashesIn(ctx, log, a.FromRowID, a.ToRowID)
		if err != nil {
			return nil, err
		}
		rep.Events += len(hs)
		if len(hs) != a.Count {
			rep.Problems = append(rep.Problems, fmt.Sprintf("anchor %d (%s): %d events in db, %d anchored", i+1, log, len(hs), a.Count))
			continue
		}
		if root := chain.MerkleRoot(hs); root != a.Root {
			rep.Problems = append(rep.Problems, fmt.Sprintf("anchor %d (%s): merkle root mismatch (rows %d..%d)", i+1, log, a.FromRowID+1, a.ToRowID))
		}
	}
	return rep, nil
}
