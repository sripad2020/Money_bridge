package store

import (
	"context"
	"database/sql"
	"errors"
	"time"
)

// Offline payment tables. IDs that are uint64 on the wire are stored as their
// int64 bit pattern; equality and ordering by counter are unaffected.
const offlineSchema = `
CREATE TABLE IF NOT EXISTS accounts (
  id TEXT PRIMARY KEY,
  phone TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  payee_id INTEGER NOT NULL UNIQUE,
  listed INTEGER NOT NULL,
  status TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS otp_codes (
  phone TEXT PRIMARY KEY,
  code_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  listed INTEGER NOT NULL,
  attempts INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  sent_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS registration_tokens (
  token_hash TEXT PRIMARY KEY,
  account_id TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS reg_challenges (
  challenge_hash TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS devices (
  id INTEGER PRIMARY KEY,
  account_id TEXT NOT NULL,
  alg INTEGER NOT NULL,
  public_key BLOB NOT NULL,
  trust INTEGER NOT NULL,
  element_kind TEXT NOT NULL,
  attestation_format TEXT NOT NULL,
  trust_note TEXT NOT NULL,
  cert BLOB NOT NULL,
  status TEXT NOT NULL,
  status_reason TEXT NOT NULL DEFAULT '',
  rasp TEXT NOT NULL DEFAULT '',
  model TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS devices_account ON devices(account_id, status);
CREATE TABLE IF NOT EXISTS reserves (
  id INTEGER PRIMARY KEY,
  device_id INTEGER NOT NULL,
  account_id TEXT NOT NULL,
  idem_key TEXT NOT NULL UNIQUE,
  amount INTEGER NOT NULL,
  spent INTEGER NOT NULL,
  carried INTEGER NOT NULL,
  counter_start INTEGER NOT NULL,
  per_payment_limit INTEGER NOT NULL,
  expiry INTEGER NOT NULL,
  instruction BLOB NOT NULL,
  genesis BLOB NOT NULL,
  hold_id TEXT NOT NULL,
  status TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  closed_at INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS reserves_device ON reserves(device_id, counter_start);
CREATE TABLE IF NOT EXISTS offline_records (
  device_id INTEGER NOT NULL,
  counter INTEGER NOT NULL,
  raw BLOB NOT NULL,
  record_hash BLOB NOT NULL,
  prev_hash BLOB NOT NULL,
  reserve_id INTEGER NOT NULL,
  payer_account TEXT NOT NULL,
  payee_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL,
  reason TEXT NOT NULL DEFAULT '',
  channel TEXT NOT NULL,
  received_at INTEGER NOT NULL,
  PRIMARY KEY (device_id, counter)
);
CREATE INDEX IF NOT EXISTS offline_records_payee ON offline_records(payee_id, status);
CREATE TABLE IF NOT EXISTS offline_conflicts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  device_id INTEGER NOT NULL,
  counter INTEGER NOT NULL,
  raw BLOB NOT NULL,
  kind TEXT NOT NULL,
  detail TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS offline_settlements (
  device_id INTEGER NOT NULL,
  counter INTEGER NOT NULL,
  hold_id TEXT NOT NULL,
  payee_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL,
  attempts INTEGER NOT NULL,
  next_attempt_at INTEGER NOT NULL,
  bank_ref TEXT NOT NULL DEFAULT '',
  last_error TEXT NOT NULL DEFAULT '',
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (device_id, counter)
);
CREATE INDEX IF NOT EXISTS offline_settlements_due ON offline_settlements(status, next_attempt_at);
CREATE TABLE IF NOT EXISTS server_nonces (
  nonce_hash TEXT PRIMARY KEY,
  device_id INTEGER NOT NULL,
  purpose TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  used INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS security_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT NOT NULL,
  subject TEXT NOT NULL,
  detail TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS request_nonces (
  sig_hash TEXT PRIMARY KEY,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS offline_events (
  row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_id TEXT NOT NULL UNIQUE,
  payment_id TEXT NOT NULL,
  seq INTEGER NOT NULL,
  stage TEXT NOT NULL,
  attempt_number INTEGER NOT NULL,
  status TEXT NOT NULL,
  previous_event_hash TEXT NOT NULL,
  dependency_hashes TEXT NOT NULL,
  retry_of_event_hash TEXT NOT NULL,
  payload TEXT NOT NULL,
  payload_hash TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  nonce_reference TEXT NOT NULL,
  workflow_version TEXT NOT NULL,
  signer TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  current_hash TEXT NOT NULL UNIQUE,
  signature TEXT NOT NULL,
  UNIQUE (payment_id, seq)
);
CREATE TRIGGER IF NOT EXISTS offline_events_append_only_update
BEFORE UPDATE ON offline_events
BEGIN SELECT RAISE(ABORT, 'offline_events is append-only'); END;
CREATE TRIGGER IF NOT EXISTS offline_events_append_only_delete
BEFORE DELETE ON offline_events
BEGIN SELECT RAISE(ABORT, 'offline_events is append-only'); END;
`

// Device and record statuses.
const (
	DeviceActive  = "ACTIVE"
	DeviceRevoked = "REVOKED"
	DeviceFrozen  = "FROZEN"

	ReserveActive  = "ACTIVE"
	ReserveClosed  = "CLOSED"  // superseded by a top-up
	ReserveExpired = "EXPIRED" // unspent money released

	RecordAccepted = "ACCEPTED"
	RecordSettled  = "SETTLED"

	SettlePending     = "PENDING"
	SettleWaitPayee   = "WAITING_PAYEE"
	SettleDone        = "SETTLED"
	SettleNeedsReview = "RECONCILIATION_REQUIRED"
)

func u2i(v uint64) int64 { return int64(v) }
func i2u(v int64) uint64 { return uint64(v) }

// ------------------------------------------------------------------ accounts

// Account is a wallet holder; every account can also be paid.
type Account struct {
	ID, Phone, Name string
	PayeeID         uint64
	Listed          bool
	Status          string
	CreatedAt       time.Time
}

func scanAccount(r scanner) (*Account, error) {
	var a Account
	var payee, created int64
	err := r.Scan(&a.ID, &a.Phone, &a.Name, &payee, &a.Listed, &a.Status, &created)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	a.PayeeID, a.CreatedAt = i2u(payee), fromNS(created)
	return &a, err
}

const accountCols = `id, phone, name, payee_id, listed, status, created_at`

// InsertAccount creates an account.
func (q Queries) InsertAccount(ctx context.Context, a *Account) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO accounts(`+accountCols+`) VALUES (?,?,?,?,?,?,?)`,
		a.ID, a.Phone, a.Name, u2i(a.PayeeID), a.Listed, a.Status, ns(a.CreatedAt))
	if isUnique(err) {
		return ErrDuplicate
	}
	return err
}

// GetAccount loads an account by id.
func (q Queries) GetAccount(ctx context.Context, id string) (*Account, error) {
	return scanAccount(q.q.QueryRowContext(ctx, `SELECT `+accountCols+` FROM accounts WHERE id=?`, id))
}

// GetAccountByPhone loads an account by E.164 phone.
func (q Queries) GetAccountByPhone(ctx context.Context, phone string) (*Account, error) {
	return scanAccount(q.q.QueryRowContext(ctx, `SELECT `+accountCols+` FROM accounts WHERE phone=?`, phone))
}

// GetAccountByPayee loads an account by payee id.
func (q Queries) GetAccountByPayee(ctx context.Context, payee uint64) (*Account, error) {
	return scanAccount(q.q.QueryRowContext(ctx, `SELECT `+accountCols+` FROM accounts WHERE payee_id=?`, u2i(payee)))
}

// ListListedAccounts returns accounts shown in the payee directory.
func (q Queries) ListListedAccounts(ctx context.Context) ([]*Account, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT `+accountCols+` FROM accounts WHERE listed=1 AND status='ACTIVE' ORDER BY payee_id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*Account
	for rows.Next() {
		a, err := scanAccount(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

// ---------------------------------------------------------------------- otp

// OTP is a pending phone verification.
type OTP struct {
	Phone, CodeHash, Name string
	Listed                bool
	Attempts              int
	ExpiresAt, SentAt     time.Time
}

// PutOTP stores (or replaces) a pending verification.
func (q Queries) PutOTP(ctx context.Context, o *OTP) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO otp_codes(phone, code_hash, name, listed, attempts, expires_at, sent_at)
		VALUES (?,?,?,?,?,?,?) ON CONFLICT(phone) DO UPDATE SET code_hash=excluded.code_hash, name=excluded.name,
		listed=excluded.listed, attempts=0, expires_at=excluded.expires_at, sent_at=excluded.sent_at`,
		o.Phone, o.CodeHash, o.Name, o.Listed, 0, ns(o.ExpiresAt), ns(o.SentAt))
	return err
}

// GetOTP loads a pending verification.
func (q Queries) GetOTP(ctx context.Context, phone string) (*OTP, error) {
	var o OTP
	var exp, sent int64
	err := q.q.QueryRowContext(ctx, `SELECT phone, code_hash, name, listed, attempts, expires_at, sent_at
		FROM otp_codes WHERE phone=?`, phone).Scan(&o.Phone, &o.CodeHash, &o.Name, &o.Listed, &o.Attempts, &exp, &sent)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	o.ExpiresAt, o.SentAt = fromNS(exp), fromNS(sent)
	return &o, err
}

// FailOTP counts a wrong code.
func (q Queries) FailOTP(ctx context.Context, phone string) error {
	_, err := q.q.ExecContext(ctx, `UPDATE otp_codes SET attempts=attempts+1 WHERE phone=?`, phone)
	return err
}

// DeleteOTP removes a verification.
func (q Queries) DeleteOTP(ctx context.Context, phone string) error {
	_, err := q.q.ExecContext(ctx, `DELETE FROM otp_codes WHERE phone=?`, phone)
	return err
}

// ------------------------------------------------- single-use tokens

// PutRegistrationToken stores a hashed single-use registration token.
func (q Queries) PutRegistrationToken(ctx context.Context, hash, account string, exp time.Time) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO registration_tokens(token_hash, account_id, expires_at, used) VALUES (?,?,?,0)`,
		hash, account, ns(exp))
	return err
}

// PeekRegistrationToken returns the account of a valid, unused token.
func (q Queries) PeekRegistrationToken(ctx context.Context, hash string, now time.Time) (string, error) {
	var acct string
	err := q.q.QueryRowContext(ctx, `SELECT account_id FROM registration_tokens WHERE token_hash=? AND used=0 AND expires_at>?`,
		hash, ns(now)).Scan(&acct)
	if errors.Is(err, sql.ErrNoRows) {
		return "", ErrNotFound
	}
	return acct, err
}

// UseRegistrationToken consumes a token exactly once.
func (q Queries) UseRegistrationToken(ctx context.Context, hash string, now time.Time) (string, error) {
	acct, err := q.PeekRegistrationToken(ctx, hash, now)
	if err != nil {
		return "", err
	}
	res, err := q.q.ExecContext(ctx, `UPDATE registration_tokens SET used=1 WHERE token_hash=? AND used=0`, hash)
	if err != nil {
		return "", err
	}
	if n, _ := res.RowsAffected(); n != 1 {
		return "", ErrNotFound
	}
	return acct, nil
}

// PutChallenge stores a registration challenge bound to a token.
func (q Queries) PutChallenge(ctx context.Context, chHash, tokHash string, exp time.Time) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO reg_challenges(challenge_hash, token_hash, expires_at, used) VALUES (?,?,?,0)`,
		chHash, tokHash, ns(exp))
	return err
}

// UseChallenge consumes a challenge for its token exactly once.
func (q Queries) UseChallenge(ctx context.Context, chHash, tokHash string, now time.Time) error {
	res, err := q.q.ExecContext(ctx, `UPDATE reg_challenges SET used=1 WHERE challenge_hash=? AND token_hash=? AND used=0 AND expires_at>?`,
		chHash, tokHash, ns(now))
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n != 1 {
		return ErrNotFound
	}
	return nil
}

// UseRequestNonce records a request signature; a repeat is ErrDuplicate.
func (q Queries) UseRequestNonce(ctx context.Context, sigHash string, exp time.Time) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO request_nonces(sig_hash, expires_at) VALUES (?,?)`, sigHash, ns(exp))
	if isUnique(err) {
		return ErrDuplicate
	}
	return err
}

// PutServerNonce stores a server-issued nonce bound to a device and purpose.
func (q Queries) PutServerNonce(ctx context.Context, hash string, device uint64, purpose string, exp time.Time) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO server_nonces(nonce_hash, device_id, purpose, expires_at, used) VALUES (?,?,?,?,0)`,
		hash, u2i(device), purpose, ns(exp))
	return err
}

// UseServerNonce consumes a server nonce exactly once for its device and purpose.
func (q Queries) UseServerNonce(ctx context.Context, hash string, device uint64, purpose string, now time.Time) error {
	res, err := q.q.ExecContext(ctx, `UPDATE server_nonces SET used=1 WHERE nonce_hash=? AND device_id=? AND purpose=?
		AND used=0 AND expires_at>?`, hash, u2i(device), purpose, ns(now))
	if err != nil {
		return err
	}
	if n, _ := res.RowsAffected(); n != 1 {
		return ErrNotFound
	}
	return nil
}

// SecurityEvent is one audit entry.
type SecurityEvent struct {
	Kind, Subject, Detail string
	CreatedAt             time.Time
}

// InsertSecurityEvent records a security event.
func (q Queries) InsertSecurityEvent(ctx context.Context, e *SecurityEvent) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO security_events(kind, subject, detail, created_at) VALUES (?,?,?,?)`,
		e.Kind, e.Subject, e.Detail, ns(e.CreatedAt))
	return err
}

// ListSecurityEvents returns events of a kind ("" for all), newest first.
func (q Queries) ListSecurityEvents(ctx context.Context, kind string, limit int) ([]*SecurityEvent, error) {
	query, args := `SELECT kind, subject, detail, created_at FROM security_events`, []any{}
	if kind != "" {
		query += ` WHERE kind=?`
		args = append(args, kind)
	}
	args = append(args, limit)
	rows, err := q.q.QueryContext(ctx, query+` ORDER BY id DESC LIMIT ?`, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*SecurityEvent
	for rows.Next() {
		var e SecurityEvent
		var at int64
		if err := rows.Scan(&e.Kind, &e.Subject, &e.Detail, &at); err != nil {
			return nil, err
		}
		e.CreatedAt = fromNS(at)
		out = append(out, &e)
	}
	return out, rows.Err()
}

// PurgeExpired removes expired single-use rows.
func (q Queries) PurgeExpired(ctx context.Context, now time.Time) error {
	for _, t := range []string{"request_nonces", "reg_challenges", "registration_tokens", "otp_codes", "server_nonces"} {
		if _, err := q.q.ExecContext(ctx, `DELETE FROM `+t+` WHERE expires_at<?`, ns(now)); err != nil {
			return err
		}
	}
	return nil
}

// ------------------------------------------------------------------- devices

// Device is a registered wallet device.
type Device struct {
	ID                uint64
	AccountID         string
	Alg               byte
	PublicKey         []byte
	Trust             byte
	ElementKind       string
	AttestationFormat string
	TrustNote         string
	Cert              []byte
	Status            string
	StatusReason      string
	RASP              string
	Model             string
	CreatedAt         time.Time
	UpdatedAt         time.Time
}

const deviceCols = `id, account_id, alg, public_key, trust, element_kind, attestation_format, trust_note, cert,
	status, status_reason, rasp, model, created_at, updated_at`

func scanDevice(r scanner) (*Device, error) {
	var d Device
	var id, c, u int64
	err := r.Scan(&id, &d.AccountID, &d.Alg, &d.PublicKey, &d.Trust, &d.ElementKind, &d.AttestationFormat,
		&d.TrustNote, &d.Cert, &d.Status, &d.StatusReason, &d.RASP, &d.Model, &c, &u)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	d.ID, d.CreatedAt, d.UpdatedAt = i2u(id), fromNS(c), fromNS(u)
	return &d, err
}

// InsertDevice registers a device.
func (q Queries) InsertDevice(ctx context.Context, d *Device) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO devices(`+deviceCols+`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
		u2i(d.ID), d.AccountID, d.Alg, d.PublicKey, d.Trust, d.ElementKind, d.AttestationFormat, d.TrustNote,
		d.Cert, d.Status, d.StatusReason, d.RASP, d.Model, ns(d.CreatedAt), ns(d.UpdatedAt))
	if isUnique(err) {
		return ErrDuplicate
	}
	return err
}

// GetDevice loads a device.
func (q Queries) GetDevice(ctx context.Context, id uint64) (*Device, error) {
	return scanDevice(q.q.QueryRowContext(ctx, `SELECT `+deviceCols+` FROM devices WHERE id=?`, u2i(id)))
}

// ActiveDevice returns the account's active device.
func (q Queries) ActiveDevice(ctx context.Context, account string) (*Device, error) {
	return scanDevice(q.q.QueryRowContext(ctx, `SELECT `+deviceCols+` FROM devices WHERE account_id=? AND status='ACTIVE'
		ORDER BY created_at DESC LIMIT 1`, account))
}

// SetDeviceStatus changes a device's status.
func (q Queries) SetDeviceStatus(ctx context.Context, id uint64, status, reason string, now time.Time) error {
	_, err := q.q.ExecContext(ctx, `UPDATE devices SET status=?, status_reason=?, updated_at=? WHERE id=?`,
		status, reason, ns(now), u2i(id))
	return err
}

// SetDeviceRASP records the latest runtime self-protection report.
func (q Queries) SetDeviceRASP(ctx context.Context, id uint64, report string, now time.Time) error {
	_, err := q.q.ExecContext(ctx, `UPDATE devices SET rasp=?, updated_at=? WHERE id=?`, report, ns(now), u2i(id))
	return err
}

// InactiveDeviceIDs lists revoked and frozen devices for the revocation list.
func (q Queries) InactiveDeviceIDs(ctx context.Context) ([]uint64, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT id FROM devices WHERE status<>'ACTIVE' ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []uint64
	for rows.Next() {
		var id int64
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		out = append(out, i2u(id))
	}
	return out, rows.Err()
}

// ------------------------------------------------------------------ reserves

// Reserve is an offline balance locked at the bank for one device.
type Reserve struct {
	ID              uint64
	DeviceID        uint64
	AccountID       string
	IdemKey         string
	Amount, Spent   int64
	Carried         int64
	CounterStart    uint32
	PerPaymentLimit int64
	Expiry          uint32
	Instruction     []byte
	Genesis         []byte
	HoldID          string
	Status          string
	CreatedAt       time.Time
	ClosedAt        time.Time
}

const reserveCols = `id, device_id, account_id, idem_key, amount, spent, carried, counter_start, per_payment_limit,
	expiry, instruction, genesis, hold_id, status, created_at, closed_at`

func scanReserve(r scanner) (*Reserve, error) {
	var v Reserve
	var id, dev, cs, exp, c, cl int64
	err := r.Scan(&id, &dev, &v.AccountID, &v.IdemKey, &v.Amount, &v.Spent, &v.Carried, &cs, &v.PerPaymentLimit,
		&exp, &v.Instruction, &v.Genesis, &v.HoldID, &v.Status, &c, &cl)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	v.ID, v.DeviceID, v.CounterStart, v.Expiry = i2u(id), i2u(dev), uint32(cs), uint32(exp)
	v.CreatedAt, v.ClosedAt = fromNS(c), fromNS(cl)
	return &v, err
}

// InsertReserve stores a reserve.
func (q Queries) InsertReserve(ctx context.Context, r *Reserve) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO reserves(`+reserveCols+`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
		u2i(r.ID), u2i(r.DeviceID), r.AccountID, r.IdemKey, r.Amount, r.Spent, r.Carried, int64(r.CounterStart),
		r.PerPaymentLimit, int64(r.Expiry), r.Instruction, r.Genesis, r.HoldID, r.Status, ns(r.CreatedAt), ns(r.ClosedAt))
	if isUnique(err) {
		return ErrDuplicate
	}
	return err
}

// GetReserveByIdem finds a reserve by the device's idempotency key.
func (q Queries) GetReserveByIdem(ctx context.Context, key string) (*Reserve, error) {
	return scanReserve(q.q.QueryRowContext(ctx, `SELECT `+reserveCols+` FROM reserves WHERE idem_key=?`, key))
}

// GetReserve loads a reserve by id.
func (q Queries) GetReserve(ctx context.Context, id uint64) (*Reserve, error) {
	return scanReserve(q.q.QueryRowContext(ctx, `SELECT `+reserveCols+` FROM reserves WHERE id=?`, u2i(id)))
}

// ActiveReserve returns the device's active reserve.
func (q Queries) ActiveReserve(ctx context.Context, device uint64) (*Reserve, error) {
	return scanReserve(q.q.QueryRowContext(ctx, `SELECT `+reserveCols+` FROM reserves WHERE device_id=? AND status='ACTIVE'`, u2i(device)))
}

// ReserveForCounter returns the reserve covering a counter: the one with the
// highest counter_start not above it.
func (q Queries) ReserveForCounter(ctx context.Context, device uint64, counter uint32) (*Reserve, error) {
	return scanReserve(q.q.QueryRowContext(ctx, `SELECT `+reserveCols+` FROM reserves WHERE device_id=? AND counter_start<=?
		ORDER BY counter_start DESC LIMIT 1`, u2i(device), int64(counter)))
}

// AddReserveSpent adds to spent only if it stays within the reserve amount.
func (q Queries) AddReserveSpent(ctx context.Context, id uint64, amount int64) (bool, error) {
	res, err := q.q.ExecContext(ctx, `UPDATE reserves SET spent=spent+? WHERE id=? AND spent+?<=amount`, amount, u2i(id), amount)
	if err != nil {
		return false, err
	}
	n, _ := res.RowsAffected()
	return n == 1, nil
}

// CloseReserve sets a reserve's final status.
func (q Queries) CloseReserve(ctx context.Context, id uint64, status string, now time.Time) error {
	_, err := q.q.ExecContext(ctx, `UPDATE reserves SET status=?, closed_at=? WHERE id=?`, status, ns(now), u2i(id))
	return err
}

// ShrinkReserveToSpent sets a closed reserve's amount to what it paid out.
func (q Queries) ShrinkReserveToSpent(ctx context.Context, id uint64) error {
	_, err := q.q.ExecContext(ctx, `UPDATE reserves SET amount=spent WHERE id=?`, u2i(id))
	return err
}

// ExpiredReserves lists active reserves whose expiry plus grace has passed.
func (q Queries) ExpiredReserves(ctx context.Context, before uint32) ([]*Reserve, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT `+reserveCols+` FROM reserves WHERE status='ACTIVE' AND expiry<?`, int64(before))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*Reserve
	for rows.Next() {
		r, err := scanReserve(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, r)
	}
	return out, rows.Err()
}

// ------------------------------------------------------------------- records

// OfflineRecord is a verified offline payment held by the server.
type OfflineRecord struct {
	DeviceID     uint64
	Counter      uint32
	Raw          []byte
	RecordHash   []byte
	PrevHash     []byte
	ReserveID    uint64
	PayerAccount string
	PayeeID      uint64
	Amount       int64
	Status       string
	Reason       string
	Channel      string
	ReceivedAt   time.Time
}

const recordCols = `device_id, counter, raw, record_hash, prev_hash, reserve_id, payer_account, payee_id, amount,
	status, reason, channel, received_at`

func scanRecord(r scanner) (*OfflineRecord, error) {
	var v OfflineRecord
	var dev, ctr, rsv, payee, at int64
	err := r.Scan(&dev, &ctr, &v.Raw, &v.RecordHash, &v.PrevHash, &rsv, &v.PayerAccount, &payee, &v.Amount,
		&v.Status, &v.Reason, &v.Channel, &at)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	v.DeviceID, v.Counter, v.ReserveID, v.PayeeID, v.ReceivedAt = i2u(dev), uint32(ctr), i2u(rsv), i2u(payee), fromNS(at)
	return &v, err
}

// InsertRecord stores a verified record; a repeat of (device, counter) is ErrDuplicate.
func (q Queries) InsertRecord(ctx context.Context, r *OfflineRecord) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO offline_records(`+recordCols+`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
		u2i(r.DeviceID), int64(r.Counter), r.Raw, r.RecordHash, r.PrevHash, u2i(r.ReserveID), r.PayerAccount,
		u2i(r.PayeeID), r.Amount, r.Status, r.Reason, r.Channel, ns(r.ReceivedAt))
	if isUnique(err) {
		return ErrDuplicate
	}
	return err
}

// GetRecord loads a record.
func (q Queries) GetRecord(ctx context.Context, device uint64, counter uint32) (*OfflineRecord, error) {
	return scanRecord(q.q.QueryRowContext(ctx, `SELECT `+recordCols+` FROM offline_records WHERE device_id=? AND counter=?`,
		u2i(device), int64(counter)))
}

// SetRecordStatus updates a record's status.
func (q Queries) SetRecordStatus(ctx context.Context, device uint64, counter uint32, status string) error {
	_, err := q.q.ExecContext(ctx, `UPDATE offline_records SET status=? WHERE device_id=? AND counter=?`,
		status, u2i(device), int64(counter))
	return err
}

// MaxCounter returns the highest counter received from a device (0 when none).
func (q Queries) MaxCounter(ctx context.Context, device uint64) (uint32, error) {
	var v sql.NullInt64
	err := q.q.QueryRowContext(ctx, `SELECT MAX(counter) FROM offline_records WHERE device_id=?`, u2i(device)).Scan(&v)
	return uint32(v.Int64), err
}

// CountRecordsInRange counts records a device has with counters in [from, to].
func (q Queries) CountRecordsInRange(ctx context.Context, device uint64, from, to uint32) (int, error) {
	var n int
	err := q.q.QueryRowContext(ctx, `SELECT COUNT(*) FROM offline_records WHERE device_id=? AND counter>=? AND counter<=?`,
		u2i(device), int64(from), int64(to)).Scan(&n)
	return n, err
}

// IncomingTotals sums pending and settled incoming payments for a payee.
func (q Queries) IncomingTotals(ctx context.Context, payee uint64) (pending, settled int64, err error) {
	var p, s sql.NullInt64
	err = q.q.QueryRowContext(ctx, `SELECT
		SUM(CASE WHEN status<>'SETTLED' THEN amount ELSE 0 END),
		SUM(CASE WHEN status='SETTLED' THEN amount ELSE 0 END)
		FROM offline_records WHERE payee_id=?`, u2i(payee)).Scan(&p, &s)
	return p.Int64, s.Int64, err
}

// RecordLink is the chain position of one stored record.
type RecordLink struct {
	Counter    uint32
	ReserveID  uint64
	PrevHash   []byte
	RecordHash []byte
}

// DeviceChain returns every stored record link of a device in counter order.
func (q Queries) DeviceChain(ctx context.Context, device uint64) ([]RecordLink, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT counter, reserve_id, prev_hash, record_hash FROM offline_records
		WHERE device_id=? ORDER BY counter`, u2i(device))
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []RecordLink
	for rows.Next() {
		var l RecordLink
		var ctr, rsv int64
		if err := rows.Scan(&ctr, &rsv, &l.PrevHash, &l.RecordHash); err != nil {
			return nil, err
		}
		l.Counter, l.ReserveID = uint32(ctr), i2u(rsv)
		out = append(out, l)
	}
	return out, rows.Err()
}

// InsertConflict records a double spend, fork or overspend attempt.
func (q Queries) InsertConflict(ctx context.Context, device uint64, counter uint32, raw []byte, kind, detail string, now time.Time) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO offline_conflicts(device_id, counter, raw, kind, detail, created_at) VALUES (?,?,?,?,?,?)`,
		u2i(device), int64(counter), raw, kind, detail, ns(now))
	return err
}

// CountConflicts counts recorded conflicts for a device.
func (q Queries) CountConflicts(ctx context.Context, device uint64) (int, error) {
	var n int
	err := q.q.QueryRowContext(ctx, `SELECT COUNT(*) FROM offline_conflicts WHERE device_id=?`, u2i(device)).Scan(&n)
	return n, err
}

// --------------------------------------------------------------- settlements

// OfflineSettlement is one queued bank transfer for a verified record.
type OfflineSettlement struct {
	DeviceID      uint64
	Counter       uint32
	HoldID        string
	PayeeID       uint64
	Amount        int64
	Status        string
	Attempts      int
	NextAttemptAt time.Time
	BankRef       string
	LastError     string
}

const settleCols = `device_id, counter, hold_id, payee_id, amount, status, attempts, next_attempt_at, bank_ref, last_error`

func scanSettlement(r scanner) (*OfflineSettlement, error) {
	var s OfflineSettlement
	var dev, ctr, payee, next int64
	err := r.Scan(&dev, &ctr, &s.HoldID, &payee, &s.Amount, &s.Status, &s.Attempts, &next, &s.BankRef, &s.LastError)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	s.DeviceID, s.Counter, s.PayeeID, s.NextAttemptAt = i2u(dev), uint32(ctr), i2u(payee), fromNS(next)
	return &s, err
}

// InsertSettlement queues a transfer (same transaction as the record).
func (q Queries) InsertOfflineSettlement(ctx context.Context, s *OfflineSettlement, now time.Time) error {
	_, err := q.q.ExecContext(ctx, `INSERT INTO offline_settlements(`+settleCols+`, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
		u2i(s.DeviceID), int64(s.Counter), s.HoldID, u2i(s.PayeeID), s.Amount, s.Status, s.Attempts,
		ns(s.NextAttemptAt), s.BankRef, s.LastError, ns(now))
	return err
}

// DueOfflineSettlements returns pending transfers that are due.
func (q Queries) DueOfflineSettlements(ctx context.Context, now time.Time, limit int) ([]*OfflineSettlement, error) {
	return q.listSettlements(ctx, `WHERE status='PENDING' AND next_attempt_at<=? ORDER BY next_attempt_at LIMIT ?`, ns(now), limit)
}

// WaitingSettlements returns transfers waiting for a payee to register.
func (q Queries) WaitingSettlements(ctx context.Context, payee uint64) ([]*OfflineSettlement, error) {
	return q.listSettlements(ctx, `WHERE status='WAITING_PAYEE' AND payee_id=?`, u2i(payee))
}

// AllOfflineSettlements returns every queued or finished transfer.
func (q Queries) AllOfflineSettlements(ctx context.Context) ([]*OfflineSettlement, error) {
	return q.listSettlements(ctx, `ORDER BY device_id, counter`)
}

func (q Queries) listSettlements(ctx context.Context, where string, args ...any) ([]*OfflineSettlement, error) {
	rows, err := q.q.QueryContext(ctx, `SELECT `+settleCols+` FROM offline_settlements `+where, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var out []*OfflineSettlement
	for rows.Next() {
		s, err := scanSettlement(rows)
		if err != nil {
			return nil, err
		}
		out = append(out, s)
	}
	return out, rows.Err()
}

// GetOfflineSettlement loads a transfer.
func (q Queries) GetOfflineSettlement(ctx context.Context, device uint64, counter uint32) (*OfflineSettlement, error) {
	return scanSettlement(q.q.QueryRowContext(ctx, `SELECT `+settleCols+` FROM offline_settlements WHERE device_id=? AND counter=?`,
		u2i(device), int64(counter)))
}

// UpdateOfflineSettlement saves a transfer's progress.
func (q Queries) UpdateOfflineSettlement(ctx context.Context, s *OfflineSettlement, now time.Time) error {
	_, err := q.q.ExecContext(ctx, `UPDATE offline_settlements SET status=?, attempts=?, next_attempt_at=?, bank_ref=?,
		last_error=?, updated_at=? WHERE device_id=? AND counter=?`,
		s.Status, s.Attempts, ns(s.NextAttemptAt), s.BankRef, s.LastError, ns(now), u2i(s.DeviceID), int64(s.Counter))
	return err
}

// PendingForReserve sums accepted but unsettled amounts held against a hold.
func (q Queries) PendingForHold(ctx context.Context, hold string) (int64, error) {
	var v sql.NullInt64
	err := q.q.QueryRowContext(ctx, `SELECT SUM(amount) FROM offline_settlements WHERE hold_id=? AND status<>'SETTLED'`, hold).Scan(&v)
	return v.Int64, err
}
