

from __future__ import annotations

import argparse
import json
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import numpy as np
import pandas as pd

MODEL_DIR = Path(__file__).resolve().parent / "models"

FEATURES = [
    "amount_minor",
    "concurrency",
    "conns",
    "deadline_ms",
    "client_inflight",
    "prev_server_inflight",
    "prev_server_streams",
    "prev_rtt_ms",
    "prev_congestion_factor",
    "prev_latency_ms",
]


def load(paths: list[str]) -> pd.DataFrame:
    frames = [pd.read_csv(p) for p in paths]
    df = pd.concat(frames, ignore_index=True)
    df = df[df["rpc_error"].isna() | (df["rpc_error"] == "")].copy()
    df = df.sort_values(["label", "ts_ms"]).reset_index(drop=True)
    lagged = {
        "server_inflight": "prev_server_inflight",
        "server_streams": "prev_server_streams",
        "rtt_ms": "prev_rtt_ms",
        "congestion_factor": "prev_congestion_factor",
        "latency_ms": "prev_latency_ms",
    }
    for src, dst in lagged.items():
        df[dst] = df.groupby("label")[src].shift(1)
    df = df.dropna(subset=list(lagged.values())).reset_index(drop=True)
    for c in FEATURES + ["latency_ms"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.dropna(subset=FEATURES + ["latency_ms"])


def analyze(df: pd.DataFrame) -> dict:
    """Per-run network and recovery profile: compare pool sizes, durability
    modes, or BBR versus CUBIC by giving each run its own --label."""
    out = {}
    group_cols = ["label"]
    if df["congestion_control"].notna().any() and df["congestion_control"].nunique() > 1:
        group_cols.append("congestion_control")
    for key, g in df.groupby(group_cols):
        lat = g["latency_ms"]
        name = key if isinstance(key, str) else " / ".join(map(str, key))
        out[name] = {
            "payments": int(len(g)),
            "p50_ms": round(float(lat.quantile(0.50)), 2),
            "p95_ms": round(float(lat.quantile(0.95)), 2),
            "p99_ms": round(float(lat.quantile(0.99)), 2),
            "mean_server_ms": round(float(pd.to_numeric(g["server_ms"], errors="coerce").mean()), 2),
            "recovered_share": round(float((pd.to_numeric(g["recoveries"], errors="coerce") > 0).mean()), 4),
            "mean_authorize_attempts": round(float(pd.to_numeric(g["authorize_attempts"], errors="coerce").mean()), 3),
            "missed_deadline_share": round(float(g["missed_deadline"].astype(str).str.lower().eq("true").mean()), 4),
            "states": g["state"].value_counts().to_dict(),
        }
    return out


def train(df: pd.DataFrame, slo_ms: float, seed: int = 7) -> dict:
    import lightgbm as lgb
    from sklearn.metrics import mean_absolute_error, r2_score, roc_auc_score
    from sklearn.model_selection import train_test_split

    X, y = df[FEATURES], df["latency_ms"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, random_state=seed)
    report: dict = {"rows": int(len(df)), "features": FEATURES, "slo_ms": slo_ms}

    reg = lgb.LGBMRegressor(n_estimators=400, learning_rate=0.05, num_leaves=31, random_state=seed, verbose=-1)
    reg.fit(X_tr, y_tr)
    pred = reg.predict(X_te)
    baseline = np.full_like(y_te, y_tr.median(), dtype=float)
    report["latency_regressor"] = {
        "mae_ms": round(float(mean_absolute_error(y_te, pred)), 2),
        "r2": round(float(r2_score(y_te, pred)), 4),
        "baseline_mae_ms_predict_median": round(float(mean_absolute_error(y_te, baseline)), 2),
        "feature_importance": dict(sorted(
            zip(FEATURES, map(int, reg.feature_importances_)), key=lambda kv: -kv[1])),
    }
    MODEL_DIR.mkdir(exist_ok=True)
    reg.booster_.save_model(str(MODEL_DIR / "latency_lgbm.txt"))

    breach = (y > slo_ms).astype(int)
    report["slo_breach_rate"] = round(float(breach.mean()), 4)
    if breach.nunique() == 2:
        b_tr, b_te = breach.loc[y_tr.index], breach.loc[y_te.index]
        clf = lgb.LGBMClassifier(n_estimators=300, learning_rate=0.05, num_leaves=31, random_state=seed, verbose=-1)
        clf.fit(X_tr, b_tr)
        proba = clf.predict_proba(X_te)[:, 1]
        report["slo_classifier"] = {"auc": round(float(roc_auc_score(b_te, proba)), 4)}
        clf.booster_.save_model(str(MODEL_DIR / "slo_breach_lgbm.txt"))
    else:
        report["slo_classifier"] = {"skipped": f"all rows on one side of {slo_ms} ms; choose another --slo-ms"}

    try:
        import xgboost as xgb

        xr = xgb.XGBRegressor(n_estimators=400, learning_rate=0.05, max_depth=6, random_state=seed)
        xr.fit(X_tr, y_tr)
        xp = xr.predict(X_te)
        report["xgboost_regressor"] = {
            "mae_ms": round(float(mean_absolute_error(y_te, xp)), 2),
            "r2": round(float(r2_score(y_te, xp)), 4),
        }
    except ImportError:
        report["xgboost_regressor"] = {"skipped": "xgboost not installed"}

    (MODEL_DIR / "report.json").write_text(json.dumps(report, indent=2))
    return report


class _Handler(BaseHTTPRequestHandler):
    reg = None
    clf = None
    slo_ms = None

    def do_POST(self):  # noqa: N802
        if self.path != "/predict":
            self.send_error(404)
            return
        try:
            body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
            rows = body if isinstance(body, list) else [body]
            X = pd.DataFrame([{f: float(r.get(f, 0)) for f in FEATURES} for r in rows])
            out = [{"predicted_latency_ms": round(float(v), 2)} for v in self.reg.predict(X)]
            if self.clf is not None:
                for o, p in zip(out, self.clf.predict(X)):
                    o["slo_breach_probability"] = round(float(p), 4)
                    o["slo_ms"] = self.slo_ms
            data = json.dumps(out if isinstance(body, list) else out[0]).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(data)
        except Exception as exc:  # report bad input to the caller
            self.send_error(400, str(exc))

    def log_message(self, *args):
        pass


def serve(port: int) -> None:
    import lightgbm as lgb

    reg_path = MODEL_DIR / "latency_lgbm.txt"
    if not reg_path.exists():
        sys.exit("no trained model; run: python ml/deadline_model.py train --csv loadgen.csv")
    _Handler.reg = lgb.Booster(model_file=str(reg_path))
    clf_path = MODEL_DIR / "slo_breach_lgbm.txt"
    if clf_path.exists():
        _Handler.clf = lgb.Booster(model_file=str(clf_path))
        _Handler.slo_ms = json.loads((MODEL_DIR / "report.json").read_text()).get("slo_ms")
    print(f"deadline model serving on http://127.0.0.1:{port}/predict")
    HTTPServer(("127.0.0.1", port), _Handler).serve_forever()


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("train", "analyze"):
        p = sub.add_parser(name)
        p.add_argument("--csv", nargs="+", required=True)
        p.add_argument("--slo-ms", type=float, default=500.0)
    s = sub.add_parser("serve")
    s.add_argument("--port", type=int, default=8711)
    args = ap.parse_args()

    if args.cmd == "serve":
        serve(args.port)
        return
    df = load(args.csv)
    if args.cmd == "analyze":
        print(json.dumps(analyze(df), indent=2))
        return
    print(json.dumps({"analysis": analyze(df), "model": train(df, args.slo_ms)}, indent=2))


if __name__ == "__main__":
    main()
