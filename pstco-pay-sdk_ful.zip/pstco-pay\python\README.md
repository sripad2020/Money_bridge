# PSTCO-Pay Python SDK

Offline payment formats, strict type checkpoints, blocking and asyncio clients, and a software wallet. It is byte-compatible with the Go SDK: payments signed in Python verify in Go apps and the reverse, and the tests prove it.

```bash
pip install ./python            # needs cryptography and httpx
```

```python
from pstco import Client, SoftwareWallet

client = Client("https://pay.example.com:8444", ca_file=None)    # system roots; pass a CA file for a private CA
w = SoftwareWallet.create("wallet-dir", "135790", client)
otp = w.start_account("9876500001", "Meena")                      # the user receives the OTP by SMS
w.verify_account("9876500001", otp_from_user)
w.register()

w.deposit(1000_00, w.approve("deposit", 1000_00, "135790"))      # paise as int; floats are refused
w.create_reserve(500_00, w.approve("reserve", 500_00, "135790"))

q = w.quote_phone("9876500002")                                   # name from the signed directory
p = w.pay(q, 199_99, "qr", w.approve("pay", 199_99, "135790", q["payee_id"]))
print(p["qr"])                                                    # show as a QR code; works offline

shop.accept(scanned_code)                                         # payee side, offline
w.sync()
```

`AsyncClient` and `AsyncSoftwareWallet` have the same API with coroutines, so many devices can share one event loop.

**Type checkpoints.** Integer arguments accept only `int`, never `bool`, `float` or `str`. Float arguments accept only `float`. Money accepts `int` paise or `str` rupees, never `float`. A wrong type raises `pstco.CheckError` naming the field.

**C library.** `pstco.native.probe(host, port, count)` opens concurrent TCP handshakes through `native/pstconet` when it is built (`scripts/build-native.ps1` or `make -C native/pstconet`), and falls back to pure asyncio otherwise.

Run the tests with `python -m pytest python/tests`. The end-to-end tests start a real `pstco-server`.
