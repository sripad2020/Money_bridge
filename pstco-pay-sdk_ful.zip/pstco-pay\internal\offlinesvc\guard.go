package offlinesvc

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"net"
	"net/http"
	"strings"
	"sync"
	"time"

	"pstcopay/internal/store"
	"pstcopay/sdk/offline"
	"pstcopay/sdk/offline/api"
)

// Security event kinds.
const (
	EventAuthLockout     = "auth_lockout"
	EventAuthFailure     = "auth_failure"
	EventRateLimited     = "rate_limited"
	EventDeviceFrozen    = "device_frozen"
	EventRASPBlocked     = "rasp_blocked"
	EventAttestationFail = "attestation_invalid"
	EventNonceMisuse     = "server_nonce_misuse"
)

// guard tracks failed authentication per device and request rates per IP.
type guard struct {
	mu       sync.Mutex
	fails    map[string]*failState
	ipHits   map[string][]time.Time
	maxFails int
	window   time.Duration
	lockFor  time.Duration
	ipLimit  int
	ipWindow time.Duration
}

type failState struct {
	times       []time.Time
	lockedUntil time.Time
}

func newGuard() *guard {
	return &guard{fails: map[string]*failState{}, ipHits: map[string][]time.Time{}, maxFails: 5,
		window: 10 * time.Minute, lockFor: 15 * time.Minute, ipLimit: 30, ipWindow: time.Minute}
}

// lockedUntil reports whether a subject is locked out.
func (g *guard) isLocked(subject string, now time.Time) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	f, ok := g.fails[subject]
	return ok && now.Before(f.lockedUntil)
}

// fail records a failed attempt and reports whether the subject just got locked.
func (g *guard) fail(subject string, now time.Time) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	f, ok := g.fails[subject]
	if !ok {
		f = &failState{}
		g.fails[subject] = f
	}
	keep := f.times[:0]
	for _, t := range f.times {
		if now.Sub(t) < g.window {
			keep = append(keep, t)
		}
	}
	f.times = append(keep, now)
	if len(f.times) >= g.maxFails && !now.Before(f.lockedUntil) {
		f.lockedUntil = now.Add(g.lockFor)
		f.times = nil
		return true
	}
	return false
}

// allowIP applies a sliding-window rate limit per client IP.
func (g *guard) allowIP(ip string, now time.Time) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	hits := g.ipHits[ip][:0]
	for _, t := range g.ipHits[ip] {
		if now.Sub(t) < g.ipWindow {
			hits = append(hits, t)
		}
	}
	if len(hits) >= g.ipLimit {
		g.ipHits[ip] = hits
		return false
	}
	g.ipHits[ip] = append(hits, now)
	return true
}

// allowKey is a sliding-window limit for any key (per phone, per account).
func (g *guard) allowKey(key string, limit int, window time.Duration, now time.Time) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	hits := g.ipHits[key][:0]
	for _, t := range g.ipHits[key] {
		if now.Sub(t) < window {
			hits = append(hits, t)
		}
	}
	if len(hits) >= limit {
		g.ipHits[key] = hits
		return false
	}
	g.ipHits[key] = append(hits, now)
	return true
}

func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}

func (s *Service) securityEvent(ctx context.Context, kind, subject, detail string) {
	_ = s.st.InsertSecurityEvent(context.WithoutCancel(ctx), &store.SecurityEvent{Kind: kind, Subject: subject,
		Detail: detail, CreatedAt: s.now()})
	s.log.Warn("security event", "kind", kind, "subject", subject, "detail", detail)
}

// authFailure counts a failed device authentication and locks the device
// out after repeated failures (stolen keys, brute force, replay attempts).
func (s *Service) authFailure(ctx context.Context, device uint64, reason string) {
	subj := "device:" + offline.FormatID(device)
	if s.guard.fail(subj, s.now()) {
		s.securityEvent(ctx, EventAuthLockout, subj, "locked for 15 minutes after repeated failures; last: "+reason)
	}
}

// IssueServerNonce returns an unpredictable 256-bit nonce from crypto/rand,
// bound to one device and one purpose, valid once for two minutes.
func (s *Service) IssueServerNonce(ctx context.Context, d *store.Device, r api.AuthNonceRequest) (*api.AuthNonceResponse, error) {
	if err := activeOnly(d); err != nil {
		return nil, err
	}
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		return nil, err
	}
	n := hex.EncodeToString(b)
	if err := s.st.PutServerNonce(ctx, sha(n), d.ID, r.Purpose, s.now().Add(2*time.Minute)); err != nil {
		return nil, err
	}
	return &api.AuthNonceResponse{Nonce: n, ExpiresInSeconds: 120}, nil
}

// requireServerNonce consumes the request's nonce as a server nonce.
func (s *Service) requireServerNonce(r *http.Request, d *store.Device, purpose string) error {
	n := r.Header.Get(api.HeaderNonce)
	if len(n) != 64 || strings.Trim(n, "0123456789abcdef") != "" {
		s.authFailure(r.Context(), d.ID, "money request without a server nonce")
		return apiErr(401, "server_nonce_required", "money-moving requests must use a nonce from %s", api.PathAuthNonce)
	}
	if err := s.st.UseServerNonce(r.Context(), sha(n), d.ID, purpose, s.now()); err != nil {
		s.authFailure(r.Context(), d.ID, "invalid server nonce")
		s.securityEvent(r.Context(), EventNonceMisuse, "device:"+offline.FormatID(d.ID), "nonce unknown, used, expired, or for another purpose")
		return apiErr(401, "server_nonce_invalid", "nonce is unknown, already used, expired or for another purpose")
	}
	return nil
}
