package chain

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"io"

	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"golang.org/x/crypto/argon2"
	"golang.org/x/crypto/hkdf"
	"os"
	"path/filepath"
	"sort"
)

// Service signer identities. Each internal service signs only the stages it owns.
const (
	SignerOrchestrator  = "svc.orchestrator"
	SignerValidator     = "svc.validator"
	SignerAuthenticator = "svc.authenticator"
	SignerRisk          = "svc.risk"
	SignerAuthorizer    = "svc.authorizer"
	SignerCapturer      = "svc.capturer"
	SignerSettlement    = "svc.settlement"
	SignerCompensator   = "svc.compensator"
	SignerCSDR          = "svc.csdr"
	SignerAnchor        = "svc.anchor"
	SignerOffline       = "svc.offline"
	// SignerOfflineCA is the bank CA key that signs device certificates,
	// reserve instructions and the payee directory. Devices pin its public key.
	SignerOfflineCA = "svc.offline-ca"
)

// AllSigners lists every service identity that needs a key.
var AllSigners = []string{
	SignerOrchestrator, SignerValidator, SignerAuthenticator, SignerRisk,
	SignerAuthorizer, SignerCapturer, SignerSettlement, SignerCompensator,
	SignerCSDR, SignerAnchor, SignerOffline, SignerOfflineCA,
}

// PublicKey returns one service's Ed25519 public key.
func (k *KeyRing) PublicKey(id string) ed25519.PublicKey { return k.pub[id] }

// Signer signs digests on behalf of one service identity.
type Signer interface {
	ID() string
	Sign(msg []byte) []byte
}

// Verifier checks signatures for a named service identity.
type Verifier interface {
	Verify(signer string, msg, sig []byte) bool
}

// KeyRing holds Ed25519 keys for all service identities. In production these
// would live in an HSM or KMS; here they are persisted to a 0600 file.
type KeyRing struct {
	priv map[string]ed25519.PrivateKey
	pub  map[string]ed25519.PublicKey
}

type edSigner struct {
	id  string
	key ed25519.PrivateKey
}

func (s edSigner) ID() string             { return s.id }
func (s edSigner) Sign(msg []byte) []byte { return ed25519.Sign(s.key, msg) }

// NewEphemeralKeyRing creates in-memory keys, for tests.
func NewEphemeralKeyRing() *KeyRing {
	k := &KeyRing{priv: map[string]ed25519.PrivateKey{}, pub: map[string]ed25519.PublicKey{}}
	for _, id := range AllSigners {
		pub, priv, _ := ed25519.GenerateKey(rand.Reader)
		k.priv[id], k.pub[id] = priv, pub
	}
	return k
}

// LoadOrCreateKeyRing loads service keys from path, creating missing ones.
func LoadOrCreateKeyRing(path string) (*KeyRing, error) { return LoadOrCreateKeyRingWith(path, "") }

// sealedKeys is the on-disk form when a passphrase protects the key file.
type sealedKeys struct {
	Sealed bool   `json:"sealed"`
	Salt   []byte `json:"salt"`
	Nonce  []byte `json:"nonce"`
	Data   []byte `json:"data"`
}

func keyFileKEK(pass string, salt []byte) []byte {
	return argon2.IDKey([]byte(pass), salt, 3, 64*1024, 2, 32)
}

// LoadOrCreateKeyRingWith loads service keys, encrypting the file at rest
// with Argon2id + AES-256-GCM when passphrase is set. An existing plaintext
// file is re-written sealed on first use with a passphrase.
func LoadOrCreateKeyRingWith(path, passphrase string) (*KeyRing, error) {
	seeds := map[string]string{}
	b, err := os.ReadFile(path)
	migrate := false
	switch {
	case err == nil:
		var sk sealedKeys
		if json.Unmarshal(b, &sk) == nil && sk.Sealed {
			if passphrase == "" {
				return nil, errors.New("keyring: key file is encrypted; set PSTCO_KEY_PASSPHRASE")
			}
			plain, err := gcmOpen(keyFileKEK(passphrase, sk.Salt), sk.Nonce, sk.Data)
			if err != nil {
				return nil, errors.New("keyring: wrong passphrase or corrupt key file")
			}
			b = plain
		} else if passphrase != "" {
			migrate = true
		}
		if err := json.Unmarshal(b, &seeds); err != nil {
			return nil, fmt.Errorf("keyring: parse %s: %w", path, err)
		}
	case errors.Is(err, os.ErrNotExist):
	default:
		return nil, err
	}
	k := &KeyRing{priv: map[string]ed25519.PrivateKey{}, pub: map[string]ed25519.PublicKey{}}
	changed := false
	for _, id := range AllSigners {
		var seed []byte
		if s, ok := seeds[id]; ok {
			seed, err = base64.StdEncoding.DecodeString(s)
			if err != nil || len(seed) != ed25519.SeedSize {
				return nil, fmt.Errorf("keyring: bad seed for %s", id)
			}
		} else {
			seed = make([]byte, ed25519.SeedSize)
			if _, err := rand.Read(seed); err != nil {
				return nil, err
			}
			seeds[id] = base64.StdEncoding.EncodeToString(seed)
			changed = true
		}
		priv := ed25519.NewKeyFromSeed(seed)
		k.priv[id] = priv
		k.pub[id] = priv.Public().(ed25519.PublicKey)
	}
	if changed || migrate {
		if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
			return nil, err
		}
		out, _ := json.MarshalIndent(seeds, "", "  ")
		if passphrase != "" {
			salt := make([]byte, 16)
			if _, err := rand.Read(salt); err != nil {
				return nil, err
			}
			nonce, ct, err := gcmSeal(keyFileKEK(passphrase, salt), out)
			if err != nil {
				return nil, err
			}
			out, _ = json.Marshal(sealedKeys{Sealed: true, Salt: salt, Nonce: nonce, Data: ct})
		}
		tmp := path + ".tmp"
		if err := os.WriteFile(tmp, out, 0o600); err != nil {
			return nil, err
		}
		if err := os.Rename(tmp, path); err != nil {
			return nil, err
		}
	}
	return k, nil
}

func gcmSeal(key, plain []byte) (nonce, ct []byte, err error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, nil, err
	}
	g, err := cipher.NewGCM(block)
	if err != nil {
		return nil, nil, err
	}
	nonce = make([]byte, g.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return nil, nil, err
	}
	return nonce, g.Seal(nil, nonce, plain, []byte("pstco-keyring")), nil
}

func gcmOpen(key, nonce, ct []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	g, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return g.Open(nil, nonce, ct, []byte("pstco-keyring"))
}

// DeriveKey returns a deterministic 32-byte key for a purpose, derived from
// the orchestrator key with HKDF-SHA256. Every instance sharing the key file
// derives the same key; nothing outside the key file can.
func (k *KeyRing) DeriveKey(purpose string) []byte {
	seed := k.priv[SignerOrchestrator].Seed()
	out := make([]byte, 32)
	r := hkdf.New(sha256.New, seed, []byte("pstco-derive/1"), []byte(purpose))
	_, _ = io.ReadFull(r, out)
	return out
}

// Signer returns the signer for a service identity. It panics on an unknown
// identity because that is a programming error.
func (k *KeyRing) Signer(id string) Signer {
	key, ok := k.priv[id]
	if !ok {
		panic("keyring: unknown signer " + id)
	}
	return edSigner{id: id, key: key}
}

// Verify implements Verifier.
func (k *KeyRing) Verify(signer string, msg, sig []byte) bool {
	pub, ok := k.pub[signer]
	if !ok {
		return false
	}
	return ed25519.Verify(pub, msg, sig)
}

// PublicKeys exports the public half of the ring, for external auditors.
func (k *KeyRing) PublicKeys() map[string]string {
	out := map[string]string{}
	ids := make([]string, 0, len(k.pub))
	for id := range k.pub {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	for _, id := range ids {
		out[id] = base64.StdEncoding.EncodeToString(k.pub[id])
	}
	return out
}
